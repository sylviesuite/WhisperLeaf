# Sovereign AI API Documentation

**Complete API reference for Sovereign AI Level 3 Personal AI System**

---

## Table of Contents

1. [Overview](#overview)
2. [Authentication](#authentication)
3. [Chat API](#chat-api)
4. [Constitutional AI API](#constitutional-ai-api)
5. [Curation API](#curation-api)
6. [Backup API](#backup-api)
7. [System API](#system-api)
8. [Error Handling](#error-handling)
9. [Rate Limiting](#rate-limiting)
10. [WebSocket API](#websocket-api)
11. [SDK Examples](#sdk-examples)

---

## Overview

Sovereign AI provides RESTful APIs for all system components, enabling programmatic access to chat functionality, constitutional governance, content curation, backup operations, and system management.

### Base URLs

- **Chat API**: `http://localhost:8003`
- **Curation API**: `http://localhost:8002`

### API Versioning

All APIs use version 1 (`/api/v1/`) unless otherwise specified. The current APIs use `/api/` for backward compatibility.

### Content Types

- **Request Content-Type**: `application/json`
- **Response Content-Type**: `application/json`
- **Character Encoding**: UTF-8

### HTTP Status Codes

- `200 OK`: Request successful
- `201 Created`: Resource created successfully
- `400 Bad Request`: Invalid request parameters
- `401 Unauthorized`: Authentication required
- `403 Forbidden`: Access denied
- `404 Not Found`: Resource not found
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: Server error

---

## Authentication

### API Key Authentication

For production deployments, API key authentication is recommended:

```bash
# Include API key in request headers
curl -H "X-API-Key: your-api-key-here" \
     -H "Content-Type: application/json" \
     http://localhost:8003/api/chat
```

### Session-Based Authentication

For web applications, session-based authentication is supported:

```bash
# Login to create session
curl -X POST http://localhost:8003/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{"username": "user", "password": "password"}'

# Use session cookie for subsequent requests
curl -b cookies.txt http://localhost:8003/api/chat
```

---

## Chat API

The Chat API provides conversational AI capabilities with constitutional governance.

### Base URL: `http://localhost:8003`

### Send Message

Send a message to the AI and receive a constitutionally-governed response.

**Endpoint**: `POST /api/chat`

**Request Body**:
```json
{
  "message": "Hello, can you help me with something?",
  "conversation_id": "optional-conversation-id",
  "context": {
    "user_preferences": {
      "response_length": "medium",
      "formality": "casual"
    }
  }
}
```

**Response**:
```json
{
  "response": "Hello! I'd be happy to help you. What do you need assistance with?",
  "constitutional_evaluation": {
    "approved": true,
    "confidence": 0.95,
    "applied_rules": ["helpful_behavior"],
    "blocked_rules": [],
    "processing_time_ms": 245,
    "reasoning": "Message approved: Helpful request with no constitutional violations"
  },
  "conversation_id": "conv_1234567890",
  "message_id": "msg_1234567890",
  "timestamp": "2025-07-19T18:00:00Z",
  "metadata": {
    "model_used": "tinyllama",
    "tokens_used": 156,
    "response_time_ms": 1250
  }
}
```

**Example**:
```bash
curl -X POST http://localhost:8003/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What are the key principles of artificial intelligence?",
    "conversation_id": "conv_ai_discussion"
  }'
```

### Get Conversations

Retrieve conversation history with optional filtering.

**Endpoint**: `GET /api/conversations`

**Query Parameters**:
- `limit` (optional): Maximum number of conversations to return (default: 50)
- `offset` (optional): Number of conversations to skip (default: 0)
- `since` (optional): ISO timestamp to filter conversations after this date
- `conversation_id` (optional): Specific conversation ID to retrieve

**Response**:
```json
{
  "conversations": [
    {
      "conversation_id": "conv_1234567890",
      "created_at": "2025-07-19T18:00:00Z",
      "updated_at": "2025-07-19T18:15:30Z",
      "message_count": 12,
      "title": "AI Principles Discussion",
      "messages": [
        {
          "message_id": "msg_1234567890",
          "role": "user",
          "content": "What are the key principles of AI?",
          "timestamp": "2025-07-19T18:00:00Z"
        },
        {
          "message_id": "msg_1234567891",
          "role": "assistant",
          "content": "The key principles of AI include...",
          "timestamp": "2025-07-19T18:00:01Z",
          "constitutional_evaluation": {
            "approved": true,
            "confidence": 0.95,
            "applied_rules": ["helpful_behavior"]
          }
        }
      ]
    }
  ],
  "total_conversations": 25,
  "has_more": true
}
```

**Example**:
```bash
# Get recent conversations
curl "http://localhost:8003/api/conversations?limit=10&since=2025-07-19T00:00:00Z"

# Get specific conversation
curl "http://localhost:8003/api/conversations?conversation_id=conv_1234567890"
```

### Delete Conversation

Delete a specific conversation and all its messages.

**Endpoint**: `DELETE /api/conversations/{conversation_id}`

**Response**:
```json
{
  "status": "success",
  "message": "Conversation deleted successfully",
  "conversation_id": "conv_1234567890"
}
```

**Example**:
```bash
curl -X DELETE http://localhost:8003/api/conversations/conv_1234567890
```

### Get Chat Statistics

Retrieve chat system statistics and metrics.

**Endpoint**: `GET /api/chat/stats`

**Response**:
```json
{
  "total_conversations": 150,
  "total_messages": 2340,
  "average_messages_per_conversation": 15.6,
  "constitutional_stats": {
    "total_evaluations": 2340,
    "approved_messages": 2180,
    "blocked_messages": 160,
    "approval_rate": 0.932
  },
  "performance_stats": {
    "average_response_time_ms": 1250,
    "average_constitutional_evaluation_ms": 245,
    "uptime_hours": 168.5
  },
  "model_stats": {
    "model_name": "tinyllama",
    "total_tokens_processed": 156780,
    "average_tokens_per_response": 67
  }
}
```

---

## Constitutional AI API

The Constitutional AI API manages rules, governance, and behavioral control.

### Base URL: `http://localhost:8003`

### Get Constitutional Rules

Retrieve all constitutional rules and their configurations.

**Endpoint**: `GET /api/constitution/rules`

**Response**:
```json
{
  "rules": {
    "privacy_protection": {
      "rule_id": "privacy_protection",
      "name": "Privacy Protection",
      "description": "Protect user privacy and personal information",
      "rule_type": "privacy",
      "priority": "critical",
      "enabled": true,
      "conditions": [
        "password",
        "social security",
        "credit card",
        "personal information"
      ],
      "action": "block",
      "response_template": "I cannot help with requests involving personal or sensitive information.",
      "created_at": "2025-07-19T18:00:00Z",
      "updated_at": "2025-07-19T18:00:00Z"
    },
    "helpful_behavior": {
      "rule_id": "helpful_behavior",
      "name": "Helpful Behavior",
      "description": "Provide helpful and constructive assistance",
      "rule_type": "behavioral",
      "priority": "high",
      "enabled": true,
      "conditions": ["help", "assist", "support"],
      "action": "encourage",
      "response_template": "I'm here to help you with that.",
      "created_at": "2025-07-19T18:00:00Z",
      "updated_at": "2025-07-19T18:00:00Z"
    }
  },
  "total_rules": 5,
  "active_rules": 5,
  "rule_types": ["privacy", "behavioral", "safety", "ethical", "functional"]
}
```

### Add Constitutional Rule

Create a new constitutional rule.

**Endpoint**: `POST /api/constitution/rules`

**Request Body**:
```json
{
  "rule_id": "custom_safety_rule",
  "name": "Custom Safety Rule",
  "description": "Block requests for dangerous activities",
  "rule_type": "safety",
  "priority": "critical",
  "conditions": [
    "dangerous",
    "harmful",
    "illegal",
    "violence"
  ],
  "action": "block",
  "response_template": "I cannot provide assistance with potentially dangerous or harmful activities.",
  "enabled": true
}
```

**Response**:
```json
{
  "status": "success",
  "message": "Constitutional rule created successfully",
  "rule_id": "custom_safety_rule",
  "rule": {
    "rule_id": "custom_safety_rule",
    "name": "Custom Safety Rule",
    "description": "Block requests for dangerous activities",
    "rule_type": "safety",
    "priority": "critical",
    "enabled": true,
    "created_at": "2025-07-19T18:00:00Z"
  }
}
```

### Update Constitutional Rule

Update an existing constitutional rule.

**Endpoint**: `PUT /api/constitution/rules/{rule_id}`

**Request Body**:
```json
{
  "name": "Updated Safety Rule",
  "description": "Enhanced safety rule with additional conditions",
  "conditions": [
    "dangerous",
    "harmful",
    "illegal",
    "violence",
    "weapons"
  ],
  "enabled": true
}
```

**Response**:
```json
{
  "status": "success",
  "message": "Constitutional rule updated successfully",
  "rule_id": "custom_safety_rule",
  "updated_fields": ["name", "description", "conditions"]
}
```

### Delete Constitutional Rule

Delete a constitutional rule.

**Endpoint**: `DELETE /api/constitution/rules/{rule_id}`

**Response**:
```json
{
  "status": "success",
  "message": "Constitutional rule deleted successfully",
  "rule_id": "custom_safety_rule"
}
```

### Evaluate Message

Evaluate a message against constitutional rules without sending to AI.

**Endpoint**: `POST /api/constitution/evaluate`

**Request Body**:
```json
{
  "message": "Can you help me hack into someone's computer?",
  "context": {
    "conversation_id": "conv_1234567890",
    "user_id": "user_123"
  }
}
```

**Response**:
```json
{
  "evaluation": {
    "approved": false,
    "confidence": 0.98,
    "applied_rules": ["privacy_protection", "safety_rule"],
    "blocked_rules": ["privacy_protection"],
    "processing_time_ms": 15,
    "reasoning": "Message blocked: Contains request for potentially illegal hacking activity",
    "suggested_response": "I cannot provide assistance with hacking or unauthorized access to computer systems."
  },
  "rule_details": [
    {
      "rule_id": "privacy_protection",
      "rule_name": "Privacy Protection",
      "matched_conditions": ["hack"],
      "action_taken": "block",
      "confidence": 0.98
    }
  ]
}
```

### Get Constitutional Statistics

Retrieve constitutional governance statistics.

**Endpoint**: `GET /api/constitution/stats`

**Response**:
```json
{
  "total_evaluations": 5680,
  "approved_messages": 5234,
  "blocked_messages": 446,
  "approval_rate": 0.921,
  "rule_usage": {
    "privacy_protection": {
      "triggered": 156,
      "blocked": 156,
      "success_rate": 1.0
    },
    "helpful_behavior": {
      "triggered": 3420,
      "encouraged": 3420,
      "success_rate": 1.0
    }
  },
  "performance_metrics": {
    "average_evaluation_time_ms": 12.5,
    "max_evaluation_time_ms": 45,
    "min_evaluation_time_ms": 2
  },
  "rule_effectiveness": {
    "critical_priority": 0.99,
    "high_priority": 0.95,
    "medium_priority": 0.87,
    "low_priority": 0.78
  }
}
```

---

## Curation API

The Curation API manages content sources, processing, and filtering.

### Base URL: `http://localhost:8002`

### Add Content Source

Add a new content source for automated curation.

**Endpoint**: `POST /api/sources`

**Request Body**:
```json
{
  "url": "https://feeds.bbci.co.uk/news/rss.xml",
  "source_type": "rss",
  "name": "BBC News",
  "description": "BBC News RSS feed",
  "priority": 8,
  "scan_interval": 3600,
  "tags": ["news", "bbc", "international"],
  "filter_rules": {
    "quality_threshold": 0.7,
    "relevance_threshold": 0.5,
    "required_keywords": ["technology", "science"],
    "excluded_keywords": ["sports", "entertainment"]
  },
  "enabled": true
}
```

**Response**:
```json
{
  "status": "success",
  "message": "Content source added successfully",
  "source_id": "source_1234567890",
  "source": {
    "source_id": "source_1234567890",
    "url": "https://feeds.bbci.co.uk/news/rss.xml",
    "source_type": "rss",
    "name": "BBC News",
    "priority": 8,
    "status": "active",
    "created_at": "2025-07-19T18:00:00Z",
    "next_scan": "2025-07-19T19:00:00Z"
  }
}
```

### Get Content Sources

Retrieve all content sources with optional filtering.

**Endpoint**: `GET /api/sources`

**Query Parameters**:
- `source_type` (optional): Filter by source type (rss, web)
- `status` (optional): Filter by status (active, paused, error, disabled)
- `priority_min` (optional): Minimum priority level
- `limit` (optional): Maximum number of sources to return
- `offset` (optional): Number of sources to skip

**Response**:
```json
{
  "sources": [
    {
      "source_id": "source_1234567890",
      "url": "https://feeds.bbci.co.uk/news/rss.xml",
      "source_type": "rss",
      "name": "BBC News",
      "description": "BBC News RSS feed",
      "priority": 8,
      "status": "active",
      "scan_interval": 3600,
      "last_scan": "2025-07-19T18:00:00Z",
      "next_scan": "2025-07-19T19:00:00Z",
      "performance": {
        "success_rate": 0.95,
        "average_quality": 0.78,
        "average_relevance": 0.65,
        "items_processed": 150,
        "items_accepted": 45,
        "items_rejected": 105
      },
      "tags": ["news", "bbc", "international"],
      "created_at": "2025-07-19T18:00:00Z",
      "updated_at": "2025-07-19T18:00:00Z"
    }
  ],
  "total_sources": 10,
  "active_sources": 8,
  "paused_sources": 2
}
```

### Update Content Source

Update an existing content source.

**Endpoint**: `PUT /api/sources/{source_id}`

**Request Body**:
```json
{
  "name": "BBC News - Updated",
  "priority": 9,
  "scan_interval": 1800,
  "filter_rules": {
    "quality_threshold": 0.8,
    "relevance_threshold": 0.6
  },
  "enabled": true
}
```

**Response**:
```json
{
  "status": "success",
  "message": "Content source updated successfully",
  "source_id": "source_1234567890",
  "updated_fields": ["name", "priority", "scan_interval", "filter_rules"]
}
```

### Delete Content Source

Delete a content source.

**Endpoint**: `DELETE /api/sources/{source_id}`

**Response**:
```json
{
  "status": "success",
  "message": "Content source deleted successfully",
  "source_id": "source_1234567890"
}
```

### Manual Content Scan

Trigger a manual scan of all active content sources.

**Endpoint**: `POST /api/scan/manual`

**Request Body** (optional):
```json
{
  "source_ids": ["source_1234567890", "source_0987654321"],
  "force_rescan": false
}
```

**Response**:
```json
{
  "status": "success",
  "message": "Manual scan initiated",
  "scan_id": "scan_1234567890",
  "sources_scanned": 5,
  "estimated_duration_seconds": 120,
  "started_at": "2025-07-19T18:00:00Z"
}
```

### Get Scan Status

Check the status of a content scan operation.

**Endpoint**: `GET /api/scan/{scan_id}/status`

**Response**:
```json
{
  "scan_id": "scan_1234567890",
  "status": "completed",
  "progress": {
    "sources_total": 5,
    "sources_completed": 5,
    "sources_failed": 0,
    "items_processed": 125,
    "items_accepted": 23,
    "items_rejected": 102
  },
  "started_at": "2025-07-19T18:00:00Z",
  "completed_at": "2025-07-19T18:02:15Z",
  "duration_seconds": 135,
  "results": [
    {
      "source_id": "source_1234567890",
      "source_name": "BBC News",
      "status": "success",
      "items_found": 25,
      "items_accepted": 5,
      "items_rejected": 20,
      "processing_time_seconds": 12.5
    }
  ]
}
```

### Get Curated Content

Retrieve curated content items with filtering and pagination.

**Endpoint**: `GET /api/content`

**Query Parameters**:
- `limit` (optional): Maximum number of items to return (default: 50)
- `offset` (optional): Number of items to skip (default: 0)
- `since` (optional): ISO timestamp to filter content after this date
- `source_id` (optional): Filter by specific source
- `quality_min` (optional): Minimum quality score (0.0-1.0)
- `relevance_min` (optional): Minimum relevance score (0.0-1.0)
- `tags` (optional): Comma-separated list of tags to filter by

**Response**:
```json
{
  "content": [
    {
      "content_id": "content_1234567890",
      "title": "Advances in Artificial Intelligence Research",
      "url": "https://example.com/ai-research-advances",
      "content": "Recent breakthroughs in artificial intelligence...",
      "summary": "This article discusses recent AI research developments...",
      "source": {
        "source_id": "source_1234567890",
        "name": "BBC News",
        "url": "https://feeds.bbci.co.uk/news/rss.xml"
      },
      "quality_score": 0.85,
      "relevance_score": 0.92,
      "tags": ["ai", "research", "technology"],
      "author": "Dr. Jane Smith",
      "published_at": "2025-07-19T17:30:00Z",
      "processed_at": "2025-07-19T18:00:00Z",
      "word_count": 1250,
      "language": "en"
    }
  ],
  "total_items": 156,
  "has_more": true,
  "filters_applied": {
    "quality_min": 0.7,
    "relevance_min": 0.5
  }
}
```

### Get Curation Statistics

Retrieve comprehensive curation system statistics.

**Endpoint**: `GET /api/stats/overview`

**Response**:
```json
{
  "sources": {
    "total": 10,
    "active": 8,
    "paused": 2,
    "error": 0,
    "by_type": {
      "rss": 7,
      "web": 3
    }
  },
  "content": {
    "items_processed": 1250,
    "items_accepted": 156,
    "items_rejected": 1094,
    "acceptance_rate": 0.125,
    "average_quality": 0.68,
    "average_relevance": 0.45
  },
  "performance": {
    "scans_completed": 45,
    "scans_failed": 2,
    "success_rate": 0.956,
    "average_scan_time_seconds": 45.2,
    "items_per_hour": 125.5
  },
  "filtering": {
    "quality_rejections": 456,
    "relevance_rejections": 389,
    "duplicate_rejections": 249,
    "filter_effectiveness": 0.876
  },
  "storage": {
    "total_content_items": 156,
    "total_size_mb": 12.5,
    "average_item_size_kb": 82.1
  }
}
```

### Set User Interests

Configure user interests for relevance scoring.

**Endpoint**: `POST /api/interests`

**Request Body**:
```json
{
  "interests": [
    {
      "keyword": "artificial intelligence",
      "weight": 1.0,
      "category": "technology"
    },
    {
      "keyword": "machine learning",
      "weight": 0.9,
      "category": "technology"
    },
    {
      "keyword": "climate change",
      "weight": 0.8,
      "category": "environment"
    }
  ],
  "categories": {
    "technology": 1.0,
    "science": 0.8,
    "environment": 0.7,
    "politics": 0.3
  }
}
```

**Response**:
```json
{
  "status": "success",
  "message": "User interests updated successfully",
  "interests_count": 3,
  "categories_count": 4,
  "updated_at": "2025-07-19T18:00:00Z"
}
```

---

## Backup API

The Backup API provides access to the Time Capsule backup and recovery system.

### Base URL: `http://localhost:8003` (integrated with Chat API)

### Create Backup

Create a new system backup.

**Endpoint**: `POST /api/backup/create`

**Request Body**:
```json
{
  "backup_type": "full",
  "description": "Manual backup before system update",
  "tags": ["manual", "pre-update"],
  "components": [
    "constitution",
    "conversations", 
    "documents",
    "configuration",
    "curation_data"
  ]
}
```

**Response**:
```json
{
  "status": "success",
  "message": "Backup created successfully",
  "backup_id": "backup_1234567890_full",
  "backup": {
    "backup_id": "backup_1234567890_full",
    "backup_type": "full",
    "description": "Manual backup before system update",
    "total_size_bytes": 1535000,
    "compressed_size_bytes": 994000,
    "compression_ratio": 0.647,
    "files_included": 25,
    "components": ["constitution", "conversations", "documents"],
    "created_at": "2025-07-19T18:00:00Z",
    "verification_status": "verified"
  }
}
```

### List Backups

Retrieve list of all backups with optional filtering.

**Endpoint**: `GET /api/backup/list`

**Query Parameters**:
- `backup_type` (optional): Filter by backup type (full, incremental, differential)
- `limit` (optional): Maximum number of backups to return
- `since` (optional): ISO timestamp to filter backups after this date
- `tags` (optional): Comma-separated list of tags to filter by

**Response**:
```json
{
  "backups": [
    {
      "backup_id": "backup_1234567890_full",
      "backup_type": "full",
      "description": "Manual backup before system update",
      "total_size_bytes": 1535000,
      "compressed_size_bytes": 994000,
      "compression_ratio": 0.647,
      "files_included": 25,
      "tags": ["manual", "pre-update"],
      "created_at": "2025-07-19T18:00:00Z",
      "verification_status": "verified",
      "retention_until": "2025-08-18T18:00:00Z"
    }
  ],
  "total_backups": 15,
  "total_size_bytes": 23450000,
  "total_compressed_bytes": 15123000,
  "average_compression_ratio": 0.645
}
```

### Get Backup Details

Get detailed information about a specific backup.

**Endpoint**: `GET /api/backup/{backup_id}`

**Response**:
```json
{
  "backup_id": "backup_1234567890_full",
  "backup_type": "full",
  "description": "Manual backup before system update",
  "total_size_bytes": 1535000,
  "compressed_size_bytes": 994000,
  "compression_ratio": 0.647,
  "files_included": 25,
  "components": ["constitution", "conversations", "documents"],
  "tags": ["manual", "pre-update"],
  "created_at": "2025-07-19T18:00:00Z",
  "verification_status": "verified",
  "checksum": "sha256:abc123def456...",
  "retention_until": "2025-08-18T18:00:00Z",
  "file_manifest": [
    {
      "path": "constitution/rules.json",
      "size_bytes": 2048,
      "checksum": "sha256:def789ghi012..."
    },
    {
      "path": "conversations/conv_123.json",
      "size_bytes": 15360,
      "checksum": "sha256:jkl345mno678..."
    }
  ]
}
```

### Verify Backup

Verify the integrity of a backup.

**Endpoint**: `POST /api/backup/{backup_id}/verify`

**Response**:
```json
{
  "status": "success",
  "backup_id": "backup_1234567890_full",
  "verification_result": {
    "is_valid": true,
    "checksum_match": true,
    "files_verified": 25,
    "files_failed": 0,
    "verification_time_seconds": 2.5
  },
  "verified_at": "2025-07-19T18:00:00Z"
}
```

### Delete Backup

Delete a specific backup.

**Endpoint**: `DELETE /api/backup/{backup_id}`

**Response**:
```json
{
  "status": "success",
  "message": "Backup deleted successfully",
  "backup_id": "backup_1234567890_full",
  "space_freed_bytes": 994000
}
```

### Create System Snapshot

Create a lightweight system snapshot for quick recovery.

**Endpoint**: `POST /api/backup/snapshot`

**Request Body**:
```json
{
  "description": "Pre-configuration change snapshot",
  "components": ["constitution", "configuration"]
}
```

**Response**:
```json
{
  "status": "success",
  "message": "System snapshot created successfully",
  "snapshot_id": "snapshot_1234567890",
  "snapshot": {
    "snapshot_id": "snapshot_1234567890",
    "description": "Pre-configuration change snapshot",
    "constitution_rules": 5,
    "conversation_count": 25,
    "document_count": 156,
    "created_at": "2025-07-19T18:00:00Z"
  }
}
```

### Create Recovery Plan

Create a recovery plan for point-in-time recovery.

**Endpoint**: `POST /api/backup/recovery-plan`

**Request Body**:
```json
{
  "target_timestamp": "2025-07-19T16:00:00Z",
  "components": ["constitution", "conversations", "documents"],
  "description": "Recovery plan for system rollback"
}
```

**Response**:
```json
{
  "status": "success",
  "message": "Recovery plan created successfully",
  "plan_id": "recovery_plan_1234567890",
  "recovery_plan": {
    "plan_id": "recovery_plan_1234567890",
    "target_timestamp": "2025-07-19T16:00:00Z",
    "components": ["constitution", "conversations", "documents"],
    "risk_level": "medium",
    "estimated_duration_minutes": 34,
    "data_loss_risk": false,
    "selected_backup": "backup_1234567890_full",
    "steps": [
      {
        "step": 1,
        "action": "create_pre_recovery_backup",
        "description": "Create backup of current state"
      },
      {
        "step": 2,
        "action": "restore_constitution",
        "description": "Restore constitutional rules"
      }
    ],
    "created_at": "2025-07-19T18:00:00Z"
  }
}
```

### Execute Recovery Plan

Execute a previously created recovery plan.

**Endpoint**: `POST /api/backup/recovery-plan/{plan_id}/execute`

**Response**:
```json
{
  "status": "success",
  "message": "Recovery plan execution started",
  "plan_id": "recovery_plan_1234567890",
  "execution_id": "exec_1234567890",
  "estimated_duration_minutes": 34,
  "started_at": "2025-07-19T18:00:00Z"
}
```

### Get Recovery Status

Check the status of a recovery operation.

**Endpoint**: `GET /api/backup/recovery/{execution_id}/status`

**Response**:
```json
{
  "execution_id": "exec_1234567890",
  "plan_id": "recovery_plan_1234567890",
  "status": "in_progress",
  "progress": {
    "current_step": 2,
    "total_steps": 4,
    "percentage": 50,
    "current_action": "restore_constitution"
  },
  "started_at": "2025-07-19T18:00:00Z",
  "estimated_completion": "2025-07-19T18:34:00Z",
  "steps_completed": [
    {
      "step": 1,
      "action": "create_pre_recovery_backup",
      "status": "completed",
      "completed_at": "2025-07-19T18:05:00Z"
    }
  ]
}
```

---

## System API

The System API provides system health, monitoring, and management capabilities.

### Base URL: `http://localhost:8003`

### Health Check

Check the health status of all system components.

**Endpoint**: `GET /health`

**Response**:
```json
{
  "status": "healthy",
  "timestamp": "2025-07-19T18:00:00Z",
  "version": "1.0.0",
  "uptime_seconds": 86400,
  "components": {
    "chat_api": {
      "status": "healthy",
      "response_time_ms": 2.5
    },
    "constitutional_ai": {
      "status": "healthy",
      "rules_loaded": 5,
      "evaluations_per_second": 15.2
    },
    "ai_model": {
      "status": "healthy",
      "model_name": "tinyllama",
      "model_loaded": true
    },
    "database": {
      "status": "healthy",
      "connection_pool": "available"
    }
  }
}
```

### System Statistics

Get comprehensive system statistics and metrics.

**Endpoint**: `GET /api/system/stats`

**Response**:
```json
{
  "system": {
    "uptime_seconds": 86400,
    "version": "1.0.0",
    "environment": "production",
    "started_at": "2025-07-18T18:00:00Z"
  },
  "performance": {
    "cpu_usage_percent": 15.2,
    "memory_usage_mb": 512.5,
    "memory_usage_percent": 12.8,
    "disk_usage_gb": 2.5,
    "disk_usage_percent": 25.0
  },
  "api_metrics": {
    "total_requests": 15680,
    "requests_per_minute": 45.2,
    "average_response_time_ms": 125.5,
    "error_rate": 0.002
  },
  "ai_metrics": {
    "total_messages_processed": 2340,
    "average_processing_time_ms": 1250,
    "constitutional_evaluations": 2340,
    "constitutional_blocks": 160
  },
  "storage_metrics": {
    "conversations": 150,
    "messages": 2340,
    "documents": 156,
    "backups": 15,
    "total_storage_mb": 125.5
  }
}
```

### System Configuration

Get or update system configuration.

**Endpoint**: `GET /api/system/config`

**Response**:
```json
{
  "system": {
    "name": "Sovereign AI",
    "version": "1.0.0",
    "environment": "production",
    "debug": false
  },
  "ai": {
    "model": "tinyllama",
    "temperature": 0.7,
    "max_tokens": 2048,
    "timeout": 30
  },
  "constitutional": {
    "default_rules_enabled": true,
    "rule_evaluation_timeout": 1000,
    "confidence_threshold": 0.8,
    "audit_logging": true
  },
  "api": {
    "chat_port": 8003,
    "curation_port": 8002,
    "cors_enabled": true,
    "rate_limiting": true
  }
}
```

**Update Configuration**: `PUT /api/system/config`

**Request Body**:
```json
{
  "ai": {
    "temperature": 0.5,
    "max_tokens": 1024
  },
  "constitutional": {
    "confidence_threshold": 0.9
  }
}
```

### System Logs

Retrieve system logs with filtering.

**Endpoint**: `GET /api/system/logs`

**Query Parameters**:
- `level` (optional): Log level filter (DEBUG, INFO, WARNING, ERROR)
- `component` (optional): Component filter (chat_api, constitutional, curation)
- `since` (optional): ISO timestamp to filter logs after this date
- `limit` (optional): Maximum number of log entries to return

**Response**:
```json
{
  "logs": [
    {
      "timestamp": "2025-07-19T18:00:00Z",
      "level": "INFO",
      "component": "chat_api",
      "message": "Message processed successfully",
      "metadata": {
        "conversation_id": "conv_1234567890",
        "processing_time_ms": 1250
      }
    },
    {
      "timestamp": "2025-07-19T17:59:45Z",
      "level": "WARNING",
      "component": "constitutional",
      "message": "Message blocked by constitutional rule",
      "metadata": {
        "rule_id": "privacy_protection",
        "confidence": 0.95
      }
    }
  ],
  "total_entries": 1500,
  "has_more": true
}
```

---

## Error Handling

### Standard Error Response Format

All APIs return errors in a consistent format:

```json
{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "The request body is invalid or missing required fields",
    "details": {
      "field": "message",
      "issue": "Field is required but was not provided"
    },
    "request_id": "req_1234567890",
    "timestamp": "2025-07-19T18:00:00Z"
  }
}
```

### Common Error Codes

- `INVALID_REQUEST`: Request body or parameters are invalid
- `UNAUTHORIZED`: Authentication required or invalid
- `FORBIDDEN`: Access denied for the requested resource
- `NOT_FOUND`: Requested resource does not exist
- `RATE_LIMITED`: Too many requests, rate limit exceeded
- `CONSTITUTIONAL_VIOLATION`: Message blocked by constitutional rules
- `AI_MODEL_ERROR`: Error communicating with AI model
- `DATABASE_ERROR`: Database operation failed
- `BACKUP_ERROR`: Backup operation failed
- `INTERNAL_ERROR`: Unexpected server error

### Error Handling Examples

```bash
# Handle authentication error
curl -X POST http://localhost:8003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello"}'

# Response (401 Unauthorized):
{
  "error": {
    "code": "UNAUTHORIZED",
    "message": "API key required for this endpoint",
    "request_id": "req_1234567890"
  }
}

# Handle constitutional violation
curl -X POST http://localhost:8003/api/chat \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{"message": "Can you help me hack something?"}'

# Response (200 OK with blocked message):
{
  "response": "I cannot provide assistance with hacking or unauthorized access to systems.",
  "constitutional_evaluation": {
    "approved": false,
    "confidence": 0.98,
    "blocked_rules": ["privacy_protection"],
    "reasoning": "Message blocked: Contains request for potentially illegal activity"
  }
}
```

---

## Rate Limiting

### Rate Limit Headers

All API responses include rate limiting headers:

```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1642694400
X-RateLimit-Window: 60
```

### Rate Limits by Endpoint

- **Chat API**: 60 requests per minute per IP
- **Constitutional API**: 120 requests per minute per IP
- **Curation API**: 30 requests per minute per IP
- **Backup API**: 10 requests per minute per IP
- **System API**: 100 requests per minute per IP

### Rate Limit Exceeded Response

```json
{
  "error": {
    "code": "RATE_LIMITED",
    "message": "Rate limit exceeded. Try again in 60 seconds.",
    "details": {
      "limit": 60,
      "window_seconds": 60,
      "retry_after_seconds": 45
    }
  }
}
```

---

## WebSocket API

### Real-Time Chat WebSocket

Connect to the WebSocket endpoint for real-time chat functionality.

**Endpoint**: `ws://localhost:8003/ws/chat`

**Connection**:
```javascript
const ws = new WebSocket('ws://localhost:8003/ws/chat');

ws.onopen = function(event) {
    console.log('Connected to Sovereign AI');
};

ws.onmessage = function(event) {
    const data = JSON.parse(event.data);
    console.log('Received:', data);
};
```

**Send Message**:
```javascript
const message = {
    type: 'chat_message',
    data: {
        message: 'Hello, how are you?',
        conversation_id: 'conv_1234567890'
    }
};

ws.send(JSON.stringify(message));
```

**Receive Response**:
```json
{
  "type": "chat_response",
  "data": {
    "response": "Hello! I'm doing well, thank you for asking.",
    "constitutional_evaluation": {
      "approved": true,
      "confidence": 0.95
    },
    "message_id": "msg_1234567890",
    "timestamp": "2025-07-19T18:00:00Z"
  }
}
```

### System Events WebSocket

Subscribe to system events and notifications.

**Endpoint**: `ws://localhost:8003/ws/events`

**Event Types**:
- `backup_created`: New backup created
- `constitutional_violation`: Message blocked by rules
- `curation_scan_completed`: Content scan finished
- `system_health_change`: System health status changed

**Example Event**:
```json
{
  "type": "backup_created",
  "data": {
    "backup_id": "backup_1234567890_full",
    "backup_type": "full",
    "size_bytes": 1535000,
    "created_at": "2025-07-19T18:00:00Z"
  },
  "timestamp": "2025-07-19T18:00:00Z"
}
```

---

## SDK Examples

### Python SDK Example

```python
import requests
import json
from datetime import datetime

class SovereignAIClient:
    def __init__(self, base_url="http://localhost:8003", api_key=None):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
        if api_key:
            self.headers["X-API-Key"] = api_key
    
    def send_message(self, message, conversation_id=None):
        """Send a message to the AI."""
        data = {"message": message}
        if conversation_id:
            data["conversation_id"] = conversation_id
        
        response = requests.post(
            f"{self.base_url}/api/chat",
            headers=self.headers,
            json=data
        )
        return response.json()
    
    def get_conversations(self, limit=50):
        """Get conversation history."""
        response = requests.get(
            f"{self.base_url}/api/conversations",
            headers=self.headers,
            params={"limit": limit}
        )
        return response.json()
    
    def add_constitutional_rule(self, rule_data):
        """Add a new constitutional rule."""
        response = requests.post(
            f"{self.base_url}/api/constitution/rules",
            headers=self.headers,
            json=rule_data
        )
        return response.json()
    
    def create_backup(self, backup_type="full", description=""):
        """Create a system backup."""
        data = {
            "backup_type": backup_type,
            "description": description,
            "tags": ["api", "automated"]
        }
        
        response = requests.post(
            f"{self.base_url}/api/backup/create",
            headers=self.headers,
            json=data
        )
        return response.json()

# Usage example
client = SovereignAIClient(api_key="your-api-key")

# Send a message
response = client.send_message("What are the principles of AI ethics?")
print(f"AI Response: {response['response']}")
print(f"Constitutional Status: {'Approved' if response['constitutional_evaluation']['approved'] else 'Blocked'}")

# Create a backup
backup_result = client.create_backup("full", "Daily automated backup")
print(f"Backup created: {backup_result['backup_id']}")
```

### JavaScript SDK Example

```javascript
class SovereignAIClient {
    constructor(baseUrl = 'http://localhost:8003', apiKey = null) {
        this.baseUrl = baseUrl;
        this.headers = {
            'Content-Type': 'application/json'
        };
        if (apiKey) {
            this.headers['X-API-Key'] = apiKey;
        }
    }

    async sendMessage(message, conversationId = null) {
        const data = { message };
        if (conversationId) {
            data.conversation_id = conversationId;
        }

        const response = await fetch(`${this.baseUrl}/api/chat`, {
            method: 'POST',
            headers: this.headers,
            body: JSON.stringify(data)
        });

        return await response.json();
    }

    async getConversations(limit = 50) {
        const response = await fetch(
            `${this.baseUrl}/api/conversations?limit=${limit}`,
            { headers: this.headers }
        );

        return await response.json();
    }

    async addCurationSource(sourceData) {
        const response = await fetch('http://localhost:8002/api/sources', {
            method: 'POST',
            headers: this.headers,
            body: JSON.stringify(sourceData)
        });

        return await response.json();
    }

    async getSystemHealth() {
        const response = await fetch(`${this.baseUrl}/health`, {
            headers: this.headers
        });

        return await response.json();
    }
}

// Usage example
const client = new SovereignAIClient('http://localhost:8003', 'your-api-key');

// Send a message
client.sendMessage('Explain quantum computing in simple terms')
    .then(response => {
        console.log('AI Response:', response.response);
        console.log('Constitutional Status:', 
            response.constitutional_evaluation.approved ? 'Approved' : 'Blocked'
        );
    });

// Add a content source
client.addCurationSource({
    url: 'https://feeds.bbci.co.uk/news/technology/rss.xml',
    source_type: 'rss',
    name: 'BBC Technology News',
    priority: 8,
    scan_interval: 3600
}).then(result => {
    console.log('Source added:', result.source_id);
});
```

### cURL Examples

```bash
# Send a chat message
curl -X POST http://localhost:8003/api/chat \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "message": "What are the latest developments in AI?",
    "conversation_id": "conv_tech_discussion"
  }'

# Add a constitutional rule
curl -X POST http://localhost:8003/api/constitution/rules \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "rule_id": "custom_ethics_rule",
    "name": "Ethics Rule",
    "description": "Ensure ethical AI responses",
    "rule_type": "ethical",
    "priority": "high",
    "conditions": ["unethical", "biased", "discriminatory"],
    "action": "block",
    "enabled": true
  }'

# Add a content source
curl -X POST http://localhost:8002/api/sources \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://feeds.bbci.co.uk/news/technology/rss.xml",
    "source_type": "rss",
    "name": "BBC Technology News",
    "priority": 8,
    "scan_interval": 3600,
    "tags": ["technology", "news", "bbc"]
  }'

# Create a backup
curl -X POST http://localhost:8003/api/backup/create \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "backup_type": "full",
    "description": "Weekly system backup",
    "tags": ["weekly", "automated"]
  }'

# Get system health
curl http://localhost:8003/health

# Get curation statistics
curl http://localhost:8002/api/stats/overview
```

---

**API Documentation Complete**

This comprehensive API documentation covers all endpoints and functionality of the Sovereign AI system. For additional support or questions, please refer to the main [README](README.md) or create an issue in the project repository.

*Sovereign AI - Your AI, Your Rules, Your Data*

