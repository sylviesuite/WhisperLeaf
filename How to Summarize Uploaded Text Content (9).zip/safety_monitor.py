"""
WhisperLeaf Safety Monitor
Real-time monitoring and intervention for emotional safety
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from enum import Enum
import re
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)

class SafetyLevel(Enum):
    """Safety levels for content and interactions"""
    SAFE = "safe"
    CAUTION = "caution"
    WARNING = "warning"
    DANGER = "danger"
    CRITICAL = "critical"

class InterventionType(Enum):
    """Types of safety interventions"""
    NONE = "none"
    GENTLE_REDIRECT = "gentle_redirect"
    SUPPORTIVE_RESPONSE = "supportive_response"
    CRISIS_PROTOCOL = "crisis_protocol"
    EMERGENCY_RESOURCES = "emergency_resources"
    BLOCK_RESPONSE = "block_response"

@dataclass
class SafetyAlert:
    """Safety alert for concerning content or behavior"""
    alert_id: str
    timestamp: datetime
    safety_level: SafetyLevel
    intervention_type: InterventionType
    trigger_content: str
    risk_factors: List[str]
    recommended_response: str
    confidence_score: float
    context: Dict[str, Any]

class SafetyMonitor:
    """
    Real-time safety monitoring system for emotional AI interactions
    Detects concerning content and recommends appropriate interventions
    """
    
    def __init__(self):
        self.crisis_patterns = self._load_crisis_patterns()
        self.safety_keywords = self._load_safety_keywords()
        self.intervention_templates = self._load_intervention_templates()
        
        # Safety monitoring statistics
        self.monitoring_stats = {
            'total_evaluations': 0,
            'safety_alerts': 0,
            'crisis_interventions': 0,
            'false_positives': 0,
            'last_evaluation': None
        }
        
        # Recent alerts for pattern detection
        self.recent_alerts: List[SafetyAlert] = []
        self.max_recent_alerts = 100
        
        logger.info("SafetyMonitor initialized with crisis detection patterns")
    
    def _load_crisis_patterns(self) -> Dict[str, Dict[str, Any]]:
        """Load crisis detection patterns and keywords"""
        return {
            'suicide_ideation': {
                'patterns': [
                    r'(?i)(?:want to|going to|plan to|thinking about).{0,20}(?:kill myself|end my life|suicide)',
                    r'(?i)(?:not worth|no point in|tired of) living',
                    r'(?i)(?:better off|world would be better) without me',
                    r'(?i)(?:can\'t|cannot) go on',
                    r'(?i)(?:end it all|make it stop|permanent solution)'
                ],
                'keywords': [
                    'suicide', 'kill myself', 'end my life', 'want to die',
                    'not worth living', 'better off dead', 'end it all',
                    'permanent solution', 'make the pain stop'
                ],
                'severity': SafetyLevel.CRITICAL,
                'intervention': InterventionType.CRISIS_PROTOCOL
            },
            
            'self_harm': {
                'patterns': [
                    r'(?i)(?:cutting|hurting|harming) myself',
                    r'(?i)(?:want to|going to|thinking about).{0,20}(?:cut|hurt|harm) myself',
                    r'(?i)self.{0,5}(?:harm|injury|mutilation)'
                ],
                'keywords': [
                    'cutting myself', 'self harm', 'hurt myself', 'self injury',
                    'burning myself', 'scratching myself', 'hitting myself'
                ],
                'severity': SafetyLevel.DANGER,
                'intervention': InterventionType.CRISIS_PROTOCOL
            },
            
            'hopelessness': {
                'patterns': [
                    r'(?i)(?:completely|totally|utterly) hopeless',
                    r'(?i)(?:no hope|nothing) left',
                    r'(?i)(?:can\'t|cannot) see.{0,20}(?:way out|future|point)',
                    r'(?i)(?:everything is|life is) pointless'
                ],
                'keywords': [
                    'hopeless', 'no hope', 'pointless', 'meaningless',
                    'no future', 'no way out', 'trapped', 'stuck forever'
                ],
                'severity': SafetyLevel.WARNING,
                'intervention': InterventionType.SUPPORTIVE_RESPONSE
            },
            
            'substance_abuse': {
                'patterns': [
                    r'(?i)(?:overdose|od).{0,20}(?:on|with)',
                    r'(?i)(?:drinking|using).{0,20}(?:too much|heavily|constantly)',
                    r'(?i)(?:can\'t|cannot) stop (?:drinking|using)'
                ],
                'keywords': [
                    'overdose', 'drinking too much', 'using drugs',
                    'can\'t stop drinking', 'addiction', 'substance abuse'
                ],
                'severity': SafetyLevel.WARNING,
                'intervention': InterventionType.SUPPORTIVE_RESPONSE
            },
            
            'isolation': {
                'patterns': [
                    r'(?i)(?:completely|totally) alone',
                    r'(?i)(?:no one|nobody).{0,20}(?:cares|understands|loves me)',
                    r'(?i)(?:isolated|cut off) from everyone'
                ],
                'keywords': [
                    'completely alone', 'nobody cares', 'no one understands',
                    'isolated', 'abandoned', 'rejected by everyone'
                ],
                'severity': SafetyLevel.CAUTION,
                'intervention': InterventionType.GENTLE_REDIRECT
            }
        }
    
    def _load_safety_keywords(self) -> Dict[str, List[str]]:
        """Load safety-related keywords for monitoring"""
        return {
            'crisis_immediate': [
                'suicide', 'kill myself', 'end my life', 'want to die',
                'overdose', 'pills', 'rope', 'bridge', 'gun'
            ],
            'crisis_planning': [
                'plan to', 'going to', 'decided to', 'ready to',
                'tonight', 'tomorrow', 'this weekend', 'soon'
            ],
            'emotional_distress': [
                'hopeless', 'worthless', 'useless', 'burden',
                'trapped', 'stuck', 'can\'t escape', 'no way out'
            ],
            'support_seeking': [
                'help me', 'need someone', 'talk to someone',
                'don\'t know what to do', 'scared', 'confused'
            ],
            'positive_indicators': [
                'getting better', 'feeling hopeful', 'support system',
                'therapy', 'counseling', 'medication helping'
            ]
        }
    
    def _load_intervention_templates(self) -> Dict[InterventionType, Dict[str, Any]]:
        """Load intervention response templates"""
        return {
            InterventionType.CRISIS_PROTOCOL: {
                'immediate_response': "I'm really concerned about you right now. You're not alone, and there are people who want to help. Please reach out to a crisis helpline or emergency services immediately.",
                'resources': [
                    "National Suicide Prevention Lifeline: 988",
                    "Crisis Text Line: Text HOME to 741741",
                    "Emergency Services: 911"
                ],
                'follow_up': "Would you like me to help you find local mental health resources?",
                'tone': 'calm_urgent'
            },
            
            InterventionType.SUPPORTIVE_RESPONSE: {
                'immediate_response': "I hear how much pain you're in right now. These feelings are overwhelming, but they can change. You deserve support and care.",
                'validation': "Your feelings are valid and understandable given what you're going through.",
                'encouragement': "You've shown strength by reaching out and sharing this with me.",
                'resources': [
                    "Consider reaching out to a mental health professional",
                    "Crisis support is available 24/7 if you need it"
                ],
                'tone': 'warm_supportive'
            },
            
            InterventionType.GENTLE_REDIRECT: {
                'immediate_response': "It sounds like you're going through a really difficult time. I'm here to listen and support you.",
                'validation': "These feelings of isolation can be incredibly painful.",
                'suggestion': "Sometimes connecting with others, even in small ways, can help break through that feeling of being alone.",
                'tone': 'gentle_encouraging'
            },
            
            InterventionType.EMERGENCY_RESOURCES: {
                'immediate_response': "This sounds like an emergency situation. Please contact emergency services or a crisis helpline right away.",
                'resources': [
                    "Emergency: 911",
                    "National Suicide Prevention Lifeline: 988",
                    "Crisis Text Line: Text HOME to 741741"
                ],
                'tone': 'calm_directive'
            }
        }
    
    def evaluate_safety(self, message: str, context: Dict[str, Any]) -> SafetyAlert:
        """
        Evaluate message and context for safety concerns
        
        Args:
            message: User message to evaluate
            context: Additional context (mood, emotions, history, etc.)
            
        Returns:
            SafetyAlert with assessment and recommendations
        """
        
        self.monitoring_stats['total_evaluations'] += 1
        self.monitoring_stats['last_evaluation'] = datetime.now()
        
        # Initialize safety assessment
        safety_level = SafetyLevel.SAFE
        intervention_type = InterventionType.NONE
        risk_factors = []
        confidence_score = 0.0
        
        # Check for crisis patterns
        crisis_matches = self._check_crisis_patterns(message)
        
        # Calculate overall severity
        if crisis_matches:
            # Convert SafetyLevel to numeric values for comparison
            severity_values = {
                SafetyLevel.SAFE: 0,
                SafetyLevel.CAUTION: 1,
                SafetyLevel.WARNING: 2,
                SafetyLevel.DANGER: 3,
                SafetyLevel.CRITICAL: 4
            }
            highest_severity_value = max(severity_values[match['severity']] for match in crisis_matches)
            # Convert back to SafetyLevel
            for level, value in severity_values.items():
                if value == highest_severity_value:
                    highest_severity = level
                    break
            else:
                highest_severity = SafetyLevel.WARNING  # fallback
            
            safety_level = highest_severity
            intervention_type = crisis_matches[0]['intervention']
            risk_factors.extend([match['category'] for match in crisis_matches])
            confidence_score = max(match['confidence'] for match in crisis_matches)
        
        # Check contextual risk factors
        contextual_risk = self._assess_contextual_risk(context)
        if contextual_risk['risk_level'] > confidence_score:
            confidence_score = contextual_risk['risk_level']
            risk_factors.extend(contextual_risk['factors'])
        
        # Check for escalation patterns
        escalation_risk = self._check_escalation_patterns(message, context)
        if escalation_risk > 0:
            confidence_score = max(confidence_score, escalation_risk)
            risk_factors.append('escalation_pattern')
        
        # Adjust safety level based on confidence
        if confidence_score >= 0.9:
            safety_level = SafetyLevel.CRITICAL
            intervention_type = InterventionType.CRISIS_PROTOCOL
        elif confidence_score >= 0.7:
            safety_level = SafetyLevel.DANGER
            intervention_type = InterventionType.CRISIS_PROTOCOL
        elif confidence_score >= 0.5:
            safety_level = SafetyLevel.WARNING
            intervention_type = InterventionType.SUPPORTIVE_RESPONSE
        elif confidence_score >= 0.3:
            safety_level = SafetyLevel.CAUTION
            intervention_type = InterventionType.GENTLE_REDIRECT
        
        # Generate recommended response
        recommended_response = self._generate_safety_response(
            safety_level, intervention_type, risk_factors, context
        )
        
        # Create safety alert
        alert = SafetyAlert(
            alert_id=f"safety_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            timestamp=datetime.now(),
            safety_level=safety_level,
            intervention_type=intervention_type,
            trigger_content=message[:200],  # Truncate for privacy
            risk_factors=risk_factors,
            recommended_response=recommended_response,
            confidence_score=confidence_score,
            context=context
        )
        
        # Update statistics
        if safety_level != SafetyLevel.SAFE:
            self.monitoring_stats['safety_alerts'] += 1
            
        if intervention_type == InterventionType.CRISIS_PROTOCOL:
            self.monitoring_stats['crisis_interventions'] += 1
        
        # Store recent alert
        self.recent_alerts.append(alert)
        if len(self.recent_alerts) > self.max_recent_alerts:
            self.recent_alerts.pop(0)
        
        logger.info(f"Safety evaluation: {safety_level.value}, confidence: {confidence_score:.2f}")
        
        return alert
    
    def _check_crisis_patterns(self, message: str) -> List[Dict[str, Any]]:
        """Check message against crisis detection patterns"""
        matches = []
        
        for category, pattern_data in self.crisis_patterns.items():
            # Check regex patterns
            for pattern in pattern_data['patterns']:
                if re.search(pattern, message):
                    matches.append({
                        'category': category,
                        'severity': pattern_data['severity'],
                        'intervention': pattern_data['intervention'],
                        'confidence': 0.9,
                        'match_type': 'pattern'
                    })
                    break
            
            # Check keywords if no pattern match
            if not any(m['category'] == category for m in matches):
                message_lower = message.lower()
                keyword_matches = sum(1 for keyword in pattern_data['keywords'] 
                                    if keyword.lower() in message_lower)
                
                if keyword_matches > 0:
                    confidence = min(0.8, keyword_matches / len(pattern_data['keywords']) + 0.3)
                    matches.append({
                        'category': category,
                        'severity': pattern_data['severity'],
                        'intervention': pattern_data['intervention'],
                        'confidence': confidence,
                        'match_type': 'keyword'
                    })
        
        return sorted(matches, key=lambda x: x['confidence'], reverse=True)
    
    def _assess_contextual_risk(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Assess risk based on contextual factors"""
        risk_factors = []
        risk_level = 0.0
        
        # Check emotional state
        emotions = context.get('emotions', [])
        high_risk_emotions = ['despair', 'hopelessness', 'worthlessness', 'rage']
        emotion_risk = sum(1 for emotion in emotions if emotion in high_risk_emotions)
        if emotion_risk > 0:
            risk_factors.append('high_risk_emotions')
            risk_level += emotion_risk * 0.2
        
        # Check mood
        mood = context.get('mood')
        if mood == 'blue':  # Sadness/depression
            crisis_level = context.get('crisis_level', 'none')
            if crisis_level in ['high', 'critical']:
                risk_factors.append('blue_mood_crisis')
                risk_level += 0.4
            elif crisis_level == 'moderate':
                risk_factors.append('blue_mood_moderate')
                risk_level += 0.2
        
        # Check time patterns (late night messages can indicate crisis)
        current_hour = datetime.now().hour
        if 0 <= current_hour <= 5:  # Late night/early morning
            risk_factors.append('late_night_distress')
            risk_level += 0.1
        
        # Check recent pattern (multiple concerning messages)
        recent_crisis_alerts = sum(1 for alert in self.recent_alerts[-10:] 
                                 if alert.safety_level in [SafetyLevel.WARNING, SafetyLevel.DANGER, SafetyLevel.CRITICAL])
        if recent_crisis_alerts >= 3:
            risk_factors.append('escalating_pattern')
            risk_level += 0.3
        
        return {
            'risk_level': min(1.0, risk_level),
            'factors': risk_factors
        }
    
    def _check_escalation_patterns(self, message: str, context: Dict[str, Any]) -> float:
        """Check for escalation patterns in recent interactions"""
        if len(self.recent_alerts) < 2:
            return 0.0
        
        # Look at recent alerts
        recent_alerts = self.recent_alerts[-5:]  # Last 5 alerts
        
        # Check for increasing severity
        severity_scores = {
            SafetyLevel.SAFE: 0,
            SafetyLevel.CAUTION: 1,
            SafetyLevel.WARNING: 2,
            SafetyLevel.DANGER: 3,
            SafetyLevel.CRITICAL: 4
        }
        
        if len(recent_alerts) >= 3:
            scores = [severity_scores[alert.safety_level] for alert in recent_alerts[-3:]]
            if scores[-1] > scores[0]:  # Escalating severity
                return 0.4
        
        # Check for repeated crisis keywords
        message_lower = message.lower()
        crisis_keywords = self.safety_keywords['crisis_immediate']
        recent_crisis_mentions = sum(1 for alert in recent_alerts 
                                   if any(keyword in alert.trigger_content.lower() 
                                         for keyword in crisis_keywords))
        
        if recent_crisis_mentions >= 2:
            return 0.3
        
        return 0.0
    
    def _generate_safety_response(self, safety_level: SafetyLevel, 
                                intervention_type: InterventionType,
                                risk_factors: List[str],
                                context: Dict[str, Any]) -> str:
        """Generate appropriate safety response based on assessment"""
        
        if intervention_type == InterventionType.NONE:
            return "I'm here to listen and support you."
        
        template = self.intervention_templates.get(intervention_type, {})
        response_parts = []
        
        # Add immediate response
        if 'immediate_response' in template:
            response_parts.append(template['immediate_response'])
        
        # Add validation if appropriate
        if 'validation' in template and safety_level in [SafetyLevel.WARNING, SafetyLevel.DANGER]:
            response_parts.append(template['validation'])
        
        # Add resources for crisis situations
        if 'resources' in template and safety_level in [SafetyLevel.DANGER, SafetyLevel.CRITICAL]:
            resources_text = "Here are some resources that can help:\n" + "\n".join(f"• {resource}" for resource in template['resources'])
            response_parts.append(resources_text)
        
        # Add follow-up if appropriate
        if 'follow_up' in template:
            response_parts.append(template['follow_up'])
        
        return "\n\n".join(response_parts)
    
    def get_recent_alerts(self, hours: int = 24) -> List[SafetyAlert]:
        """Get recent safety alerts within specified time window"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        return [alert for alert in self.recent_alerts if alert.timestamp >= cutoff_time]
    
    def get_safety_statistics(self) -> Dict[str, Any]:
        """Get safety monitoring statistics"""
        recent_24h = self.get_recent_alerts(24)
        
        return {
            'monitoring_stats': self.monitoring_stats,
            'recent_alerts_24h': len(recent_24h),
            'alert_levels_24h': {
                level.value: sum(1 for alert in recent_24h if alert.safety_level == level)
                for level in SafetyLevel
            },
            'intervention_types_24h': {
                intervention.value: sum(1 for alert in recent_24h if alert.intervention_type == intervention)
                for intervention in InterventionType
            },
            'total_stored_alerts': len(self.recent_alerts)
        }
    
    def clear_old_alerts(self, days: int = 7):
        """Clear alerts older than specified days"""
        cutoff_time = datetime.now() - timedelta(days=days)
        self.recent_alerts = [alert for alert in self.recent_alerts if alert.timestamp >= cutoff_time]
        logger.info(f"Cleared old alerts, {len(self.recent_alerts)} alerts remaining")
    
    def is_crisis_situation(self, alert: SafetyAlert) -> bool:
        """Determine if alert represents a crisis situation requiring immediate intervention"""
        return (alert.safety_level in [SafetyLevel.DANGER, SafetyLevel.CRITICAL] or
                alert.intervention_type == InterventionType.CRISIS_PROTOCOL or
                alert.confidence_score >= 0.8)

