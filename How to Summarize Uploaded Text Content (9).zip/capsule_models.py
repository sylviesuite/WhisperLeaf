#!/usr/bin/env python3
"""
Time Capsule Data Models for WhisperLeaf

Defines the data structures for storing and managing time capsules,
emotional snapshots, and future self communications.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Union
from enum import Enum
import json
import uuid

class CapsuleType(Enum):
    """Types of time capsules"""
    EMOTIONAL_SNAPSHOT = "emotional_snapshot"
    MILESTONE_MARKER = "milestone_marker"
    FUTURE_MESSAGE = "future_message"
    INSIGHT_PRESERVATION = "insight_preservation"
    GROWTH_CELEBRATION = "growth_celebration"
    REFLECTION_PROMPT = "reflection_prompt"
    CRISIS_RECOVERY = "crisis_recovery"
    GRATITUDE_MOMENT = "gratitude_moment"

class CapsuleStatus(Enum):
    """Status of time capsules"""
    SEALED = "sealed"           # Capsule is sealed and waiting
    READY = "ready"             # Ready to be opened
    OPENED = "opened"           # Has been opened and viewed
    ARCHIVED = "archived"       # Archived for long-term storage
    SCHEDULED = "scheduled"     # Scheduled for future opening

class EmotionalIntensity(Enum):
    """Emotional intensity levels"""
    VERY_LOW = 0.1
    LOW = 0.3
    MODERATE = 0.5
    HIGH = 0.7
    VERY_HIGH = 0.9

@dataclass
class EmotionalSnapshot:
    """Complete snapshot of emotional state at a moment in time"""
    timestamp: datetime
    mood: str                           # Big Mood color
    emotions: List[str]                 # Specific emotions
    intensity: float                    # 0.0 to 1.0
    context: Dict[str, Any]            # Environmental context
    thoughts: Optional[str] = None      # Current thoughts
    physical_state: Optional[str] = None # Physical sensations
    energy_level: float = 0.5          # 0.0 to 1.0
    stress_level: float = 0.5          # 0.0 to 1.0
    confidence: float = 0.8            # Confidence in assessment
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'timestamp': self.timestamp.isoformat(),
            'mood': self.mood,
            'emotions': self.emotions,
            'intensity': self.intensity,
            'context': self.context,
            'thoughts': self.thoughts,
            'physical_state': self.physical_state,
            'energy_level': self.energy_level,
            'stress_level': self.stress_level,
            'confidence': self.confidence
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EmotionalSnapshot':
        """Create from dictionary"""
        return cls(
            timestamp=datetime.fromisoformat(data['timestamp']),
            mood=data['mood'],
            emotions=data['emotions'],
            intensity=data['intensity'],
            context=data['context'],
            thoughts=data.get('thoughts'),
            physical_state=data.get('physical_state'),
            energy_level=data.get('energy_level', 0.5),
            stress_level=data.get('stress_level', 0.5),
            confidence=data.get('confidence', 0.8)
        )

@dataclass
class FutureMessage:
    """Message to future self"""
    message: str
    sender_emotional_state: EmotionalSnapshot
    intended_recipient_context: Optional[str] = None  # When/why to read this
    advice: Optional[str] = None                      # Specific advice
    encouragement: Optional[str] = None               # Encouraging words
    reminders: List[str] = field(default_factory=list)  # Things to remember
    questions: List[str] = field(default_factory=list)  # Questions for future self
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'message': self.message,
            'sender_emotional_state': self.sender_emotional_state.to_dict(),
            'intended_recipient_context': self.intended_recipient_context,
            'advice': self.advice,
            'encouragement': self.encouragement,
            'reminders': self.reminders,
            'questions': self.questions
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FutureMessage':
        """Create from dictionary"""
        return cls(
            message=data['message'],
            sender_emotional_state=EmotionalSnapshot.from_dict(data['sender_emotional_state']),
            intended_recipient_context=data.get('intended_recipient_context'),
            advice=data.get('advice'),
            encouragement=data.get('encouragement'),
            reminders=data.get('reminders', []),
            questions=data.get('questions', [])
        )

@dataclass
class MilestoneMarker:
    """Marker for significant emotional milestones"""
    milestone_name: str
    description: str
    achievement_type: str               # breakthrough, recovery, growth, etc.
    emotional_journey: List[EmotionalSnapshot]  # Journey to this milestone
    lessons_learned: List[str] = field(default_factory=list)
    gratitude_notes: List[str] = field(default_factory=list)
    future_goals: List[str] = field(default_factory=list)
    celebration_notes: Optional[str] = None
    significance_score: float = 0.5     # 0.0 to 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'milestone_name': self.milestone_name,
            'description': self.description,
            'achievement_type': self.achievement_type,
            'emotional_journey': [snapshot.to_dict() for snapshot in self.emotional_journey],
            'lessons_learned': self.lessons_learned,
            'gratitude_notes': self.gratitude_notes,
            'future_goals': self.future_goals,
            'celebration_notes': self.celebration_notes,
            'significance_score': self.significance_score
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MilestoneMarker':
        """Create from dictionary"""
        return cls(
            milestone_name=data['milestone_name'],
            description=data['description'],
            achievement_type=data['achievement_type'],
            emotional_journey=[EmotionalSnapshot.from_dict(s) for s in data['emotional_journey']],
            lessons_learned=data.get('lessons_learned', []),
            gratitude_notes=data.get('gratitude_notes', []),
            future_goals=data.get('future_goals', []),
            celebration_notes=data.get('celebration_notes'),
            significance_score=data.get('significance_score', 0.5)
        )

@dataclass
class TimeCapsule:
    """Main time capsule container"""
    capsule_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    description: str = ""
    capsule_type: CapsuleType = CapsuleType.EMOTIONAL_SNAPSHOT
    status: CapsuleStatus = CapsuleStatus.SEALED
    
    # Timing
    created_at: datetime = field(default_factory=datetime.now)
    sealed_until: Optional[datetime] = None
    opened_at: Optional[datetime] = None
    
    # Content
    emotional_snapshot: Optional[EmotionalSnapshot] = None
    future_message: Optional[FutureMessage] = None
    milestone_marker: Optional[MilestoneMarker] = None
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    privacy_level: str = "private"      # private, confidential, encrypted
    creator_notes: Optional[str] = None
    opening_conditions: List[str] = field(default_factory=list)  # Conditions for opening
    
    # Analytics
    emotional_significance: float = 0.5  # 0.0 to 1.0
    growth_relevance: float = 0.5       # 0.0 to 1.0
    view_count: int = 0
    last_viewed: Optional[datetime] = None
    
    def is_ready_to_open(self) -> bool:
        """Check if capsule is ready to be opened"""
        if self.status != CapsuleStatus.SEALED:
            return False
        
        if self.sealed_until and datetime.now() < self.sealed_until:
            return False
        
        # Check opening conditions
        # (This would be expanded with actual condition checking)
        return True
    
    def open_capsule(self) -> Dict[str, Any]:
        """Open the time capsule and return contents"""
        if not self.is_ready_to_open():
            raise ValueError("Capsule is not ready to be opened")
        
        self.status = CapsuleStatus.OPENED
        self.opened_at = datetime.now()
        self.view_count += 1
        self.last_viewed = datetime.now()
        
        return self.get_contents()
    
    def get_contents(self) -> Dict[str, Any]:
        """Get capsule contents"""
        contents = {
            'capsule_id': self.capsule_id,
            'title': self.title,
            'description': self.description,
            'capsule_type': self.capsule_type.value,
            'created_at': self.created_at.isoformat(),
            'opened_at': self.opened_at.isoformat() if self.opened_at else None,
            'tags': self.tags,
            'creator_notes': self.creator_notes,
            'emotional_significance': self.emotional_significance,
            'growth_relevance': self.growth_relevance
        }
        
        if self.emotional_snapshot:
            contents['emotional_snapshot'] = self.emotional_snapshot.to_dict()
        
        if self.future_message:
            contents['future_message'] = self.future_message.to_dict()
        
        if self.milestone_marker:
            contents['milestone_marker'] = self.milestone_marker.to_dict()
        
        return contents
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        data = {
            'capsule_id': self.capsule_id,
            'title': self.title,
            'description': self.description,
            'capsule_type': self.capsule_type.value,
            'status': self.status.value,
            'created_at': self.created_at.isoformat(),
            'sealed_until': self.sealed_until.isoformat() if self.sealed_until else None,
            'opened_at': self.opened_at.isoformat() if self.opened_at else None,
            'tags': self.tags,
            'privacy_level': self.privacy_level,
            'creator_notes': self.creator_notes,
            'opening_conditions': self.opening_conditions,
            'emotional_significance': self.emotional_significance,
            'growth_relevance': self.growth_relevance,
            'view_count': self.view_count,
            'last_viewed': self.last_viewed.isoformat() if self.last_viewed else None
        }
        
        if self.emotional_snapshot:
            data['emotional_snapshot'] = self.emotional_snapshot.to_dict()
        
        if self.future_message:
            data['future_message'] = self.future_message.to_dict()
        
        if self.milestone_marker:
            data['milestone_marker'] = self.milestone_marker.to_dict()
        
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TimeCapsule':
        """Create from dictionary"""
        capsule = cls(
            capsule_id=data['capsule_id'],
            title=data['title'],
            description=data['description'],
            capsule_type=CapsuleType(data['capsule_type']),
            status=CapsuleStatus(data['status']),
            created_at=datetime.fromisoformat(data['created_at']),
            sealed_until=datetime.fromisoformat(data['sealed_until']) if data.get('sealed_until') else None,
            opened_at=datetime.fromisoformat(data['opened_at']) if data.get('opened_at') else None,
            tags=data.get('tags', []),
            privacy_level=data.get('privacy_level', 'private'),
            creator_notes=data.get('creator_notes'),
            opening_conditions=data.get('opening_conditions', []),
            emotional_significance=data.get('emotional_significance', 0.5),
            growth_relevance=data.get('growth_relevance', 0.5),
            view_count=data.get('view_count', 0),
            last_viewed=datetime.fromisoformat(data['last_viewed']) if data.get('last_viewed') else None
        )
        
        if 'emotional_snapshot' in data:
            capsule.emotional_snapshot = EmotionalSnapshot.from_dict(data['emotional_snapshot'])
        
        if 'future_message' in data:
            capsule.future_message = FutureMessage.from_dict(data['future_message'])
        
        if 'milestone_marker' in data:
            capsule.milestone_marker = MilestoneMarker.from_dict(data['milestone_marker'])
        
        return capsule

@dataclass
class CapsuleCollection:
    """Collection of related time capsules"""
    collection_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    capsule_ids: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'collection_id': self.collection_id,
            'name': self.name,
            'description': self.description,
            'capsule_ids': self.capsule_ids,
            'created_at': self.created_at.isoformat(),
            'tags': self.tags
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CapsuleCollection':
        """Create from dictionary"""
        return cls(
            collection_id=data['collection_id'],
            name=data['name'],
            description=data['description'],
            capsule_ids=data.get('capsule_ids', []),
            created_at=datetime.fromisoformat(data['created_at']),
            tags=data.get('tags', [])
        )

