"""
Document processing pipeline for text extraction and content preparation.
"""

import os
import mimetypes
from pathlib import Path
from typing import Dict, Any, Optional, List
import hashlib
import re

class DocumentProcessor:
    """Processes various document types and extracts text content."""
    
    def __init__(self):
        self.supported_types = {
            'text/plain': self._process_text,
            'text/markdown': self._process_text,
            'text/html': self._process_html,
            'application/json': self._process_json,
            'text/csv': self._process_csv,
        }
    
    def process_document(self, file_path: str) -> Dict[str, Any]:
        """
        Process a document and extract text content.
        
        Returns:
            Dict containing extracted text, metadata, and processing info
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Detect MIME type
        mime_type, _ = mimetypes.guess_type(str(file_path))
        if not mime_type:
            mime_type = "application/octet-stream"
        
        # Get file stats
        file_stats = file_path.stat()
        file_size = file_stats.st_size
        
        # Calculate file hash
        file_hash = self._calculate_file_hash(file_path)
        
        # Process based on MIME type
        if mime_type in self.supported_types:
            processor = self.supported_types[mime_type]
            content_data = processor(file_path)
        else:
            # Fallback: try to read as text
            try:
                content_data = self._process_text(file_path)
            except UnicodeDecodeError:
                content_data = {
                    "text": "",
                    "error": f"Unsupported file type: {mime_type}",
                    "word_count": 0,
                    "char_count": 0
                }
        
        # Combine all information
        result = {
            "file_path": str(file_path),
            "file_name": file_path.name,
            "file_size": file_size,
            "file_hash": file_hash,
            "mime_type": mime_type,
            "processing_status": "success" if not content_data.get("error") else "error",
            **content_data
        }
        
        return result
    
    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA-256 hash of file."""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()
    
    def _process_text(self, file_path: Path) -> Dict[str, Any]:
        """Process plain text files."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
            
            # Clean and normalize text
            cleaned_text = self._clean_text(text)
            
            return {
                "text": cleaned_text,
                "word_count": len(cleaned_text.split()),
                "char_count": len(cleaned_text),
                "line_count": len(text.splitlines()),
                "encoding": "utf-8"
            }
            
        except UnicodeDecodeError:
            # Try with different encodings
            for encoding in ['latin-1', 'cp1252', 'iso-8859-1']:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        text = f.read()
                    
                    cleaned_text = self._clean_text(text)
                    
                    return {
                        "text": cleaned_text,
                        "word_count": len(cleaned_text.split()),
                        "char_count": len(cleaned_text),
                        "line_count": len(text.splitlines()),
                        "encoding": encoding
                    }
                except UnicodeDecodeError:
                    continue
            
            return {
                "text": "",
                "error": "Could not decode file with any supported encoding",
                "word_count": 0,
                "char_count": 0
            }
    
    def _process_html(self, file_path: Path) -> Dict[str, Any]:
        """Process HTML files and extract text content."""
        try:
            from bs4 import BeautifulSoup
            
            with open(file_path, 'r', encoding='utf-8') as f:
                html_content = f.read()
            
            # Parse HTML and extract text
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Extract text
            text = soup.get_text()
            cleaned_text = self._clean_text(text)
            
            # Extract metadata
            title = soup.find('title')
            title_text = title.get_text().strip() if title else ""
            
            meta_description = soup.find('meta', attrs={'name': 'description'})
            description = meta_description.get('content', '') if meta_description else ""
            
            return {
                "text": cleaned_text,
                "title": title_text,
                "description": description,
                "word_count": len(cleaned_text.split()),
                "char_count": len(cleaned_text),
                "html_tags_removed": True
            }
            
        except ImportError:
            # Fallback: simple HTML tag removal
            with open(file_path, 'r', encoding='utf-8') as f:
                html_content = f.read()
            
            # Simple HTML tag removal
            text = re.sub(r'<[^>]+>', '', html_content)
            cleaned_text = self._clean_text(text)
            
            return {
                "text": cleaned_text,
                "word_count": len(cleaned_text.split()),
                "char_count": len(cleaned_text),
                "html_tags_removed": True,
                "note": "Basic HTML processing (BeautifulSoup not available)"
            }
            
        except Exception as e:
            return {
                "text": "",
                "error": f"Error processing HTML: {str(e)}",
                "word_count": 0,
                "char_count": 0
            }
    
    def _process_json(self, file_path: Path) -> Dict[str, Any]:
        """Process JSON files."""
        try:
            import json
            
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Convert JSON to readable text
            text = self._json_to_text(data)
            cleaned_text = self._clean_text(text)
            
            return {
                "text": cleaned_text,
                "word_count": len(cleaned_text.split()),
                "char_count": len(cleaned_text),
                "json_structure": self._analyze_json_structure(data)
            }
            
        except json.JSONDecodeError as e:
            return {
                "text": "",
                "error": f"Invalid JSON format: {str(e)}",
                "word_count": 0,
                "char_count": 0
            }
        except Exception as e:
            return {
                "text": "",
                "error": f"Error processing JSON: {str(e)}",
                "word_count": 0,
                "char_count": 0
            }
    
    def _process_csv(self, file_path: Path) -> Dict[str, Any]:
        """Process CSV files."""
        try:
            import csv
            
            with open(file_path, 'r', encoding='utf-8') as f:
                # Detect delimiter
                sample = f.read(1024)
                f.seek(0)
                sniffer = csv.Sniffer()
                delimiter = sniffer.sniff(sample).delimiter
                
                # Read CSV
                reader = csv.reader(f, delimiter=delimiter)
                rows = list(reader)
            
            if not rows:
                return {
                    "text": "",
                    "word_count": 0,
                    "char_count": 0,
                    "csv_rows": 0,
                    "csv_columns": 0
                }
            
            # Convert CSV to text
            text_lines = []
            headers = rows[0] if rows else []
            
            # Add headers
            if headers:
                text_lines.append("Headers: " + ", ".join(headers))
            
            # Add data rows (limit to prevent huge text)
            max_rows = 100
            for i, row in enumerate(rows[1:max_rows + 1], 1):
                if len(row) == len(headers):
                    row_text = []
                    for header, value in zip(headers, row):
                        if value.strip():
                            row_text.append(f"{header}: {value}")
                    if row_text:
                        text_lines.append(f"Row {i}: " + "; ".join(row_text))
            
            text = "\n".join(text_lines)
            cleaned_text = self._clean_text(text)
            
            return {
                "text": cleaned_text,
                "word_count": len(cleaned_text.split()),
                "char_count": len(cleaned_text),
                "csv_rows": len(rows),
                "csv_columns": len(headers),
                "csv_delimiter": delimiter
            }
            
        except Exception as e:
            return {
                "text": "",
                "error": f"Error processing CSV: {str(e)}",
                "word_count": 0,
                "char_count": 0
            }
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text content."""
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove control characters except newlines and tabs
        text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text)
        
        # Normalize line endings
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        
        # Remove excessive newlines
        text = re.sub(r'\n\s*\n\s*\n', '\n\n', text)
        
        return text.strip()
    
    def _json_to_text(self, data: Any, prefix: str = "") -> str:
        """Convert JSON data to readable text."""
        lines = []
        
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, (dict, list)):
                    lines.append(f"{prefix}{key}:")
                    lines.append(self._json_to_text(value, prefix + "  "))
                else:
                    lines.append(f"{prefix}{key}: {value}")
        elif isinstance(data, list):
            for i, item in enumerate(data):
                if isinstance(item, (dict, list)):
                    lines.append(f"{prefix}Item {i + 1}:")
                    lines.append(self._json_to_text(item, prefix + "  "))
                else:
                    lines.append(f"{prefix}Item {i + 1}: {item}")
        else:
            lines.append(f"{prefix}{data}")
        
        return "\n".join(lines)
    
    def _analyze_json_structure(self, data: Any) -> Dict[str, Any]:
        """Analyze JSON structure for metadata."""
        if isinstance(data, dict):
            return {
                "type": "object",
                "keys": list(data.keys()),
                "key_count": len(data)
            }
        elif isinstance(data, list):
            return {
                "type": "array",
                "length": len(data),
                "item_types": list(set(type(item).__name__ for item in data))
            }
        else:
            return {
                "type": type(data).__name__,
                "value": str(data)[:100]  # First 100 chars
            }
    
    def get_supported_types(self) -> List[str]:
        """Get list of supported MIME types."""
        return list(self.supported_types.keys())
    
    def is_supported(self, file_path: str) -> bool:
        """Check if a file type is supported."""
        mime_type, _ = mimetypes.guess_type(file_path)
        return mime_type in self.supported_types if mime_type else False

