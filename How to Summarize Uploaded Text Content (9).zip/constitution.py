"""
Constitutional AI Layer - Rule Definition and Governance System.

This module implements a constitutional framework that governs AI behavior
according to user-defined rules, values, and principles.
"""

import json
import logging
from typing import Dict, List, Optional, Any, Union, Tuple
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
import re
import hashlib

class RuleType(Enum):
    """Types of constitutional rules."""
    BEHAVIORAL = "behavioral"      # How the AI should behave
    CONTENT = "content"           # What content is allowed/forbidden
    PRIVACY = "privacy"           # Privacy and data handling rules
    ETHICAL = "ethical"           # Ethical guidelines and principles
    FUNCTIONAL = "functional"     # Functional limitations and capabilities
    CONTEXTUAL = "contextual"     # Context-specific rules

class RulePriority(Enum):
    """Priority levels for constitutional rules."""
    CRITICAL = 1    # Must never be violated
    HIGH = 2        # Should rarely be violated
    MEDIUM = 3      # Can be violated with good reason
    LOW = 4         # Guidelines that can be flexible

class RuleScope(Enum):
    """Scope of rule application."""
    GLOBAL = "global"           # Applies to all interactions
    CONVERSATION = "conversation"  # Applies to current conversation
    CONTEXT = "context"         # Applies to specific contexts
    TEMPORARY = "temporary"     # Temporary rule override

@dataclass
class ConstitutionalRule:
    """Represents a single constitutional rule."""
    id: str
    name: str
    description: str
    rule_type: RuleType
    priority: RulePriority
    scope: RuleScope
    
    # Rule definition
    condition: str  # When this rule applies (natural language or pattern)
    action: str     # What action to take (natural language)
    
    # Rule parameters
    enabled: bool = True
    weight: float = 1.0  # Relative importance within priority level
    
    # Metadata
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    created_by: str = "user"
    tags: List[str] = field(default_factory=list)
    examples: List[str] = field(default_factory=list)
    
    # Usage tracking
    times_applied: int = 0
    times_violated: int = 0
    last_applied: Optional[datetime] = None

@dataclass
class ConstitutionalContext:
    """Context information for constitutional evaluation."""
    user_id: str
    conversation_id: str
    message_content: str
    message_type: str = "text"  # text, image, file, etc.
    
    # Context metadata
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    user_preferences: Dict[str, Any] = field(default_factory=dict)
    conversation_history: List[Dict[str, Any]] = field(default_factory=list)
    
    # Additional context
    source: str = "chat"  # chat, api, automation, etc.
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ConstitutionalDecision:
    """Result of constitutional evaluation."""
    allowed: bool
    confidence: float  # 0.0 to 1.0
    
    # Applied rules
    applied_rules: List[str] = field(default_factory=list)
    violated_rules: List[str] = field(default_factory=list)
    
    # Decision reasoning
    reasoning: str = ""
    suggestions: List[str] = field(default_factory=list)
    
    # Metadata
    decision_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    processing_time_ms: float = 0.0

class ConstitutionalEngine:
    """Core engine for constitutional AI governance."""
    
    def __init__(self, config_file: str = "./data/constitution.json"):
        self.config_file = Path(config_file)
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        
        self.rules: Dict[str, ConstitutionalRule] = {}
        self.rule_patterns: Dict[str, re.Pattern] = {}
        
        # Decision history for learning and auditing
        self.decision_history: List[ConstitutionalDecision] = []
        
        self.logger = logging.getLogger(__name__)
        
        # Load existing constitution
        self.load_constitution()
        
        # Initialize default rules if none exist
        if not self.rules:
            self._create_default_constitution()
    
    def add_rule(self, rule: ConstitutionalRule) -> bool:
        """Add a new constitutional rule."""
        try:
            self.rules[rule.id] = rule
            
            # Compile regex patterns if the condition looks like a pattern
            if self._is_regex_pattern(rule.condition):
                try:
                    self.rule_patterns[rule.id] = re.compile(rule.condition, re.IGNORECASE)
                except re.error as e:
                    self.logger.warning(f"Invalid regex pattern in rule {rule.id}: {e}")
            
            self.save_constitution()
            self.logger.info(f"Added constitutional rule: {rule.name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding rule {rule.id}: {e}")
            return False
    
    def remove_rule(self, rule_id: str) -> bool:
        """Remove a constitutional rule."""
        if rule_id in self.rules:
            rule_name = self.rules[rule_id].name
            del self.rules[rule_id]
            
            if rule_id in self.rule_patterns:
                del self.rule_patterns[rule_id]
            
            self.save_constitution()
            self.logger.info(f"Removed constitutional rule: {rule_name}")
            return True
        return False
    
    def update_rule(self, rule_id: str, **kwargs) -> bool:
        """Update an existing constitutional rule."""
        if rule_id not in self.rules:
            return False
        
        rule = self.rules[rule_id]
        
        # Update allowed fields
        for key, value in kwargs.items():
            if hasattr(rule, key):
                if key == 'rule_type' and isinstance(value, str):
                    rule.rule_type = RuleType(value)
                elif key == 'priority' and isinstance(value, str):
                    rule.priority = RulePriority(value)
                elif key == 'scope' and isinstance(value, str):
                    rule.scope = RuleScope(value)
                else:
                    setattr(rule, key, value)
        
        # Update regex pattern if condition changed
        if 'condition' in kwargs:
            if self._is_regex_pattern(rule.condition):
                try:
                    self.rule_patterns[rule_id] = re.compile(rule.condition, re.IGNORECASE)
                except re.error as e:
                    self.logger.warning(f"Invalid regex pattern in rule {rule_id}: {e}")
            elif rule_id in self.rule_patterns:
                del self.rule_patterns[rule_id]
        
        self.save_constitution()
        self.logger.info(f"Updated constitutional rule: {rule.name}")
        return True
    
    def evaluate_message(self, context: ConstitutionalContext) -> ConstitutionalDecision:
        """Evaluate a message against the constitutional rules."""
        start_time = datetime.now()
        
        decision = ConstitutionalDecision(
            allowed=True,
            confidence=1.0
        )
        
        # Get applicable rules
        applicable_rules = self._get_applicable_rules(context)
        
        # Evaluate each rule
        rule_results = []
        for rule in applicable_rules:
            result = self._evaluate_rule(rule, context)
            rule_results.append((rule, result))
            
            if result['applies']:
                decision.applied_rules.append(rule.id)
                
                if not result['satisfied']:
                    decision.violated_rules.append(rule.id)
                    
                    # Critical and high priority violations block the message
                    if rule.priority in [RulePriority.CRITICAL, RulePriority.HIGH]:
                        decision.allowed = False
                        decision.confidence = min(decision.confidence, 0.1)
                    else:
                        # Medium and low priority violations reduce confidence
                        decision.confidence *= 0.7
        
        # Generate reasoning
        decision.reasoning = self._generate_reasoning(rule_results, decision)
        
        # Generate suggestions if message is blocked
        if not decision.allowed:
            decision.suggestions = self._generate_suggestions(rule_results, context)
        
        # Update rule usage statistics
        self._update_rule_statistics(rule_results)
        
        # Calculate processing time
        end_time = datetime.now()
        decision.processing_time_ms = (end_time - start_time).total_seconds() * 1000
        
        # Store decision in history
        self.decision_history.append(decision)
        
        # Keep only recent decisions (last 1000)
        if len(self.decision_history) > 1000:
            self.decision_history = self.decision_history[-1000:]
        
        return decision
    
    def get_rule(self, rule_id: str) -> Optional[ConstitutionalRule]:
        """Get a specific rule."""
        return self.rules.get(rule_id)
    
    def list_rules(self, rule_type: Optional[RuleType] = None, 
                   enabled_only: bool = True) -> List[ConstitutionalRule]:
        """List constitutional rules."""
        rules = list(self.rules.values())
        
        if rule_type:
            rules = [r for r in rules if r.rule_type == rule_type]
        
        if enabled_only:
            rules = [r for r in rules if r.enabled]
        
        # Sort by priority and weight
        rules.sort(key=lambda r: (r.priority.value, -r.weight))
        return rules
    
    def get_constitution_stats(self) -> Dict[str, Any]:
        """Get statistics about the constitution."""
        total_rules = len(self.rules)
        enabled_rules = len([r for r in self.rules.values() if r.enabled])
        
        rule_types = {}
        priorities = {}
        
        for rule in self.rules.values():
            rule_types[rule.rule_type.value] = rule_types.get(rule.rule_type.value, 0) + 1
            priorities[rule.priority.value] = priorities.get(rule.priority.value, 0) + 1
        
        recent_decisions = len([d for d in self.decision_history 
                              if (datetime.now(timezone.utc) - d.decision_time).days < 7])
        
        blocked_messages = len([d for d in self.decision_history if not d.allowed])
        
        return {
            'total_rules': total_rules,
            'enabled_rules': enabled_rules,
            'rule_types': rule_types,
            'priorities': priorities,
            'recent_decisions': recent_decisions,
            'blocked_messages': blocked_messages,
            'block_rate': blocked_messages / len(self.decision_history) if self.decision_history else 0
        }
    
    def _get_applicable_rules(self, context: ConstitutionalContext) -> List[ConstitutionalRule]:
        """Get rules that apply to the given context."""
        applicable_rules = []
        
        for rule in self.rules.values():
            if not rule.enabled:
                continue
            
            # Check scope
            if rule.scope == RuleScope.GLOBAL:
                applicable_rules.append(rule)
            elif rule.scope == RuleScope.CONVERSATION:
                # Always applicable in conversation context
                applicable_rules.append(rule)
            elif rule.scope == RuleScope.CONTEXT:
                # Check if context matches (simplified)
                if self._context_matches_rule(context, rule):
                    applicable_rules.append(rule)
            elif rule.scope == RuleScope.TEMPORARY:
                # Check if temporary rule is still valid
                if self._temporary_rule_valid(rule):
                    applicable_rules.append(rule)
        
        return applicable_rules
    
    def _evaluate_rule(self, rule: ConstitutionalRule, context: ConstitutionalContext) -> Dict[str, Any]:
        """Evaluate a single rule against the context."""
        result = {
            'applies': False,
            'satisfied': True,
            'confidence': 1.0,
            'reason': ''
        }
        
        # Check if rule applies to this message
        if rule.id in self.rule_patterns:
            # Use regex pattern matching
            pattern = self.rule_patterns[rule.id]
            if pattern.search(context.message_content):
                result['applies'] = True
                result['satisfied'] = False  # Pattern match means violation for most rules
                result['reason'] = f"Message matches pattern: {rule.condition}"
        else:
            # Use natural language condition evaluation (simplified)
            if self._evaluate_natural_language_condition(rule.condition, context):
                result['applies'] = True
                result['satisfied'] = self._evaluate_natural_language_action(rule.action, context)
                result['reason'] = f"Rule condition met: {rule.condition}"
        
        return result
    
    def _evaluate_natural_language_condition(self, condition: str, context: ConstitutionalContext) -> bool:
        """Evaluate a natural language condition (simplified implementation)."""
        condition_lower = condition.lower()
        message_lower = context.message_content.lower()
        
        # Simple keyword-based evaluation
        if 'contains' in condition_lower:
            # Extract what should be contained
            parts = condition_lower.split('contains')
            if len(parts) > 1:
                keyword = parts[1].strip().strip('"\'')
                return keyword in message_lower
        
        if 'personal information' in condition_lower:
            personal_keywords = ['password', 'ssn', 'social security', 'credit card', 'bank account', 'address', 'phone number']
            return any(keyword in message_lower for keyword in personal_keywords)
        
        if 'harmful content' in condition_lower:
            harmful_keywords = ['hack', 'attack', 'harm', 'damage', 'illegal', 'violence', 'dangerous']
            return any(keyword in message_lower for keyword in harmful_keywords)
        
        if 'asks for assistance' in condition_lower:
            help_indicators = ['help', 'assist', 'can you', 'please', 'how to', 'explain', 'tell me']
            return any(indicator in message_lower for indicator in help_indicators)
        
        if 'asks for information' in condition_lower:
            info_indicators = ['what', 'how', 'when', 'where', 'why', 'who', 'explain', 'tell me about']
            return any(indicator in message_lower for indicator in info_indicators)
        
        # Default: don't trigger unless specific patterns match
        return False
    
    def _evaluate_natural_language_action(self, action: str, context: ConstitutionalContext) -> bool:
        """Evaluate if a natural language action should be satisfied."""
        action_lower = action.lower()
        
        # For helpful behavior, allow if it's a legitimate request
        if 'provide helpful' in action_lower or 'provide accurate' in action_lower:
            return True
        
        # For privacy protection, block if personal info is requested
        if 'refuse to process' in action_lower and 'personal information' in action_lower:
            personal_keywords = ['password', 'ssn', 'social security', 'credit card', 'bank account']
            return not any(keyword in context.message_content.lower() for keyword in personal_keywords)
        
        # For harmful content, block if harmful keywords present
        if 'refuse' in action_lower and 'harmful' in action_lower:
            harmful_keywords = ['hack', 'attack', 'harm', 'damage', 'illegal', 'violence']
            return not any(keyword in context.message_content.lower() for keyword in harmful_keywords)
        
        # Most actions are permissive unless explicitly blocking
        if 'refuse' in action_lower or 'deny' in action_lower or 'block' in action_lower:
            return False
        
        # Default to satisfied (allow the action)
        return True
    
    def _generate_reasoning(self, rule_results: List[Tuple[ConstitutionalRule, Dict]], 
                          decision: ConstitutionalDecision) -> str:
        """Generate human-readable reasoning for the decision."""
        if decision.allowed:
            if not decision.applied_rules:
                return "No constitutional rules were triggered by this message."
            else:
                return f"Message allowed. Applied {len(decision.applied_rules)} constitutional rules with no violations."
        else:
            violated_rules = [rule for rule, result in rule_results 
                            if result['applies'] and not result['satisfied']]
            
            if violated_rules:
                rule_names = [rule.name for rule in violated_rules]
                return f"Message blocked due to violations of: {', '.join(rule_names)}"
            else:
                return "Message blocked by constitutional evaluation."
    
    def _generate_suggestions(self, rule_results: List[Tuple[ConstitutionalRule, Dict]], 
                            context: ConstitutionalContext) -> List[str]:
        """Generate suggestions for improving a blocked message."""
        suggestions = []
        
        for rule, result in rule_results:
            if result['applies'] and not result['satisfied']:
                if rule.rule_type == RuleType.CONTENT:
                    suggestions.append(f"Remove or rephrase content that violates: {rule.name}")
                elif rule.rule_type == RuleType.PRIVACY:
                    suggestions.append("Avoid sharing personal or sensitive information")
                elif rule.rule_type == RuleType.BEHAVIORAL:
                    suggestions.append(f"Adjust your request to align with: {rule.description}")
                elif rule.rule_type == RuleType.ETHICAL:
                    suggestions.append("Consider the ethical implications of your request")
        
        if not suggestions:
            suggestions.append("Please rephrase your message to comply with constitutional guidelines")
        
        return suggestions
    
    def _update_rule_statistics(self, rule_results: List[Tuple[ConstitutionalRule, Dict]]):
        """Update usage statistics for rules."""
        for rule, result in rule_results:
            if result['applies']:
                rule.times_applied += 1
                rule.last_applied = datetime.now(timezone.utc)
                
                if not result['satisfied']:
                    rule.times_violated += 1
    
    def _context_matches_rule(self, context: ConstitutionalContext, rule: ConstitutionalRule) -> bool:
        """Check if context matches a context-specific rule."""
        # Simplified implementation - could be expanded with more sophisticated matching
        return True
    
    def _temporary_rule_valid(self, rule: ConstitutionalRule) -> bool:
        """Check if a temporary rule is still valid."""
        # Simplified implementation - could check expiration times, etc.
        return True
    
    def _is_regex_pattern(self, condition: str) -> bool:
        """Check if a condition string looks like a regex pattern."""
        regex_indicators = ['.*', '\\d', '\\w', '\\s', '[', ']', '(', ')', '|', '^', '$']
        return any(indicator in condition for indicator in regex_indicators)
    
    def _create_default_constitution(self):
        """Create a default set of constitutional rules."""
        default_rules = [
            ConstitutionalRule(
                id="privacy_protection",
                name="Privacy Protection",
                description="Protect user privacy and personal information",
                rule_type=RuleType.PRIVACY,
                priority=RulePriority.CRITICAL,
                scope=RuleScope.GLOBAL,
                condition="message contains personal information requests",
                action="refuse to process or store personal information",
                tags=["privacy", "security"],
                examples=["Don't ask for passwords", "Don't store personal data"]
            ),
            ConstitutionalRule(
                id="helpful_behavior",
                name="Helpful Behavior",
                description="Always strive to be helpful and constructive",
                rule_type=RuleType.BEHAVIORAL,
                priority=RulePriority.HIGH,
                scope=RuleScope.GLOBAL,
                condition="user asks for assistance",
                action="provide helpful and accurate information",
                tags=["behavior", "helpfulness"],
                examples=["Answer questions clearly", "Provide useful suggestions"]
            ),
            ConstitutionalRule(
                id="no_harmful_content",
                name="No Harmful Content",
                description="Refuse to generate harmful or dangerous content",
                rule_type=RuleType.CONTENT,
                priority=RulePriority.CRITICAL,
                scope=RuleScope.GLOBAL,
                condition="message requests harmful content",
                action="refuse and explain why the request is problematic",
                tags=["safety", "content"],
                examples=["No violence", "No illegal activities", "No dangerous instructions"]
            ),
            ConstitutionalRule(
                id="truthfulness",
                name="Truthfulness",
                description="Always provide accurate and truthful information",
                rule_type=RuleType.ETHICAL,
                priority=RulePriority.HIGH,
                scope=RuleScope.GLOBAL,
                condition="user asks for information",
                action="provide accurate information or acknowledge uncertainty",
                tags=["ethics", "accuracy"],
                examples=["Don't make up facts", "Acknowledge when uncertain"]
            ),
            ConstitutionalRule(
                id="respect_autonomy",
                name="Respect User Autonomy",
                description="Respect user's right to make their own decisions",
                rule_type=RuleType.ETHICAL,
                priority=RulePriority.MEDIUM,
                scope=RuleScope.GLOBAL,
                condition="user makes a decision",
                action="support user autonomy while providing relevant information",
                tags=["ethics", "autonomy"],
                examples=["Don't be overly prescriptive", "Provide options"]
            )
        ]
        
        for rule in default_rules:
            self.add_rule(rule)
        
        self.logger.info(f"Created default constitution with {len(default_rules)} rules")
    
    def save_constitution(self):
        """Save the constitution to file."""
        try:
            constitution_data = {
                'rules': {
                    rule_id: {
                        **asdict(rule),
                        'rule_type': rule.rule_type.value,
                        'priority': rule.priority.value,
                        'scope': rule.scope.value,
                        'created_at': rule.created_at.isoformat(),
                        'last_applied': rule.last_applied.isoformat() if rule.last_applied else None
                    }
                    for rule_id, rule in self.rules.items()
                },
                'metadata': {
                    'version': '1.0',
                    'last_updated': datetime.now(timezone.utc).isoformat(),
                    'total_rules': len(self.rules)
                }
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(constitution_data, f, indent=2)
                
        except Exception as e:
            self.logger.error(f"Error saving constitution: {e}")
    
    def load_constitution(self):
        """Load the constitution from file."""
        try:
            if not self.config_file.exists():
                return
            
            with open(self.config_file, 'r') as f:
                constitution_data = json.load(f)
            
            # Load rules
            rules_data = constitution_data.get('rules', {})
            for rule_id, rule_data in rules_data.items():
                # Parse datetime fields
                rule_data['created_at'] = datetime.fromisoformat(rule_data['created_at'])
                if rule_data.get('last_applied'):
                    rule_data['last_applied'] = datetime.fromisoformat(rule_data['last_applied'])
                
                # Parse enums
                rule_data['rule_type'] = RuleType(rule_data['rule_type'])
                rule_data['priority'] = RulePriority(rule_data['priority'])
                rule_data['scope'] = RuleScope(rule_data['scope'])
                
                self.rules[rule_id] = ConstitutionalRule(**rule_data)
                
                # Compile regex patterns
                if self._is_regex_pattern(self.rules[rule_id].condition):
                    try:
                        self.rule_patterns[rule_id] = re.compile(
                            self.rules[rule_id].condition, re.IGNORECASE
                        )
                    except re.error as e:
                        self.logger.warning(f"Invalid regex pattern in rule {rule_id}: {e}")
            
            self.logger.info(f"Loaded {len(self.rules)} constitutional rules")
            
        except Exception as e:
            self.logger.error(f"Error loading constitution: {e}")

