"""
WhisperLeaf Mood Timeline Data Models
Data structures for tracking emotional states over time
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass, field
import json

class TimelineGranularity(Enum):
    """Granularity levels for timeline analysis"""
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    YEARLY = "yearly"

class MoodTrend(Enum):
    """Mood trend directions"""
    IMPROVING = "improving"
    STABLE = "stable"
    DECLINING = "declining"
    VOLATILE = "volatile"
    UNKNOWN = "unknown"

class PatternType(Enum):
    """Types of emotional patterns"""
    DAILY_CYCLE = "daily_cycle"
    WEEKLY_CYCLE = "weekly_cycle"
    SEASONAL = "seasonal"
    TRIGGER_BASED = "trigger_based"
    STRESS_RESPONSE = "stress_response"
    GROWTH_PHASE = "growth_phase"
    CRISIS_PATTERN = "crisis_pattern"

@dataclass
class MoodEntry:
    """A single mood entry in the timeline"""
    entry_id: str
    timestamp: datetime
    mood: str  # Big Mood color: blue, green, yellow, purple, red
    intensity: float  # 0.0 to 1.0
    emotions: List[str]
    context: Dict[str, Any]
    notes: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    source: str = "manual"  # manual, journal, conversation, prompt_response
    confidence: float = 1.0  # How confident we are in this mood assessment
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'entry_id': self.entry_id,
            'timestamp': self.timestamp.isoformat(),
            'mood': self.mood,
            'intensity': self.intensity,
            'emotions': self.emotions,
            'context': self.context,
            'notes': self.notes,
            'tags': self.tags,
            'source': self.source,
            'confidence': self.confidence
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MoodEntry':
        """Create from dictionary"""
        return cls(
            entry_id=data['entry_id'],
            timestamp=datetime.fromisoformat(data['timestamp']),
            mood=data['mood'],
            intensity=data['intensity'],
            emotions=data['emotions'],
            context=data['context'],
            notes=data.get('notes'),
            tags=data.get('tags', []),
            source=data.get('source', 'manual'),
            confidence=data.get('confidence', 1.0)
        )

@dataclass
class MoodPattern:
    """An identified emotional pattern"""
    pattern_id: str
    pattern_type: PatternType
    name: str
    description: str
    start_date: datetime
    end_date: Optional[datetime]
    frequency: str  # daily, weekly, monthly, etc.
    strength: float  # 0.0 to 1.0 - how strong/consistent the pattern is
    mood_sequence: List[str]  # sequence of moods in the pattern
    triggers: List[str]
    context_factors: Dict[str, Any]
    confidence: float
    examples: List[str]  # entry_ids that exemplify this pattern
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'pattern_id': self.pattern_id,
            'pattern_type': self.pattern_type.value,
            'name': self.name,
            'description': self.description,
            'start_date': self.start_date.isoformat(),
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'frequency': self.frequency,
            'strength': self.strength,
            'mood_sequence': self.mood_sequence,
            'triggers': self.triggers,
            'context_factors': self.context_factors,
            'confidence': self.confidence,
            'examples': self.examples
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MoodPattern':
        """Create from dictionary"""
        return cls(
            pattern_id=data['pattern_id'],
            pattern_type=PatternType(data['pattern_type']),
            name=data['name'],
            description=data['description'],
            start_date=datetime.fromisoformat(data['start_date']),
            end_date=datetime.fromisoformat(data['end_date']) if data['end_date'] else None,
            frequency=data['frequency'],
            strength=data['strength'],
            mood_sequence=data['mood_sequence'],
            triggers=data['triggers'],
            context_factors=data['context_factors'],
            confidence=data['confidence'],
            examples=data['examples']
        )

@dataclass
class TimelineSummary:
    """Summary statistics for a time period"""
    period_start: datetime
    period_end: datetime
    granularity: TimelineGranularity
    total_entries: int
    mood_distribution: Dict[str, int]  # mood -> count
    average_intensity: float
    dominant_mood: str
    mood_trend: MoodTrend
    volatility_score: float  # 0.0 to 1.0 - how much mood varies
    growth_indicators: List[str]
    challenges_identified: List[str]
    patterns_detected: List[str]  # pattern_ids
    notable_events: List[Dict[str, Any]]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'period_start': self.period_start.isoformat(),
            'period_end': self.period_end.isoformat(),
            'granularity': self.granularity.value,
            'total_entries': self.total_entries,
            'mood_distribution': self.mood_distribution,
            'average_intensity': self.average_intensity,
            'dominant_mood': self.dominant_mood,
            'mood_trend': self.mood_trend.value,
            'volatility_score': self.volatility_score,
            'growth_indicators': self.growth_indicators,
            'challenges_identified': self.challenges_identified,
            'patterns_detected': self.patterns_detected,
            'notable_events': self.notable_events
        }

@dataclass
class GrowthMetric:
    """Tracks specific aspects of emotional growth"""
    metric_id: str
    name: str
    description: str
    category: str  # emotional_regulation, self_awareness, resilience, etc.
    baseline_value: float
    current_value: float
    target_value: Optional[float]
    measurement_unit: str
    tracking_period: timedelta
    last_updated: datetime
    trend: MoodTrend
    milestones: List[Dict[str, Any]]
    
    def calculate_progress(self) -> float:
        """Calculate progress as percentage"""
        if self.target_value is None:
            return 0.0
        
        if self.target_value == self.baseline_value:
            return 100.0 if self.current_value == self.target_value else 0.0
        
        progress = (self.current_value - self.baseline_value) / (self.target_value - self.baseline_value)
        return max(0.0, min(100.0, progress * 100))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'metric_id': self.metric_id,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'baseline_value': self.baseline_value,
            'current_value': self.current_value,
            'target_value': self.target_value,
            'measurement_unit': self.measurement_unit,
            'tracking_period': self.tracking_period.total_seconds(),
            'last_updated': self.last_updated.isoformat(),
            'trend': self.trend.value,
            'milestones': self.milestones
        }

@dataclass
class EmotionalInsight:
    """An insight derived from timeline analysis"""
    insight_id: str
    timestamp: datetime
    category: str  # pattern, growth, warning, celebration, etc.
    title: str
    description: str
    confidence: float
    supporting_data: Dict[str, Any]
    actionable_suggestions: List[str]
    related_patterns: List[str]  # pattern_ids
    priority: str  # low, medium, high, urgent
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'insight_id': self.insight_id,
            'timestamp': self.timestamp.isoformat(),
            'category': self.category,
            'title': self.title,
            'description': self.description,
            'confidence': self.confidence,
            'supporting_data': self.supporting_data,
            'actionable_suggestions': self.actionable_suggestions,
            'related_patterns': self.related_patterns,
            'priority': self.priority
        }

@dataclass
class TimelineVisualization:
    """Data structure for timeline visualization"""
    visualization_id: str
    title: str
    chart_type: str  # line, bar, heatmap, scatter, etc.
    time_range: Tuple[datetime, datetime]
    granularity: TimelineGranularity
    data_points: List[Dict[str, Any]]
    annotations: List[Dict[str, Any]]  # Notable events, patterns, etc.
    styling: Dict[str, Any]  # Colors, themes, etc.
    interactive_elements: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for visualization"""
        return {
            'visualization_id': self.visualization_id,
            'title': self.title,
            'chart_type': self.chart_type,
            'time_range': [self.time_range[0].isoformat(), self.time_range[1].isoformat()],
            'granularity': self.granularity.value,
            'data_points': self.data_points,
            'annotations': self.annotations,
            'styling': self.styling,
            'interactive_elements': self.interactive_elements
        }

