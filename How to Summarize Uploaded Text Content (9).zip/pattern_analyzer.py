"""
WhisperLeaf Advanced Pattern Analysis Engine
Sophisticated emotional pattern recognition and analysis
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from collections import defaultdict, Counter
from dataclasses import dataclass
import logging
import statistics
from enum import Enum

logger = logging.getLogger(__name__)

class PatternComplexity(Enum):
    """Pattern complexity levels"""
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"
    HIGHLY_COMPLEX = "highly_complex"

class PatternStability(Enum):
    """Pattern stability levels"""
    UNSTABLE = "unstable"
    SOMEWHAT_STABLE = "somewhat_stable"
    STABLE = "stable"
    HIGHLY_STABLE = "highly_stable"

@dataclass
class PatternSignature:
    """Unique signature for pattern identification"""
    signature_id: str
    pattern_type: str
    key_features: Dict[str, Any]
    frequency_profile: Dict[str, float]
    stability_score: float
    complexity: PatternComplexity
    confidence: float

@dataclass
class EmotionalCycle:
    """Represents a complete emotional cycle"""
    cycle_id: str
    start_time: datetime
    end_time: datetime
    phases: List[Dict[str, Any]]
    dominant_emotions: List[str]
    intensity_curve: List[float]
    triggers: List[str]
    resolution_patterns: List[str]
    cycle_health_score: float

@dataclass
class PatternPrediction:
    """Prediction of future emotional patterns"""
    prediction_id: str
    predicted_pattern: str
    probability: float
    time_window: Tuple[datetime, datetime]
    confidence_interval: Tuple[float, float]
    influencing_factors: List[str]
    recommended_actions: List[str]
    risk_level: str

class AdvancedPatternAnalyzer:
    """
    Advanced pattern recognition engine for emotional data
    """
    
    def __init__(self):
        self.pattern_signatures = {}
        self.emotional_cycles = {}
        self.pattern_predictions = {}
        
        # Analysis parameters
        self.min_pattern_occurrences = 3
        self.pattern_confidence_threshold = 0.6
        self.cycle_detection_window = timedelta(days=7)
        self.prediction_horizon = timedelta(days=14)
        
        # Pattern analysis cache
        self.analysis_cache = {}
        self.cache_expiry = {}
        
        logger.info("AdvancedPatternAnalyzer initialized")
    
    def analyze_complex_patterns(self, mood_entries: List[Any]) -> Dict[str, Any]:
        """Analyze complex emotional patterns from mood entries"""
        
        if len(mood_entries) < 10:
            return {
                'patterns_found': [],
                'cycles_detected': [],
                'predictions': [],
                'analysis_summary': 'Insufficient data for complex pattern analysis'
            }
        
        # Convert to DataFrame for analysis
        df = self._entries_to_dataframe(mood_entries)
        
        # Detect various pattern types
        temporal_patterns = self._detect_temporal_patterns(df)
        contextual_patterns = self._detect_contextual_patterns(df)
        emotional_cycles = self._detect_emotional_cycles(df)
        transition_patterns = self._detect_transition_patterns(df)
        
        # Generate pattern signatures
        signatures = self._generate_pattern_signatures(
            temporal_patterns + contextual_patterns + transition_patterns
        )
        
        # Create predictions
        predictions = self._generate_pattern_predictions(df, signatures)
        
        # Analyze pattern stability
        stability_analysis = self._analyze_pattern_stability(df, signatures)
        
        return {
            'patterns_found': temporal_patterns + contextual_patterns + transition_patterns,
            'cycles_detected': emotional_cycles,
            'predictions': predictions,
            'pattern_signatures': signatures,
            'stability_analysis': stability_analysis,
            'analysis_summary': f'Analyzed {len(mood_entries)} entries, found {len(signatures)} unique patterns'
        }
    
    def _entries_to_dataframe(self, mood_entries: List[Any]) -> pd.DataFrame:
        """Convert mood entries to pandas DataFrame for analysis"""
        
        data = []
        for entry in mood_entries:
            row = {
                'timestamp': entry.timestamp,
                'mood': entry.mood,
                'intensity': entry.intensity,
                'emotions': ','.join(entry.emotions),
                'hour': entry.timestamp.hour,
                'day_of_week': entry.timestamp.weekday(),
                'day_of_month': entry.timestamp.day,
                'month': entry.timestamp.month,
                'source': entry.source,
                'confidence': entry.confidence
            }
            
            # Add context fields
            for key, value in entry.context.items():
                row[f'context_{key}'] = str(value)
            
            # Add emotion flags
            for emotion in ['happy', 'sad', 'angry', 'anxious', 'calm', 'excited', 'frustrated']:
                row[f'emotion_{emotion}'] = emotion in entry.emotions
            
            data.append(row)
        
        df = pd.DataFrame(data)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        return df
    
    def _detect_temporal_patterns(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """Detect time-based patterns"""
        patterns = []
        
        # Hourly patterns
        hourly_mood = df.groupby('hour')['mood'].apply(lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else 'unknown')
        hourly_intensity = df.groupby('hour')['intensity'].mean()
        
        # Find consistent hourly patterns
        hour_consistency = {}
        for hour in range(24):
            if hour in hourly_mood.index:
                hour_entries = df[df['hour'] == hour]
                if len(hour_entries) >= 3:
                    mood_consistency = (hour_entries['mood'] == hourly_mood[hour]).mean()
                    if mood_consistency >= 0.7:
                        hour_consistency[hour] = {
                            'mood': hourly_mood[hour],
                            'intensity': hourly_intensity[hour],
                            'consistency': mood_consistency
                        }
        
        if len(hour_consistency) >= 3:
            patterns.append({
                'type': 'hourly_pattern',
                'name': 'Daily Emotional Rhythm',
                'description': f'Consistent emotional patterns across {len(hour_consistency)} hours of the day',
                'strength': np.mean([h['consistency'] for h in hour_consistency.values()]),
                'details': hour_consistency,
                'complexity': PatternComplexity.MODERATE,
                'stability': self._calculate_pattern_stability(hour_consistency)
            })
        
        # Weekly patterns
        weekly_mood = df.groupby('day_of_week')['mood'].apply(lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else 'unknown')
        weekly_intensity = df.groupby('day_of_week')['intensity'].mean()
        
        week_consistency = {}
        for day in range(7):
            if day in weekly_mood.index:
                day_entries = df[df['day_of_week'] == day]
                if len(day_entries) >= 2:
                    mood_consistency = (day_entries['mood'] == weekly_mood[day]).mean()
                    if mood_consistency >= 0.6:
                        week_consistency[day] = {
                            'mood': weekly_mood[day],
                            'intensity': weekly_intensity[day],
                            'consistency': mood_consistency
                        }
        
        if len(week_consistency) >= 4:
            patterns.append({
                'type': 'weekly_pattern',
                'name': 'Weekly Emotional Cycle',
                'description': f'Consistent emotional patterns across {len(week_consistency)} days of the week',
                'strength': np.mean([d['consistency'] for d in week_consistency.values()]),
                'details': week_consistency,
                'complexity': PatternComplexity.MODERATE,
                'stability': self._calculate_pattern_stability(week_consistency)
            })
        
        # Monthly patterns (if enough data)
        if len(df) >= 30:
            monthly_mood = df.groupby('month')['mood'].apply(lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else 'unknown')
            monthly_intensity = df.groupby('month')['intensity'].mean()
            
            month_consistency = {}
            for month in monthly_mood.index:
                month_entries = df[df['month'] == month]
                if len(month_entries) >= 5:
                    mood_consistency = (month_entries['mood'] == monthly_mood[month]).mean()
                    if mood_consistency >= 0.5:
                        month_consistency[month] = {
                            'mood': monthly_mood[month],
                            'intensity': monthly_intensity[month],
                            'consistency': mood_consistency
                        }
            
            if len(month_consistency) >= 2:
                patterns.append({
                    'type': 'seasonal_pattern',
                    'name': 'Seasonal Emotional Pattern',
                    'description': f'Seasonal emotional variations across {len(month_consistency)} months',
                    'strength': np.mean([m['consistency'] for m in month_consistency.values()]),
                    'details': month_consistency,
                    'complexity': PatternComplexity.COMPLEX,
                    'stability': self._calculate_pattern_stability(month_consistency)
                })
        
        return patterns
    
    def _detect_contextual_patterns(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """Detect context-based patterns"""
        patterns = []
        
        # Find context columns
        context_columns = [col for col in df.columns if col.startswith('context_')]
        
        for context_col in context_columns:
            if df[context_col].nunique() > 1 and df[context_col].nunique() < len(df) * 0.8:
                # Analyze mood patterns by context
                context_mood = df.groupby(context_col)['mood'].apply(lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else 'unknown')
                context_intensity = df.groupby(context_col)['intensity'].mean()
                
                context_patterns = {}
                for context_value in context_mood.index:
                    if pd.notna(context_value) and context_value != 'nan':
                        context_entries = df[df[context_col] == context_value]
                        if len(context_entries) >= 3:
                            mood_consistency = (context_entries['mood'] == context_mood[context_value]).mean()
                            if mood_consistency >= 0.7:
                                context_patterns[context_value] = {
                                    'mood': context_mood[context_value],
                                    'intensity': context_intensity[context_value],
                                    'consistency': mood_consistency,
                                    'frequency': len(context_entries)
                                }
                
                if len(context_patterns) >= 2:
                    context_name = context_col.replace('context_', '').replace('_', ' ').title()
                    patterns.append({
                        'type': 'contextual_pattern',
                        'name': f'{context_name} Emotional Pattern',
                        'description': f'Emotional patterns related to {context_name.lower()}',
                        'strength': np.mean([p['consistency'] for p in context_patterns.values()]),
                        'details': context_patterns,
                        'context_factor': context_col,
                        'complexity': PatternComplexity.SIMPLE if len(context_patterns) <= 3 else PatternComplexity.MODERATE,
                        'stability': self._calculate_pattern_stability(context_patterns)
                    })
        
        return patterns
    
    def _detect_emotional_cycles(self, df: pd.DataFrame) -> List[EmotionalCycle]:
        """Detect complete emotional cycles"""
        cycles = []
        
        if len(df) < 7:
            return cycles
        
        # Look for mood transitions that form cycles
        df['mood_change'] = df['mood'] != df['mood'].shift(1)
        df['intensity_change'] = df['intensity'].diff()
        
        # Find potential cycle starts (significant mood or intensity changes)
        cycle_starts = df[
            (df['mood_change'] == True) | 
            (abs(df['intensity_change']) > 0.3)
        ].index.tolist()
        
        for i, start_idx in enumerate(cycle_starts[:-1]):
            end_idx = cycle_starts[i + 1] if i + 1 < len(cycle_starts) else len(df) - 1
            cycle_data = df.iloc[start_idx:end_idx + 1]
            
            if len(cycle_data) >= 3:  # Minimum cycle length
                cycle_duration = cycle_data.iloc[-1]['timestamp'] - cycle_data.iloc[0]['timestamp']
                
                if timedelta(hours=6) <= cycle_duration <= timedelta(days=7):
                    # Analyze cycle phases
                    phases = self._analyze_cycle_phases(cycle_data)
                    
                    # Calculate cycle health score
                    health_score = self._calculate_cycle_health(cycle_data)
                    
                    cycle = EmotionalCycle(
                        cycle_id=f"cycle_{start_idx}_{end_idx}",
                        start_time=cycle_data.iloc[0]['timestamp'],
                        end_time=cycle_data.iloc[-1]['timestamp'],
                        phases=phases,
                        dominant_emotions=cycle_data['mood'].mode().tolist(),
                        intensity_curve=cycle_data['intensity'].tolist(),
                        triggers=self._identify_cycle_triggers(cycle_data),
                        resolution_patterns=self._identify_resolution_patterns(cycle_data),
                        cycle_health_score=health_score
                    )
                    
                    cycles.append(cycle)
        
        return cycles
    
    def _detect_transition_patterns(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """Detect mood transition patterns"""
        patterns = []
        
        if len(df) < 5:
            return patterns
        
        # Create transition pairs
        transitions = []
        for i in range(len(df) - 1):
            current_mood = df.iloc[i]['mood']
            next_mood = df.iloc[i + 1]['mood']
            time_diff = (df.iloc[i + 1]['timestamp'] - df.iloc[i]['timestamp']).total_seconds() / 3600  # hours
            
            if current_mood != next_mood and time_diff <= 24:  # Within 24 hours
                transitions.append({
                    'from_mood': current_mood,
                    'to_mood': next_mood,
                    'time_diff': time_diff,
                    'intensity_change': df.iloc[i + 1]['intensity'] - df.iloc[i]['intensity'],
                    'context': df.iloc[i + 1].get('context_activity', 'unknown')
                })
        
        if len(transitions) >= 5:
            # Analyze common transitions
            transition_counts = Counter([(t['from_mood'], t['to_mood']) for t in transitions])
            common_transitions = {k: v for k, v in transition_counts.items() if v >= 2}
            
            if common_transitions:
                # Analyze transition characteristics
                transition_analysis = {}
                for (from_mood, to_mood), count in common_transitions.items():
                    relevant_transitions = [t for t in transitions 
                                         if t['from_mood'] == from_mood and t['to_mood'] == to_mood]
                    
                    avg_time = np.mean([t['time_diff'] for t in relevant_transitions])
                    avg_intensity_change = np.mean([t['intensity_change'] for t in relevant_transitions])
                    
                    transition_analysis[f"{from_mood}_to_{to_mood}"] = {
                        'frequency': count,
                        'avg_transition_time': avg_time,
                        'avg_intensity_change': avg_intensity_change,
                        'probability': count / len(transitions)
                    }
                
                patterns.append({
                    'type': 'transition_pattern',
                    'name': 'Mood Transition Patterns',
                    'description': f'Common emotional transitions with {len(common_transitions)} recurring patterns',
                    'strength': np.mean([t['probability'] for t in transition_analysis.values()]),
                    'details': transition_analysis,
                    'complexity': PatternComplexity.MODERATE,
                    'stability': PatternStability.STABLE if len(common_transitions) >= 3 else PatternStability.SOMEWHAT_STABLE
                })
        
        return patterns
    
    def _analyze_cycle_phases(self, cycle_data: pd.DataFrame) -> List[Dict[str, Any]]:
        """Analyze phases within an emotional cycle"""
        phases = []
        
        # Simple phase detection based on intensity changes
        intensity_values = cycle_data['intensity'].values
        
        # Find local minima and maxima
        peaks = []
        valleys = []
        
        for i in range(1, len(intensity_values) - 1):
            if intensity_values[i] > intensity_values[i-1] and intensity_values[i] > intensity_values[i+1]:
                peaks.append(i)
            elif intensity_values[i] < intensity_values[i-1] and intensity_values[i] < intensity_values[i+1]:
                valleys.append(i)
        
        # Create phases based on peaks and valleys
        phase_boundaries = sorted(peaks + valleys)
        
        if not phase_boundaries:
            # Single phase
            phases.append({
                'phase_name': 'stable',
                'start_time': cycle_data.iloc[0]['timestamp'],
                'end_time': cycle_data.iloc[-1]['timestamp'],
                'dominant_mood': cycle_data['mood'].mode().iloc[0],
                'avg_intensity': cycle_data['intensity'].mean(),
                'phase_type': 'stable'
            })
        else:
            # Multiple phases
            prev_boundary = 0
            for i, boundary in enumerate(phase_boundaries + [len(cycle_data) - 1]):
                phase_data = cycle_data.iloc[prev_boundary:boundary + 1]
                
                if len(phase_data) > 0:
                    phase_type = 'rising' if boundary in peaks else 'falling' if boundary in valleys else 'stable'
                    
                    phases.append({
                        'phase_name': f'phase_{i+1}',
                        'start_time': phase_data.iloc[0]['timestamp'],
                        'end_time': phase_data.iloc[-1]['timestamp'],
                        'dominant_mood': phase_data['mood'].mode().iloc[0] if len(phase_data['mood'].mode()) > 0 else 'unknown',
                        'avg_intensity': phase_data['intensity'].mean(),
                        'phase_type': phase_type
                    })
                
                prev_boundary = boundary
        
        return phases
    
    def _calculate_cycle_health(self, cycle_data: pd.DataFrame) -> float:
        """Calculate health score for an emotional cycle"""
        
        # Factors that contribute to cycle health:
        # 1. Intensity stability (not too volatile)
        # 2. Presence of positive emotions
        # 3. Resolution (ending in better state than start)
        # 4. Duration appropriateness
        
        intensity_stability = 1.0 - min(1.0, cycle_data['intensity'].std())
        
        positive_emotions = ['happy', 'calm', 'peaceful', 'content', 'grateful']
        positive_ratio = sum(1 for emotion in cycle_data['emotions'].str.split(',').sum() 
                           if emotion.strip() in positive_emotions) / len(cycle_data)
        
        resolution_score = max(0, cycle_data.iloc[-1]['intensity'] - cycle_data.iloc[0]['intensity'])
        
        duration = (cycle_data.iloc[-1]['timestamp'] - cycle_data.iloc[0]['timestamp']).total_seconds() / 3600
        duration_score = 1.0 if 6 <= duration <= 48 else 0.5  # Optimal duration 6-48 hours
        
        health_score = (intensity_stability * 0.3 + positive_ratio * 0.3 + 
                       resolution_score * 0.2 + duration_score * 0.2)
        
        return min(1.0, health_score)
    
    def _identify_cycle_triggers(self, cycle_data: pd.DataFrame) -> List[str]:
        """Identify triggers that started the emotional cycle"""
        triggers = []
        
        # Look at context at cycle start
        start_context = cycle_data.iloc[0]
        
        context_cols = [col for col in cycle_data.columns if col.startswith('context_')]
        for col in context_cols:
            value = start_context[col]
            if pd.notna(value) and value != 'unknown':
                triggers.append(f"{col.replace('context_', '')}: {value}")
        
        # Look for significant events (high intensity changes)
        if len(cycle_data) > 1:
            intensity_change = abs(cycle_data.iloc[1]['intensity'] - cycle_data.iloc[0]['intensity'])
            if intensity_change > 0.3:
                triggers.append(f"significant_intensity_change: {intensity_change:.2f}")
        
        return triggers
    
    def _identify_resolution_patterns(self, cycle_data: pd.DataFrame) -> List[str]:
        """Identify how the emotional cycle resolved"""
        patterns = []
        
        start_intensity = cycle_data.iloc[0]['intensity']
        end_intensity = cycle_data.iloc[-1]['intensity']
        
        if end_intensity > start_intensity + 0.2:
            patterns.append("positive_resolution")
        elif end_intensity < start_intensity - 0.2:
            patterns.append("negative_resolution")
        else:
            patterns.append("neutral_resolution")
        
        # Check for mood improvement
        start_mood = cycle_data.iloc[0]['mood']
        end_mood = cycle_data.iloc[-1]['mood']
        
        positive_moods = ['green', 'purple']
        negative_moods = ['blue', 'red', 'yellow']
        
        if start_mood in negative_moods and end_mood in positive_moods:
            patterns.append("mood_improvement")
        elif start_mood in positive_moods and end_mood in negative_moods:
            patterns.append("mood_decline")
        
        return patterns
    
    def _generate_pattern_signatures(self, patterns: List[Dict[str, Any]]) -> List[PatternSignature]:
        """Generate unique signatures for detected patterns"""
        signatures = []
        
        for i, pattern in enumerate(patterns):
            signature = PatternSignature(
                signature_id=f"sig_{pattern['type']}_{i}",
                pattern_type=pattern['type'],
                key_features={
                    'strength': pattern['strength'],
                    'complexity': pattern['complexity'].value,
                    'details_count': len(pattern.get('details', {}))
                },
                frequency_profile=self._calculate_frequency_profile(pattern),
                stability_score=self._extract_stability_score(pattern),
                complexity=pattern['complexity'],
                confidence=pattern['strength']
            )
            signatures.append(signature)
        
        return signatures
    
    def _calculate_frequency_profile(self, pattern: Dict[str, Any]) -> Dict[str, float]:
        """Calculate frequency profile for a pattern"""
        profile = {}
        
        if 'details' in pattern:
            details = pattern['details']
            if isinstance(details, dict):
                for key, value in details.items():
                    if isinstance(value, dict) and 'frequency' in value:
                        profile[str(key)] = float(value['frequency'])
                    elif isinstance(value, dict) and 'consistency' in value:
                        profile[str(key)] = float(value['consistency'])
        
        return profile
    
    def _extract_stability_score(self, pattern: Dict[str, Any]) -> float:
        """Extract stability score from pattern"""
        if 'stability' in pattern:
            if isinstance(pattern['stability'], PatternStability):
                stability_map = {
                    PatternStability.UNSTABLE: 0.2,
                    PatternStability.SOMEWHAT_STABLE: 0.5,
                    PatternStability.STABLE: 0.8,
                    PatternStability.HIGHLY_STABLE: 1.0
                }
                return stability_map[pattern['stability']]
        
        return pattern.get('strength', 0.5)
    
    def _generate_pattern_predictions(self, df: pd.DataFrame, signatures: List[PatternSignature]) -> List[PatternPrediction]:
        """Generate predictions based on detected patterns"""
        predictions = []
        
        if len(df) < 7:
            return predictions
        
        current_time = df['timestamp'].max()
        
        for signature in signatures:
            if signature.confidence >= self.pattern_confidence_threshold:
                # Predict when this pattern might occur next
                prediction_time = current_time + timedelta(days=1)  # Simple prediction
                
                prediction = PatternPrediction(
                    prediction_id=f"pred_{signature.signature_id}",
                    predicted_pattern=signature.pattern_type,
                    probability=signature.confidence * 0.8,  # Reduce confidence for prediction
                    time_window=(prediction_time, prediction_time + timedelta(hours=6)),
                    confidence_interval=(signature.confidence - 0.2, signature.confidence),
                    influencing_factors=list(signature.key_features.keys()),
                    recommended_actions=self._generate_recommendations(signature),
                    risk_level=self._assess_risk_level(signature)
                )
                predictions.append(prediction)
        
        return predictions
    
    def _generate_recommendations(self, signature: PatternSignature) -> List[str]:
        """Generate recommendations based on pattern signature"""
        recommendations = []
        
        if signature.pattern_type == 'hourly_pattern':
            recommendations.append("Consider adjusting daily routine to optimize emotional well-being")
            recommendations.append("Pay attention to activities during emotionally challenging hours")
        
        elif signature.pattern_type == 'weekly_pattern':
            recommendations.append("Plan supportive activities for emotionally difficult days")
            recommendations.append("Leverage emotionally positive days for important tasks")
        
        elif signature.pattern_type == 'contextual_pattern':
            recommendations.append("Be mindful of environmental factors that influence your mood")
            recommendations.append("Consider modifying contexts that consistently lead to negative emotions")
        
        elif signature.pattern_type == 'transition_pattern':
            recommendations.append("Develop strategies to manage common mood transitions")
            recommendations.append("Practice grounding techniques during difficult transitions")
        
        return recommendations
    
    def _assess_risk_level(self, signature: PatternSignature) -> str:
        """Assess risk level of a pattern"""
        
        if signature.confidence < 0.3:
            return "low"
        elif signature.confidence < 0.6:
            return "medium"
        elif signature.confidence < 0.8:
            return "high"
        else:
            return "very_high"
    
    def _analyze_pattern_stability(self, df: pd.DataFrame, signatures: List[PatternSignature]) -> Dict[str, Any]:
        """Analyze overall pattern stability"""
        
        if not signatures:
            return {
                'overall_stability': 'unknown',
                'stability_score': 0.0,
                'stable_patterns': 0,
                'unstable_patterns': 0
            }
        
        stability_scores = [sig.stability_score for sig in signatures]
        overall_stability_score = np.mean(stability_scores)
        
        stable_count = sum(1 for score in stability_scores if score >= 0.7)
        unstable_count = sum(1 for score in stability_scores if score < 0.4)
        
        if overall_stability_score >= 0.8:
            overall_stability = 'highly_stable'
        elif overall_stability_score >= 0.6:
            overall_stability = 'stable'
        elif overall_stability_score >= 0.4:
            overall_stability = 'somewhat_stable'
        else:
            overall_stability = 'unstable'
        
        return {
            'overall_stability': overall_stability,
            'stability_score': overall_stability_score,
            'stable_patterns': stable_count,
            'unstable_patterns': unstable_count,
            'pattern_count': len(signatures),
            'stability_distribution': {
                'highly_stable': sum(1 for s in stability_scores if s >= 0.8),
                'stable': sum(1 for s in stability_scores if 0.6 <= s < 0.8),
                'somewhat_stable': sum(1 for s in stability_scores if 0.4 <= s < 0.6),
                'unstable': sum(1 for s in stability_scores if s < 0.4)
            }
        }
    
    def _calculate_pattern_stability(self, pattern_data: Dict[str, Any]) -> PatternStability:
        """Calculate stability level for a pattern"""
        
        if not pattern_data:
            return PatternStability.UNSTABLE
        
        # Calculate consistency scores
        consistency_scores = []
        for item in pattern_data.values():
            if isinstance(item, dict) and 'consistency' in item:
                consistency_scores.append(item['consistency'])
        
        if not consistency_scores:
            return PatternStability.UNSTABLE
        
        avg_consistency = np.mean(consistency_scores)
        
        if avg_consistency >= 0.9:
            return PatternStability.HIGHLY_STABLE
        elif avg_consistency >= 0.7:
            return PatternStability.STABLE
        elif avg_consistency >= 0.5:
            return PatternStability.SOMEWHAT_STABLE
        else:
            return PatternStability.UNSTABLE
    
    def get_pattern_insights(self, analysis_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate insights from pattern analysis results"""
        insights = []
        
        patterns = analysis_results.get('patterns_found', [])
        cycles = analysis_results.get('cycles_detected', [])
        predictions = analysis_results.get('predictions', [])
        stability = analysis_results.get('stability_analysis', {})
        
        # Pattern insights
        if patterns:
            strong_patterns = [p for p in patterns if p['strength'] >= 0.7]
            if strong_patterns:
                insights.append({
                    'type': 'pattern_strength',
                    'title': 'Strong Emotional Patterns Detected',
                    'description': f'Found {len(strong_patterns)} strong emotional patterns that could guide daily planning',
                    'priority': 'high',
                    'actionable': True,
                    'patterns': [p['name'] for p in strong_patterns]
                })
        
        # Cycle insights
        if cycles:
            healthy_cycles = [c for c in cycles if c.cycle_health_score >= 0.7]
            unhealthy_cycles = [c for c in cycles if c.cycle_health_score < 0.4]
            
            if healthy_cycles:
                insights.append({
                    'type': 'healthy_cycles',
                    'title': 'Healthy Emotional Cycles',
                    'description': f'Identified {len(healthy_cycles)} healthy emotional cycles showing good emotional regulation',
                    'priority': 'medium',
                    'actionable': False,
                    'celebration': True
                })
            
            if unhealthy_cycles:
                insights.append({
                    'type': 'concerning_cycles',
                    'title': 'Concerning Emotional Cycles',
                    'description': f'Found {len(unhealthy_cycles)} cycles that may need attention or support',
                    'priority': 'high',
                    'actionable': True,
                    'support_needed': True
                })
        
        # Stability insights
        if stability:
            overall_stability = stability.get('overall_stability', 'unknown')
            if overall_stability in ['stable', 'highly_stable']:
                insights.append({
                    'type': 'emotional_stability',
                    'title': 'Good Emotional Stability',
                    'description': f'Your emotional patterns show {overall_stability} characteristics',
                    'priority': 'low',
                    'actionable': False,
                    'celebration': True
                })
            elif overall_stability == 'unstable':
                insights.append({
                    'type': 'emotional_instability',
                    'title': 'Emotional Pattern Instability',
                    'description': 'Your emotional patterns show some instability that might benefit from support',
                    'priority': 'high',
                    'actionable': True,
                    'support_needed': True
                })
        
        # Prediction insights
        high_confidence_predictions = [p for p in predictions if p.probability >= 0.7]
        if high_confidence_predictions:
            insights.append({
                'type': 'pattern_predictions',
                'title': 'Predictable Emotional Patterns',
                'description': f'Found {len(high_confidence_predictions)} highly predictable patterns for proactive planning',
                'priority': 'medium',
                'actionable': True,
                'predictions': [p.predicted_pattern for p in high_confidence_predictions]
            })
        
        return insights

