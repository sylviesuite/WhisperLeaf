# Sovereign AI - Level 3 Personal AI System

**A complete, self-hosted AI system with constitutional governance, automated curation, and enterprise-grade backup capabilities.**

---

## Table of Contents

1. [Overview](#overview)
2. [System Architecture](#system-architecture)
3. [Key Features](#key-features)
4. [Quick Start Guide](#quick-start-guide)
5. [Installation](#installation)
6. [Configuration](#configuration)
7. [Usage Guide](#usage-guide)
8. [API Documentation](#api-documentation)
9. [System Administration](#system-administration)
10. [Backup and Recovery](#backup-and-recovery)
11. [Troubleshooting](#troubleshooting)
12. [Development](#development)
13. [Contributing](#contributing)
14. [License](#license)

---

## Overview

Sovereign AI is a Level 3 personal AI system designed to provide complete user control over AI behavior, data, and privacy. Unlike cloud-based AI services, Sovereign AI runs entirely on your local infrastructure, ensuring data sovereignty and constitutional governance of AI behavior.

### What Makes Sovereign AI Different

**Constitutional Governance**: Every AI interaction is governed by user-defined constitutional principles, ensuring the AI operates according to your values and requirements.

**Complete Data Sovereignty**: All data, conversations, and AI processing remain on your local infrastructure. No data is sent to external services.

**Automated Content Curation**: Intelligent content discovery and filtering from trusted sources, with user-controlled quality assessment and relevance scoring.

**Enterprise-Grade Backup**: Comprehensive backup and recovery system with point-in-time recovery, system snapshots, and automated retention policies.

**Modern Web Interface**: Professional React-based chat interface with real-time constitutional feedback and comprehensive system monitoring.

### System Requirements

- **Operating System**: Ubuntu 22.04 or compatible Linux distribution
- **Memory**: Minimum 4GB RAM (8GB recommended)
- **Storage**: 10GB available disk space
- **Network**: Internet connection for initial setup and content curation
- **Python**: 3.11 or higher
- **Node.js**: 20.18 or higher

---

## System Architecture

Sovereign AI consists of five integrated components:

### 1. Constitutional AI Layer
- **Rule Definition System**: Define behavioral, content, privacy, ethical, and functional rules
- **AI Governance Engine**: Real-time evaluation of messages and responses
- **Priority-Based Rules**: Critical, High, Medium, and Low priority rule enforcement
- **Context-Aware Evaluation**: Global, conversation-specific, and contextual rule application

### 2. Custom Chat Application
- **React Frontend**: Modern, responsive web interface
- **Real-Time Messaging**: Instant message exchange with constitutional feedback
- **Conversation History**: Complete conversation tracking with metadata
- **Constitutional Transparency**: Visual indicators for approved/blocked messages

### 3. Automated Curation Engine
- **RSS Feed Processing**: Automated content discovery from trusted sources
- **Web Scraping Framework**: Intelligent content extraction with rate limiting
- **Content Filtering**: Multi-metric quality assessment and relevance scoring
- **Source Management**: Priority-based source management with performance tracking

### 4. Time Capsule Backup System
- **Automated Backups**: Full and incremental backups with intelligent compression
- **Point-in-Time Recovery**: Sophisticated recovery planning with risk assessment
- **System Snapshots**: Lightweight system state capture and rollback
- **Recovery Management**: Multi-step recovery workflows with progress tracking

### 5. Core Data Management
- **Document Vault**: Secure document storage with encryption and validation
- **Vector Database**: Semantic search capabilities with ChromaDB integration
- **Conversation Storage**: Complete conversation history with constitutional metadata
- **Configuration Management**: Centralized system configuration and settings

---

## Key Features

### Constitutional AI Governance
- **5 Default Constitutional Rules**: Privacy protection, helpful behavior, safety, truthfulness, and user autonomy
- **Custom Rule Definition**: Create rules in natural language with pattern matching
- **Real-Time Evaluation**: Sub-millisecond rule evaluation with confidence scoring
- **Response Modification**: Automatic response modification for constitutional violations
- **Comprehensive Audit Trail**: Complete logging of all constitutional decisions

### Intelligent Content Curation
- **Multi-Source Support**: RSS feeds, web pages, and extensible architecture
- **Quality Assessment**: Multi-metric analysis including readability and structure
- **Relevance Scoring**: User interest-based scoring with keyword matching
- **Duplicate Detection**: Hash-based exact and similarity-based near-duplicate detection
- **Automated Scheduling**: Configurable scan intervals with priority-based processing

### Enterprise Backup and Recovery
- **Compression Efficiency**: 64-67% compression ratio with tar.gz archives
- **Integrity Verification**: SHA-256 checksums with automatic verification
- **Recovery Planning**: Intelligent recovery plans with risk assessment and duration estimation
- **Automated Retention**: Configurable retention policies with automatic cleanup
- **Performance Monitoring**: Comprehensive statistics and system health tracking

### Modern Web Interface
- **Responsive Design**: Works perfectly on desktop and mobile devices
- **Real-Time Feedback**: Instant constitutional evaluation with visual indicators
- **Professional UI**: Clean, modern interface with proper accessibility
- **Performance Metrics**: Real-time display of processing times and confidence scores
- **System Monitoring**: Comprehensive system status and health monitoring

---

## Quick Start Guide

### 1. System Startup

```bash
# Start all services
cd sovereign_ai

# Activate Python environment
source venv/bin/activate

# Start chat API server
python chat_api.py &

# Start curation API server  
python curation_api.py &

# Start React application
cd sovereign-chat
pnpm run dev --host &
```

### 2. Access the System

- **Chat Interface**: http://localhost:5174
- **Chat API**: http://localhost:8003
- **Curation API**: http://localhost:8002

### 3. Basic Usage

1. **Chat with AI**: Open the web interface and start a conversation
2. **Monitor Constitutional Governance**: Watch real-time constitutional evaluation
3. **Add Content Sources**: Use the curation API to add RSS feeds or web sources
4. **Create Backups**: Use the time capsule system for automated backups
5. **Review System Health**: Monitor all components through the web interface

---

## Installation

### Prerequisites

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install required system packages
sudo apt install -y python3.11 python3.11-venv python3-pip nodejs npm curl git

# Install pnpm for React application
npm install -g pnpm

# Install Ollama for local AI models
curl -fsSL https://ollama.ai/install.sh | sh
```

### System Installation

```bash
# Clone or extract the Sovereign AI system
cd /path/to/sovereign_ai

# Create Python virtual environment
python3.11 -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt

# Install React dependencies
cd sovereign-chat
pnpm install
cd ..

# Download AI model
ollama pull tinyllama

# Initialize system databases
python -c "
from api_server.database import init_database
from time_capsule.backup_system import TimeCapsuleBackupSystem
from time_capsule.recovery_manager import RecoveryManager

init_database()
backup_system = TimeCapsuleBackupSystem()
recovery_manager = RecoveryManager(backup_system)
print('Databases initialized successfully')
"
```

### Configuration

```bash
# Copy configuration templates
cp config/config.yaml.template config/config.yaml
cp .env.template .env

# Edit configuration files
nano config/config.yaml
nano .env
```

---

## Configuration

### System Configuration (`config/config.yaml`)

```yaml
# System Settings
system:
  name: "Sovereign AI"
  version: "1.0.0"
  environment: "production"

# AI Model Configuration
ai:
  model: "tinyllama"
  temperature: 0.7
  max_tokens: 2048
  timeout: 30

# Constitutional AI Settings
constitutional:
  default_rules_enabled: true
  rule_evaluation_timeout: 1000  # milliseconds
  confidence_threshold: 0.8
  audit_logging: true

# Curation Settings
curation:
  max_sources: 100
  default_scan_interval: 3600  # seconds
  content_retention_days: 30
  quality_threshold: 0.6

# Backup Settings
backup:
  retention_days: 30
  max_backups: 100
  compression_level: 6
  automated_backups: true
  backup_schedule:
    full_backup: "0 2 * * *"      # Daily at 2 AM
    incremental: "0 */6 * * *"    # Every 6 hours

# API Settings
api:
  chat_port: 8003
  curation_port: 8002
  cors_enabled: true
  rate_limiting: true
  max_requests_per_minute: 60

# Web Interface Settings
web:
  port: 5174
  host: "0.0.0.0"
  development_mode: false
```

### Environment Variables (`.env`)

```bash
# AI Model Configuration
OLLAMA_HOST=http://localhost:11434
AI_MODEL=tinyllama

# Database Configuration
DATABASE_URL=sqlite:///./sovereign_ai.db
BACKUP_DATABASE_URL=sqlite:///./time_capsule/metadata/backup_metadata.db

# Security Settings
SECRET_KEY=your-secret-key-here
ENCRYPTION_KEY=your-encryption-key-here

# Logging Configuration
LOG_LEVEL=INFO
LOG_FILE=./logs/sovereign_ai.log

# External Services (Optional)
OPENAI_API_KEY=your-openai-key-if-needed
OPENAI_API_BASE=https://api.openai.com/v1
```

### Constitutional Rules Configuration

Create custom constitutional rules in `data/constitution.json`:

```json
{
  "rules": {
    "privacy_protection": {
      "name": "Privacy Protection",
      "description": "Protect user privacy and personal information",
      "rule_type": "privacy",
      "priority": "critical",
      "conditions": [
        "password",
        "social security",
        "credit card",
        "personal information"
      ],
      "action": "block",
      "response_template": "I cannot help with requests involving personal or sensitive information."
    },
    "helpful_behavior": {
      "name": "Helpful Behavior",
      "description": "Provide helpful and constructive assistance",
      "rule_type": "behavioral",
      "priority": "high",
      "conditions": ["help", "assist", "support"],
      "action": "encourage",
      "response_template": "I'm here to help you with that."
    }
  },
  "metadata": {
    "version": "1.0",
    "last_updated": "2025-07-19T18:00:00Z",
    "total_rules": 2
  }
}
```

---

## Usage Guide

### Starting the System

1. **Start Core Services**:
   ```bash
   cd sovereign_ai
   source venv/bin/activate
   
   # Start Ollama service
   sudo systemctl start ollama
   
   # Start API servers
   python chat_api.py &
   python curation_api.py &
   
   # Start web interface
   cd sovereign-chat
   pnpm run dev --host &
   ```

2. **Verify System Health**:
   ```bash
   # Check API health
   curl http://localhost:8003/health
   curl http://localhost:8002/health
   
   # Check web interface
   curl http://localhost:5174
   ```

### Using the Chat Interface

1. **Access the Interface**: Open http://localhost:5174 in your web browser

2. **Start a Conversation**: Type a message and press Enter

3. **Monitor Constitutional Governance**: 
   - Green badges indicate approved messages
   - Red badges indicate blocked messages
   - Confidence scores show system certainty
   - Processing times display system performance

4. **Review Conversation History**: All conversations are automatically saved with constitutional metadata

### Managing Content Curation

1. **Add RSS Sources**:
   ```bash
   curl -X POST http://localhost:8002/api/sources \
     -H "Content-Type: application/json" \
     -d '{
       "url": "https://feeds.bbci.co.uk/news/rss.xml",
       "source_type": "rss",
       "priority": 8,
       "scan_interval": 3600
     }'
   ```

2. **Add Web Sources**:
   ```bash
   curl -X POST http://localhost:8002/api/sources \
     -H "Content-Type: application/json" \
     -d '{
       "url": "https://example.com/news",
       "source_type": "web",
       "priority": 6,
       "scan_interval": 7200
     }'
   ```

3. **Manual Content Scan**:
   ```bash
   curl -X POST http://localhost:8002/api/scan/manual
   ```

4. **View Curation Statistics**:
   ```bash
   curl http://localhost:8002/api/stats/overview
   ```

### Backup and Recovery Operations

1. **Create Manual Backup**:
   ```python
   from time_capsule.backup_system import TimeCapsuleBackupSystem
   
   backup_system = TimeCapsuleBackupSystem()
   backup_id = backup_system.create_backup(
       backup_type="full",
       description="Manual backup before system update",
       tags=["manual", "pre-update"]
   )
   print(f"Backup created: {backup_id}")
   ```

2. **List Available Backups**:
   ```python
   backups = backup_system.list_backups()
   for backup in backups:
       print(f"{backup.backup_id}: {backup.description}")
   ```

3. **Create System Snapshot**:
   ```python
   from time_capsule.recovery_manager import RecoveryManager
   
   recovery_manager = RecoveryManager(backup_system)
   snapshot_id = recovery_manager.create_system_snapshot(
       description="Pre-configuration change snapshot"
   )
   print(f"Snapshot created: {snapshot_id}")
   ```

4. **Create Recovery Plan**:
   ```python
   from datetime import datetime, timezone, timedelta
   
   target_time = datetime.now(timezone.utc) - timedelta(hours=2)
   plan_id = recovery_manager.create_recovery_plan(
       target_timestamp=target_time,
       components=["constitution", "conversations", "documents"]
   )
   print(f"Recovery plan created: {plan_id}")
   ```

### Constitutional Rule Management

1. **View Current Rules**:
   ```bash
   curl http://localhost:8003/api/constitution/rules
   ```

2. **Add Custom Rule**:
   ```python
   from constitutional.constitution import ConstitutionalFramework
   
   constitution = ConstitutionalFramework()
   constitution.add_rule(
       rule_id="custom_rule_1",
       name="Custom Safety Rule",
       description="Block requests for dangerous activities",
       rule_type="safety",
       priority="critical",
       conditions=["dangerous", "harmful", "illegal"],
       action="block"
   )
   ```

3. **View Constitutional Statistics**:
   ```bash
   curl http://localhost:8003/api/constitution/stats
   ```

---

## API Documentation

### Chat API Endpoints

#### POST /api/chat
Send a message to the AI and receive a constitutionally-governed response.

**Request**:
```json
{
  "message": "Hello, can you help me with something?",
  "conversation_id": "optional-conversation-id"
}
```

**Response**:
```json
{
  "response": "Hello! I'd be happy to help you. What do you need assistance with?",
  "constitutional_evaluation": {
    "approved": true,
    "confidence": 0.95,
    "applied_rules": ["helpful_behavior"],
    "processing_time_ms": 245
  },
  "conversation_id": "conv_1234567890",
  "timestamp": "2025-07-19T18:00:00Z"
}
```

#### GET /api/conversations
Retrieve conversation history.

**Response**:
```json
{
  "conversations": [
    {
      "conversation_id": "conv_1234567890",
      "messages": [
        {
          "role": "user",
          "content": "Hello",
          "timestamp": "2025-07-19T18:00:00Z"
        },
        {
          "role": "assistant", 
          "content": "Hello! How can I help you?",
          "timestamp": "2025-07-19T18:00:01Z",
          "constitutional_evaluation": {
            "approved": true,
            "confidence": 0.95
          }
        }
      ]
    }
  ]
}
```

#### GET /api/constitution/rules
Get all constitutional rules.

**Response**:
```json
{
  "rules": {
    "privacy_protection": {
      "name": "Privacy Protection",
      "description": "Protect user privacy",
      "rule_type": "privacy",
      "priority": "critical"
    }
  },
  "total_rules": 5
}
```

### Curation API Endpoints

#### POST /api/sources
Add a new content source.

**Request**:
```json
{
  "url": "https://feeds.bbci.co.uk/news/rss.xml",
  "source_type": "rss",
  "priority": 8,
  "scan_interval": 3600,
  "tags": ["news", "bbc"]
}
```

**Response**:
```json
{
  "source_id": "source_1234567890",
  "status": "added",
  "message": "Source added successfully"
}
```

#### GET /api/sources
List all content sources.

**Response**:
```json
{
  "sources": [
    {
      "source_id": "source_1234567890",
      "url": "https://feeds.bbci.co.uk/news/rss.xml",
      "source_type": "rss",
      "priority": 8,
      "status": "active",
      "last_scan": "2025-07-19T18:00:00Z",
      "performance": {
        "success_rate": 0.95,
        "average_quality": 0.78,
        "items_processed": 150
      }
    }
  ]
}
```

#### POST /api/scan/manual
Trigger manual content scan.

**Response**:
```json
{
  "scan_id": "scan_1234567890",
  "status": "started",
  "sources_scanned": 5,
  "estimated_duration": "2 minutes"
}
```

#### GET /api/stats/overview
Get curation system overview.

**Response**:
```json
{
  "sources": {
    "total": 10,
    "active": 8,
    "paused": 2
  },
  "content": {
    "items_processed": 1250,
    "items_accepted": 156,
    "items_rejected": 1094,
    "acceptance_rate": 0.125
  },
  "performance": {
    "average_scan_time": 45.2,
    "success_rate": 0.94
  }
}
```

---

## System Administration

### Service Management

#### Starting Services

```bash
# Start all services
./scripts/start_services.sh

# Start individual services
python chat_api.py &
python curation_api.py &
cd sovereign-chat && pnpm run dev --host &
```

#### Stopping Services

```bash
# Stop all services
./scripts/stop_services.sh

# Stop individual services
pkill -f chat_api.py
pkill -f curation_api.py
pkill -f "pnpm run dev"
```

#### Service Status

```bash
# Check service health
curl http://localhost:8003/health
curl http://localhost:8002/health
curl http://localhost:5174

# Check system processes
ps aux | grep -E "(chat_api|curation_api|pnpm)"
```

### Database Management

#### Database Initialization

```python
from api_server.database import init_database
from time_capsule.backup_system import TimeCapsuleBackupSystem

# Initialize main database
init_database()

# Initialize backup databases
backup_system = TimeCapsuleBackupSystem()
```

#### Database Backup

```bash
# Backup SQLite databases
cp api-server/sovereign_ai.db backups/sovereign_ai_$(date +%Y%m%d_%H%M%S).db
cp time_capsule/metadata/backup_metadata.db backups/backup_metadata_$(date +%Y%m%d_%H%M%S).db
```

#### Database Maintenance

```python
# Vacuum databases for optimization
import sqlite3

databases = [
    "api-server/sovereign_ai.db",
    "time_capsule/metadata/backup_metadata.db",
    "time_capsule/recovery/recovery.db"
]

for db_path in databases:
    conn = sqlite3.connect(db_path)
    conn.execute("VACUUM")
    conn.close()
    print(f"Vacuumed {db_path}")
```

### Log Management

#### Log Locations

- **Chat API**: `logs/chat_api.log`
- **Curation API**: `logs/curation_api.log`
- **Constitutional AI**: `logs/constitutional.log`
- **Backup System**: `logs/backup_system.log`
- **System Logs**: `logs/system.log`

#### Log Rotation

```bash
# Configure logrotate
sudo nano /etc/logrotate.d/sovereign_ai

# Add configuration:
/path/to/sovereign_ai/logs/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 644 ubuntu ubuntu
}
```

#### Log Analysis

```bash
# View recent errors
grep -i error logs/*.log | tail -20

# Monitor real-time logs
tail -f logs/chat_api.log

# Analyze constitutional decisions
grep "constitutional" logs/*.log | grep -E "(approved|blocked)"
```

### Performance Monitoring

#### System Metrics

```python
import psutil
import time

def monitor_system():
    while True:
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        print(f"CPU: {cpu_percent}%")
        print(f"Memory: {memory.percent}% ({memory.used/1024/1024:.1f}MB used)")
        print(f"Disk: {disk.percent}% ({disk.used/1024/1024/1024:.1f}GB used)")
        print("-" * 40)
        
        time.sleep(60)

monitor_system()
```

#### API Performance

```bash
# Test API response times
time curl -s http://localhost:8003/health > /dev/null
time curl -s http://localhost:8002/health > /dev/null

# Load testing with Apache Bench
ab -n 100 -c 10 http://localhost:8003/health
```

### Security Management

#### SSL/TLS Configuration

```bash
# Generate self-signed certificates
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# Configure HTTPS in API servers
# Add to chat_api.py:
import ssl
context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
context.load_cert_chain('cert.pem', 'key.pem')
app.run(host='0.0.0.0', port=8003, ssl_context=context)
```

#### Firewall Configuration

```bash
# Configure UFW firewall
sudo ufw enable
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 8003/tcp  # Chat API
sudo ufw allow 8002/tcp  # Curation API
sudo ufw allow 5174/tcp  # React App

# Check firewall status
sudo ufw status
```

#### Access Control

```python
# Add API key authentication
from functools import wraps
from flask import request, jsonify

def require_api_key(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        if not api_key or api_key != os.getenv('API_KEY'):
            return jsonify({'error': 'Invalid API key'}), 401
        return f(*args, **kwargs)
    return decorated_function

@app.route('/api/chat', methods=['POST'])
@require_api_key
def chat():
    # Chat endpoint implementation
    pass
```

---

## Backup and Recovery

### Automated Backup System

The Time Capsule backup system provides comprehensive backup and recovery capabilities with enterprise-grade features.

#### Backup Types

1. **Full Backup**: Complete system backup including all data, configuration, and system state
2. **Incremental Backup**: Only changes since the last backup
3. **Differential Backup**: Changes since the last full backup

#### Backup Schedule

Default automated backup schedule:
- **Full Backup**: Daily at 2:00 AM
- **Incremental Backup**: Every 6 hours
- **Cleanup**: Weekly on Sunday at 1:00 AM

#### Manual Backup Operations

```python
from time_capsule.backup_system import TimeCapsuleBackupSystem

# Initialize backup system
backup_system = TimeCapsuleBackupSystem()

# Create full backup
backup_id = backup_system.create_backup(
    backup_type="full",
    description="Manual full backup before system update",
    tags=["manual", "pre-update", "full"]
)

# Create incremental backup
backup_id = backup_system.create_backup(
    backup_type="incremental", 
    description="Incremental backup after configuration changes",
    tags=["manual", "post-config", "incremental"]
)

# List all backups
backups = backup_system.list_backups()
for backup in backups:
    print(f"ID: {backup.backup_id}")
    print(f"Type: {backup.backup_type}")
    print(f"Size: {backup.total_size_bytes:,} bytes")
    print(f"Compressed: {backup.compressed_size_bytes:,} bytes")
    print(f"Ratio: {backup.compressed_size_bytes/backup.total_size_bytes:.2%}")
    print(f"Files: {len(backup.files_included)}")
    print(f"Created: {backup.timestamp}")
    print("-" * 50)
```

#### Backup Verification

```python
# Verify backup integrity
backup_id = "backup_1234567890_full"
is_valid = backup_system.verify_backup(backup_id)
print(f"Backup {backup_id} is {'valid' if is_valid else 'corrupted'}")

# Get backup statistics
stats = backup_system.get_backup_statistics()
print(f"Total backups: {stats['total_backups']}")
print(f"Total size: {stats['total_size_bytes']:,} bytes")
print(f"Compressed size: {stats['total_compressed_bytes']:,} bytes")
print(f"Average compression: {stats['average_compression_ratio']:.2%}")
```

### Recovery Operations

#### System Snapshots

System snapshots provide lightweight, fast recovery points for quick rollbacks:

```python
from time_capsule.recovery_manager import RecoveryManager

# Initialize recovery manager
recovery_manager = RecoveryManager(backup_system)

# Create system snapshot
snapshot_id = recovery_manager.create_system_snapshot(
    description="Snapshot before constitutional rule changes"
)

# List snapshots
snapshots = recovery_manager.list_system_snapshots()
for snapshot in snapshots:
    print(f"ID: {snapshot.snapshot_id}")
    print(f"Description: {snapshot.description}")
    print(f"Timestamp: {snapshot.timestamp}")
    print(f"Constitution rules: {len(snapshot.constitution_snapshot.get('rules', {}))}")
    print(f"Conversations: {snapshot.conversation_count}")
    print(f"Documents: {snapshot.document_count}")
    print("-" * 50)

# Rollback to snapshot
success = recovery_manager.rollback_to_snapshot(snapshot_id)
print(f"Rollback {'successful' if success else 'failed'}")
```

#### Recovery Planning

The recovery manager creates intelligent recovery plans with risk assessment:

```python
from datetime import datetime, timezone, timedelta

# Create recovery plan for 2 hours ago
target_time = datetime.now(timezone.utc) - timedelta(hours=2)
plan_id = recovery_manager.create_recovery_plan(
    target_timestamp=target_time,
    components=["constitution", "conversations", "documents", "configuration"]
)

print(f"Recovery plan created: {plan_id}")

# Execute recovery plan
success = recovery_manager.execute_recovery_plan(plan_id)
print(f"Recovery {'successful' if success else 'failed'}")
```

#### Point-in-Time Recovery

```python
# Restore from specific backup
backup_id = "backup_1234567890_full"
restore_id = backup_system.restore_from_backup(
    backup_id=backup_id,
    restore_scope={
        "constitution": True,
        "conversations": True,
        "documents": True,
        "configuration": True
    }
)

print(f"Restore operation: {restore_id}")
```

### Disaster Recovery Procedures

#### Complete System Recovery

1. **Assess the Situation**:
   ```python
   # Check system health
   recovery_status = recovery_manager.get_recovery_status()
   print(f"System health: {recovery_status['system_health']}")
   print(f"Available snapshots: {recovery_status['snapshots']['total_snapshots']}")
   print(f"Available backups: {len(backup_system.list_backups())}")
   ```

2. **Create Pre-Recovery Backup**:
   ```python
   # Create backup of current state before recovery
   pre_recovery_backup = backup_system.create_backup(
       backup_type="full",
       description="Pre-disaster-recovery backup",
       tags=["disaster-recovery", "pre-recovery"]
   )
   ```

3. **Select Recovery Point**:
   ```python
   # Find the best backup before the incident
   backups = backup_system.list_backups()
   incident_time = datetime(2025, 7, 19, 15, 30, 0, tzinfo=timezone.utc)
   
   suitable_backups = [
       b for b in backups 
       if b.timestamp < incident_time and b.verification_status == "verified"
   ]
   
   if suitable_backups:
       recovery_backup = max(suitable_backups, key=lambda b: b.timestamp)
       print(f"Selected backup: {recovery_backup.backup_id}")
       print(f"Backup timestamp: {recovery_backup.timestamp}")
   ```

4. **Execute Recovery**:
   ```python
   # Create and execute recovery plan
   plan_id = recovery_manager.create_recovery_plan(
       target_timestamp=recovery_backup.timestamp,
       components=["constitution", "conversations", "documents", "configuration"]
   )
   
   success = recovery_manager.execute_recovery_plan(plan_id)
   if success:
       print("Disaster recovery completed successfully")
   else:
       print("Disaster recovery failed - check logs for details")
   ```

5. **Verify Recovery**:
   ```python
   # Verify system integrity after recovery
   post_recovery_snapshot = recovery_manager.create_system_snapshot(
       description="Post-disaster-recovery verification snapshot"
   )
   
   # Test system functionality
   # (Run integration tests or manual verification)
   ```

#### Backup Retention and Cleanup

```python
# Configure retention policies
backup_system.config['retention_days'] = 30
backup_system.config['max_backups'] = 100

# Manual cleanup of old backups
backups = backup_system.list_backups()
now = datetime.now(timezone.utc)

for backup in backups:
    age_days = (now - backup.timestamp).days
    if age_days > backup.retention_days:
        success = backup_system.delete_backup(backup.backup_id)
        if success:
            print(f"Deleted expired backup: {backup.backup_id}")
```

---

## Troubleshooting

### Common Issues and Solutions

#### Service Startup Issues

**Problem**: Chat API fails to start
```
Error: Address already in use: 8003
```

**Solution**:
```bash
# Find and kill process using port 8003
sudo lsof -i :8003
sudo kill -9 <PID>

# Or use a different port
export CHAT_API_PORT=8004
python chat_api.py
```

**Problem**: Ollama model not found
```
Error: Model 'tinyllama' not found
```

**Solution**:
```bash
# Download the model
ollama pull tinyllama

# Verify model is available
ollama list

# If Ollama service is not running
sudo systemctl start ollama
sudo systemctl enable ollama
```

#### Database Issues

**Problem**: Database connection errors
```
sqlite3.OperationalError: database is locked
```

**Solution**:
```bash
# Check for processes using the database
sudo lsof /path/to/sovereign_ai.db

# Kill processes if necessary
sudo kill -9 <PID>

# Repair database if corrupted
sqlite3 sovereign_ai.db "PRAGMA integrity_check;"
```

**Problem**: Database schema errors
```
sqlite3.OperationalError: no such table: conversations
```

**Solution**:
```python
# Reinitialize database
from api_server.database import init_database
init_database()
```

#### Constitutional AI Issues

**Problem**: All messages being blocked
```
Constitutional evaluation: blocked (confidence: 0.95)
```

**Solution**:
```python
# Check constitutional rules
from constitutional.constitution import ConstitutionalFramework

constitution = ConstitutionalFramework()
rules = constitution.get_all_rules()

# Temporarily disable strict rules
constitution.update_rule("privacy_protection", {"priority": "low"})

# Or reset to default rules
constitution.load_default_constitution()
```

**Problem**: Constitutional evaluation timeout
```
Error: Constitutional evaluation timeout after 1000ms
```

**Solution**:
```python
# Increase timeout in configuration
constitution.config['rule_evaluation_timeout'] = 5000  # 5 seconds

# Or simplify complex rules
constitution.optimize_rules()
```

#### Curation Engine Issues

**Problem**: RSS feeds not processing
```
Error: Failed to fetch RSS feed: Connection timeout
```

**Solution**:
```python
from curation.rss_processor import RSSProcessor

# Test RSS feed manually
processor = RSSProcessor()
result = processor.process_feed("https://feeds.bbci.co.uk/news/rss.xml")

# Check network connectivity
import requests
response = requests.get("https://feeds.bbci.co.uk/news/rss.xml", timeout=10)
print(f"Status: {response.status_code}")

# Update feed URL if necessary
# Some feeds may have changed URLs
```

**Problem**: Content filtering too aggressive
```
All content rejected by quality filter
```

**Solution**:
```python
from curation.content_filter import ContentFilter

# Adjust filter thresholds
filter_config = {
    "quality_threshold": 0.4,  # Lower threshold
    "relevance_threshold": 0.3,
    "min_word_count": 50
}

content_filter = ContentFilter(filter_config)
```

#### Backup System Issues

**Problem**: Backup creation fails
```
Error: division by zero in compression ratio calculation
```

**Solution**:
```python
# This occurs when backing up empty directories
# Fix in backup_system.py:
compression_ratio = compressed_size / total_size if total_size > 0 else 0.0
```

**Problem**: Backup verification fails
```
Error: Checksum mismatch for backup
```

**Solution**:
```python
# Re-verify backup
backup_system = TimeCapsuleBackupSystem()
is_valid = backup_system.verify_backup(backup_id)

if not is_valid:
    # Create new backup
    new_backup_id = backup_system.create_backup("full", "Replacement backup")
    
    # Delete corrupted backup
    backup_system.delete_backup(backup_id)
```

#### Performance Issues

**Problem**: Slow response times
```
Chat response time: 15000ms (too slow)
```

**Solution**:
```python
# Check system resources
import psutil
print(f"CPU: {psutil.cpu_percent()}%")
print(f"Memory: {psutil.virtual_memory().percent}%")

# Optimize AI model settings
# In config.yaml:
ai:
  temperature: 0.5  # Lower temperature for faster responses
  max_tokens: 1024  # Reduce max tokens
  timeout: 10       # Reduce timeout

# Consider using a smaller model
ollama pull phi3:mini
```

**Problem**: High memory usage
```
Memory usage: 95% (system running out of memory)
```

**Solution**:
```bash
# Monitor memory usage
free -h
top -o %MEM

# Restart services to free memory
./scripts/restart_services.sh

# Consider upgrading system memory or using smaller AI model
```

### Diagnostic Tools

#### System Health Check

```python
def system_health_check():
    """Comprehensive system health check."""
    import requests
    import sqlite3
    import os
    
    health_report = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "services": {},
        "databases": {},
        "disk_space": {},
        "memory": {},
        "ai_model": {}
    }
    
    # Check API services
    services = {
        "chat_api": "http://localhost:8003/health",
        "curation_api": "http://localhost:8002/health",
        "react_app": "http://localhost:5174"
    }
    
    for service, url in services.items():
        try:
            response = requests.get(url, timeout=5)
            health_report["services"][service] = {
                "status": "healthy" if response.status_code == 200 else "unhealthy",
                "response_time": response.elapsed.total_seconds() * 1000
            }
        except Exception as e:
            health_report["services"][service] = {
                "status": "error",
                "error": str(e)
            }
    
    # Check databases
    databases = [
        "api-server/sovereign_ai.db",
        "time_capsule/metadata/backup_metadata.db"
    ]
    
    for db_path in databases:
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
            table_count = cursor.fetchone()[0]
            conn.close()
            
            health_report["databases"][db_path] = {
                "status": "healthy",
                "tables": table_count,
                "size_mb": os.path.getsize(db_path) / 1024 / 1024
            }
        except Exception as e:
            health_report["databases"][db_path] = {
                "status": "error",
                "error": str(e)
            }
    
    # Check disk space
    disk_usage = psutil.disk_usage('/')
    health_report["disk_space"] = {
        "total_gb": disk_usage.total / 1024 / 1024 / 1024,
        "used_gb": disk_usage.used / 1024 / 1024 / 1024,
        "free_gb": disk_usage.free / 1024 / 1024 / 1024,
        "percent_used": disk_usage.percent
    }
    
    # Check memory
    memory = psutil.virtual_memory()
    health_report["memory"] = {
        "total_mb": memory.total / 1024 / 1024,
        "used_mb": memory.used / 1024 / 1024,
        "available_mb": memory.available / 1024 / 1024,
        "percent_used": memory.percent
    }
    
    # Check AI model
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=5)
        if response.status_code == 200:
            models = response.json().get("models", [])
            health_report["ai_model"] = {
                "status": "healthy",
                "available_models": [m["name"] for m in models]
            }
        else:
            health_report["ai_model"] = {"status": "unhealthy"}
    except Exception as e:
        health_report["ai_model"] = {
            "status": "error",
            "error": str(e)
        }
    
    return health_report

# Run health check
health = system_health_check()
print(json.dumps(health, indent=2))
```

#### Log Analysis Tool

```python
def analyze_logs(log_dir="./logs", hours=24):
    """Analyze system logs for errors and patterns."""
    import glob
    from collections import defaultdict
    
    cutoff_time = datetime.now() - timedelta(hours=hours)
    error_patterns = defaultdict(int)
    warning_patterns = defaultdict(int)
    
    log_files = glob.glob(f"{log_dir}/*.log")
    
    for log_file in log_files:
        try:
            with open(log_file, 'r') as f:
                for line in f:
                    if 'ERROR' in line:
                        # Extract error pattern
                        parts = line.split(' - ')
                        if len(parts) >= 3:
                            error_patterns[parts[2].strip()] += 1
                    elif 'WARNING' in line:
                        parts = line.split(' - ')
                        if len(parts) >= 3:
                            warning_patterns[parts[2].strip()] += 1
        except Exception as e:
            print(f"Error reading {log_file}: {e}")
    
    print("Log Analysis Report")
    print("=" * 50)
    print(f"Time period: Last {hours} hours")
    print(f"Log files analyzed: {len(log_files)}")
    
    print("\nTop Errors:")
    for error, count in sorted(error_patterns.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {count:3d}: {error}")
    
    print("\nTop Warnings:")
    for warning, count in sorted(warning_patterns.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {count:3d}: {warning}")

# Run log analysis
analyze_logs()
```

### Emergency Recovery Procedures

#### Complete System Reset

If the system becomes completely unresponsive:

1. **Stop All Services**:
   ```bash
   pkill -f chat_api.py
   pkill -f curation_api.py
   pkill -f "pnpm run dev"
   sudo systemctl stop ollama
   ```

2. **Backup Current State**:
   ```bash
   # Create emergency backup
   tar -czf emergency_backup_$(date +%Y%m%d_%H%M%S).tar.gz \
     api-server/ \
     constitutional/ \
     curation/ \
     time_capsule/ \
     config/ \
     logs/
   ```

3. **Reset Databases**:
   ```bash
   # Backup existing databases
   mv api-server/sovereign_ai.db api-server/sovereign_ai.db.backup
   mv time_capsule/metadata/backup_metadata.db time_capsule/metadata/backup_metadata.db.backup
   
   # Reinitialize databases
   python -c "
   from api_server.database import init_database
   from time_capsule.backup_system import TimeCapsuleBackupSystem
   init_database()
   backup_system = TimeCapsuleBackupSystem()
   print('Databases reinitialized')
   "
   ```

4. **Restart Services**:
   ```bash
   sudo systemctl start ollama
   ./scripts/start_services.sh
   ```

5. **Verify System**:
   ```bash
   # Run health checks
   python -c "
   import requests
   print('Chat API:', requests.get('http://localhost:8003/health').status_code)
   print('Curation API:', requests.get('http://localhost:8002/health').status_code)
   print('React App:', requests.get('http://localhost:5174').status_code)
   "
   ```

---

## Development

### Development Environment Setup

```bash
# Clone development repository
git clone <repository-url>
cd sovereign_ai

# Create development environment
python3.11 -m venv venv_dev
source venv_dev/bin/activate

# Install development dependencies
pip install -r requirements-dev.txt

# Install pre-commit hooks
pre-commit install

# Set up development configuration
cp config/config.yaml.dev config/config.yaml
cp .env.dev .env
```

### Code Structure

```
sovereign_ai/
├── api-server/              # Core API server
│   ├── models.py           # Database models
│   ├── database.py         # Database connection
│   ├── vault.py           # Document vault
│   └── main.py            # API endpoints
├── constitutional/          # Constitutional AI
│   ├── constitution.py    # Rule framework
│   └── ai_governor.py     # AI governance
├── curation/               # Content curation
│   ├── rss_processor.py   # RSS processing
│   ├── web_scraper.py     # Web scraping
│   ├── content_filter.py  # Content filtering
│   └── source_manager.py  # Source management
├── time_capsule/           # Backup system
│   ├── backup_system.py   # Backup engine
│   └── recovery_manager.py # Recovery system
├── sovereign-chat/         # React frontend
│   ├── src/
│   │   ├── components/    # React components
│   │   └── App.jsx       # Main application
│   └── package.json      # Node.js dependencies
├── config/                 # Configuration files
├── logs/                  # Log files
├── tests/                 # Test suite
└── scripts/               # Utility scripts
```

### Testing

#### Unit Tests

```bash
# Run all tests
python -m pytest tests/

# Run specific test module
python -m pytest tests/test_constitutional.py

# Run with coverage
python -m pytest --cov=. tests/
```

#### Integration Tests

```bash
# Run integration test suite
python integration_test.py

# Run specific integration test
python -c "
from integration_test import SovereignAIIntegrationTest
test = SovereignAIIntegrationTest()
test.test_constitutional_ai_integration()
"
```

#### Performance Tests

```bash
# Load test APIs
ab -n 1000 -c 10 http://localhost:8003/health
ab -n 100 -c 5 -p test_message.json -T application/json http://localhost:8003/api/chat

# Memory leak testing
python -c "
import psutil
import time
import requests

process = psutil.Process()
for i in range(100):
    requests.post('http://localhost:8003/api/chat', json={'message': f'Test {i}'})
    if i % 10 == 0:
        print(f'Iteration {i}: Memory {process.memory_info().rss / 1024 / 1024:.1f} MB')
    time.sleep(0.1)
"
```

### Contributing Guidelines

#### Code Style

```bash
# Format code with black
black .

# Sort imports with isort
isort .

# Lint with flake8
flake8 .

# Type checking with mypy
mypy .
```

#### Commit Guidelines

```bash
# Commit message format
git commit -m "feat(constitutional): add new rule priority system

- Add support for rule priority levels
- Implement priority-based conflict resolution
- Update tests for new priority system

Closes #123"
```

#### Pull Request Process

1. **Create Feature Branch**:
   ```bash
   git checkout -b feature/new-constitutional-rule-type
   ```

2. **Implement Changes**:
   - Write code following style guidelines
   - Add comprehensive tests
   - Update documentation

3. **Test Changes**:
   ```bash
   # Run all tests
   python -m pytest tests/
   
   # Run integration tests
   python integration_test.py
   
   # Check code quality
   black --check .
   flake8 .
   mypy .
   ```

4. **Submit Pull Request**:
   - Provide clear description
   - Include test results
   - Reference related issues

### Extending the System

#### Adding New Constitutional Rules

```python
# Create custom rule type
class CustomRuleType:
    def __init__(self, name, description, evaluation_function):
        self.name = name
        self.description = description
        self.evaluation_function = evaluation_function
    
    def evaluate(self, message, context):
        return self.evaluation_function(message, context)

# Register with constitutional framework
from constitutional.constitution import ConstitutionalFramework

constitution = ConstitutionalFramework()
constitution.register_rule_type("custom", CustomRuleType)
```

#### Adding New Content Sources

```python
# Create custom content processor
class CustomContentProcessor:
    def __init__(self, config):
        self.config = config
    
    def process_source(self, source_url):
        # Implement custom content processing
        content_items = []
        # ... processing logic ...
        return content_items

# Register with curation engine
from curation.source_manager import SourceManager

source_manager = SourceManager()
source_manager.register_processor("custom", CustomContentProcessor)
```

#### Adding New API Endpoints

```python
# Add to chat_api.py
@app.route('/api/custom/endpoint', methods=['POST'])
def custom_endpoint():
    data = request.get_json()
    
    # Implement custom functionality
    result = process_custom_request(data)
    
    return jsonify({
        'status': 'success',
        'result': result
    })
```

---

## Contributing

We welcome contributions to Sovereign AI! Please read our contributing guidelines and code of conduct before submitting pull requests.

### How to Contribute

1. **Fork the Repository**: Create a fork of the Sovereign AI repository
2. **Create Feature Branch**: Create a branch for your feature or bug fix
3. **Implement Changes**: Make your changes following our coding standards
4. **Add Tests**: Ensure your changes are covered by tests
5. **Update Documentation**: Update relevant documentation
6. **Submit Pull Request**: Submit a pull request with a clear description

### Development Setup

See the [Development](#development) section for detailed setup instructions.

### Reporting Issues

Please use the GitHub issue tracker to report bugs or request features. Include:
- Detailed description of the issue
- Steps to reproduce
- Expected vs actual behavior
- System information
- Relevant log files

---

## License

Sovereign AI is released under the MIT License. See the LICENSE file for details.

### Third-Party Licenses

This project includes several third-party libraries and components:

- **FastAPI**: MIT License
- **React**: MIT License
- **SQLAlchemy**: MIT License
- **ChromaDB**: Apache License 2.0
- **Ollama**: MIT License
- **TinyLLama**: Apache License 2.0

See the `THIRD_PARTY_LICENSES.md` file for complete license information.

---

## Support

For support, please:

1. **Check Documentation**: Review this README and other documentation
2. **Search Issues**: Check existing GitHub issues
3. **Create Issue**: Create a new issue with detailed information
4. **Community Forum**: Join our community discussions

### Professional Support

Professional support and consulting services are available for enterprise deployments. Contact us for more information.

---

**Sovereign AI - Your AI, Your Rules, Your Data**

*Built with ❤️ by the Manus AI team*

