"""
AI Governor - Integrates constitutional rules with AI model responses.

This module provides the governance layer that ensures AI responses
comply with constitutional rules and user-defined principles.
"""

import json
import logging
import time
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timezone
import requests
from dataclasses import dataclass, asdict

from .constitution import (
    ConstitutionalEngine, ConstitutionalContext, ConstitutionalDecision,
    ConstitutionalRule, RuleType, RulePriority
)

@dataclass
class AIResponse:
    """Represents an AI model response."""
    content: str
    model: str
    timestamp: datetime
    
    # Constitutional evaluation
    constitutional_decision: Optional[ConstitutionalDecision] = None
    
    # Response metadata
    generation_time_ms: float = 0.0
    token_count: int = 0
    confidence: float = 1.0
    
    # Governance metadata
    was_modified: bool = False
    modification_reason: str = ""
    original_content: str = ""

@dataclass
class ConversationMessage:
    """Represents a message in a conversation."""
    role: str  # "user", "assistant", "system"
    content: str
    timestamp: datetime = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now(timezone.utc)
        if self.metadata is None:
            self.metadata = {}

class AIGovernor:
    """Governs AI interactions according to constitutional rules."""
    
    def __init__(self, ollama_url: str = "http://localhost:11434", 
                 constitution_config: str = "./data/constitution.json"):
        self.ollama_url = ollama_url
        self.constitutional_engine = ConstitutionalEngine(constitution_config)
        
        # Conversation management
        self.conversations: Dict[str, List[ConversationMessage]] = {}
        self.user_preferences: Dict[str, Dict[str, Any]] = {}
        
        # Response modification templates
        self.modification_templates = {
            'privacy_violation': "I can't provide information that might compromise privacy or security. Instead, I can help you with: {alternatives}",
            'harmful_content': "I can't assist with that request as it could be harmful. Let me suggest some constructive alternatives: {alternatives}",
            'inappropriate_request': "That request doesn't align with my guidelines. Here's how I can help instead: {alternatives}",
            'insufficient_context': "I need more context to provide a helpful response while following my guidelines. Could you clarify: {clarification_needed}?"
        }
        
        self.logger = logging.getLogger(__name__)
    
    def process_user_message(self, user_id: str, conversation_id: str, 
                           message: str, context: Dict[str, Any] = None) -> AIResponse:
        """Process a user message through constitutional governance."""
        start_time = time.time()
        
        # Create constitutional context
        constitutional_context = ConstitutionalContext(
            user_id=user_id,
            conversation_id=conversation_id,
            message_content=message,
            user_preferences=self.user_preferences.get(user_id, {}),
            conversation_history=self._get_conversation_history(conversation_id),
            metadata=context or {}
        )
        
        # Evaluate message against constitution
        decision = self.constitutional_engine.evaluate_message(constitutional_context)
        
        # Add user message to conversation
        self._add_message_to_conversation(conversation_id, ConversationMessage(
            role="user",
            content=message,
            metadata={"constitutional_decision": asdict(decision)}
        ))
        
        # Generate AI response based on constitutional decision
        if decision.allowed:
            ai_response = self._generate_ai_response(constitutional_context, decision)
        else:
            ai_response = self._generate_blocked_response(constitutional_context, decision)
        
        # Evaluate AI response against constitution
        ai_context = ConstitutionalContext(
            user_id=user_id,
            conversation_id=conversation_id,
            message_content=ai_response.content,
            message_type="ai_response",
            user_preferences=self.user_preferences.get(user_id, {}),
            conversation_history=self._get_conversation_history(conversation_id),
            metadata={"original_user_message": message}
        )
        
        ai_decision = self.constitutional_engine.evaluate_message(ai_context)
        ai_response.constitutional_decision = ai_decision
        
        # Modify AI response if it violates constitution
        if not ai_decision.allowed:
            ai_response = self._modify_ai_response(ai_response, ai_decision, constitutional_context)
        
        # Add AI response to conversation
        self._add_message_to_conversation(conversation_id, ConversationMessage(
            role="assistant",
            content=ai_response.content,
            metadata={
                "constitutional_decision": asdict(ai_decision),
                "was_modified": ai_response.was_modified,
                "generation_time_ms": ai_response.generation_time_ms
            }
        ))
        
        # Calculate total processing time
        ai_response.generation_time_ms = (time.time() - start_time) * 1000
        
        return ai_response
    
    def _generate_ai_response(self, context: ConstitutionalContext, 
                            decision: ConstitutionalDecision) -> AIResponse:
        """Generate AI response using Ollama."""
        start_time = time.time()
        
        try:
            # Prepare the prompt with constitutional guidance
            system_prompt = self._create_constitutional_system_prompt(context, decision)
            
            # Get conversation history for context
            conversation_history = self._get_conversation_history(context.conversation_id)
            
            # Build messages for Ollama
            messages = [{"role": "system", "content": system_prompt}]
            
            # Add recent conversation history (last 10 messages)
            for msg in conversation_history[-10:]:
                if msg.role in ["user", "assistant"]:
                    messages.append({"role": msg.role, "content": msg.content})
            
            # Add current user message
            messages.append({"role": "user", "content": context.message_content})
            
            # Call Ollama API
            response = requests.post(
                f"{self.ollama_url}/api/chat",
                json={
                    "model": "tinyllama",  # Use the model we have available
                    "messages": messages,
                    "stream": False
                },
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                content = result.get("message", {}).get("content", "")
                
                generation_time = (time.time() - start_time) * 1000
                
                return AIResponse(
                    content=content,
                    model="tinyllama",
                    timestamp=datetime.now(timezone.utc),
                    generation_time_ms=generation_time,
                    token_count=len(content.split()),  # Rough token estimate
                    confidence=0.8  # Default confidence
                )
            else:
                self.logger.error(f"Ollama API error: {response.status_code} - {response.text}")
                return self._create_fallback_response("I'm having trouble generating a response right now.")
                
        except Exception as e:
            self.logger.error(f"Error generating AI response: {e}")
            return self._create_fallback_response("I encountered an error while processing your request.")
    
    def _generate_blocked_response(self, context: ConstitutionalContext, 
                                 decision: ConstitutionalDecision) -> AIResponse:
        """Generate a response for blocked messages."""
        
        # Create a helpful explanation
        explanation = f"I can't process that request because it {decision.reasoning.lower()}"
        
        if decision.suggestions:
            explanation += "\n\nHere are some suggestions:\n"
            for i, suggestion in enumerate(decision.suggestions, 1):
                explanation += f"{i}. {suggestion}\n"
        
        explanation += "\nI'm here to help in ways that align with my guidelines. Is there something else I can assist you with?"
        
        return AIResponse(
            content=explanation,
            model="constitutional_governor",
            timestamp=datetime.now(timezone.utc),
            generation_time_ms=0.0,
            confidence=1.0
        )
    
    def _modify_ai_response(self, response: AIResponse, decision: ConstitutionalDecision,
                          original_context: ConstitutionalContext) -> AIResponse:
        """Modify an AI response that violates constitutional rules."""
        
        # Store original content
        response.original_content = response.content
        response.was_modified = True
        
        # Determine modification type based on violated rules
        violated_rule_types = []
        for rule_id in decision.violated_rules:
            rule = self.constitutional_engine.get_rule(rule_id)
            if rule:
                violated_rule_types.append(rule.rule_type)
        
        # Choose appropriate modification template
        if RuleType.PRIVACY in violated_rule_types:
            template_key = 'privacy_violation'
        elif RuleType.CONTENT in violated_rule_types:
            template_key = 'harmful_content'
        elif RuleType.ETHICAL in violated_rule_types:
            template_key = 'inappropriate_request'
        else:
            template_key = 'insufficient_context'
        
        # Generate modified response
        template = self.modification_templates[template_key]
        
        # Create alternatives or clarifications
        alternatives = self._generate_alternatives(original_context, violated_rule_types)
        clarification_needed = "more specific details about what you're trying to accomplish"
        
        modified_content = template.format(
            alternatives=alternatives,
            clarification_needed=clarification_needed
        )
        
        response.content = modified_content
        response.modification_reason = f"Constitutional violation: {', '.join([r.value for r in violated_rule_types])}"
        
        return response
    
    def _create_constitutional_system_prompt(self, context: ConstitutionalContext,
                                           decision: ConstitutionalDecision) -> str:
        """Create a system prompt that incorporates constitutional guidance."""
        
        base_prompt = """You are a helpful AI assistant operating under constitutional governance. 
Your responses must align with the following principles:

1. Be helpful, harmless, and honest
2. Respect user privacy and autonomy
3. Provide accurate information
4. Refuse harmful or inappropriate requests
5. Be transparent about your limitations

"""
        
        # Add specific guidance based on applied rules
        if decision.applied_rules:
            base_prompt += "Specific guidance for this interaction:\n"
            for rule_id in decision.applied_rules:
                rule = self.constitutional_engine.get_rule(rule_id)
                if rule:
                    base_prompt += f"- {rule.description}\n"
        
        base_prompt += "\nRespond naturally while following these guidelines."
        
        return base_prompt
    
    def _generate_alternatives(self, context: ConstitutionalContext, 
                             violated_types: List[RuleType]) -> str:
        """Generate alternative suggestions for blocked requests."""
        
        alternatives = []
        
        if RuleType.PRIVACY in violated_types:
            alternatives.extend([
                "General information on the topic",
                "Best practices for privacy protection",
                "Resources for learning more safely"
            ])
        
        if RuleType.CONTENT in violated_types:
            alternatives.extend([
                "Educational information on the topic",
                "Constructive approaches to your goal",
                "Related topics that might be helpful"
            ])
        
        if RuleType.ETHICAL in violated_types:
            alternatives.extend([
                "Ethical approaches to your objective",
                "Information about relevant guidelines",
                "Alternative methods that align with best practices"
            ])
        
        if not alternatives:
            alternatives = [
                "A different approach to your question",
                "Related information that might be helpful",
                "Clarification on what you're trying to accomplish"
            ]
        
        return ", ".join(alternatives[:3])  # Limit to 3 alternatives
    
    def _create_fallback_response(self, message: str) -> AIResponse:
        """Create a fallback response for errors."""
        return AIResponse(
            content=message,
            model="fallback",
            timestamp=datetime.now(timezone.utc),
            generation_time_ms=0.0,
            confidence=0.5
        )
    
    def _get_conversation_history(self, conversation_id: str) -> List[ConversationMessage]:
        """Get conversation history."""
        return self.conversations.get(conversation_id, [])
    
    def _add_message_to_conversation(self, conversation_id: str, message: ConversationMessage):
        """Add a message to conversation history."""
        if conversation_id not in self.conversations:
            self.conversations[conversation_id] = []
        
        self.conversations[conversation_id].append(message)
        
        # Keep only recent messages (last 100)
        if len(self.conversations[conversation_id]) > 100:
            self.conversations[conversation_id] = self.conversations[conversation_id][-100:]
    
    def set_user_preferences(self, user_id: str, preferences: Dict[str, Any]):
        """Set user preferences."""
        self.user_preferences[user_id] = preferences
        self.logger.info(f"Updated preferences for user {user_id}")
    
    def get_conversation_summary(self, conversation_id: str) -> Dict[str, Any]:
        """Get a summary of a conversation."""
        messages = self._get_conversation_history(conversation_id)
        
        if not messages:
            return {"message_count": 0, "summary": "No messages"}
        
        user_messages = [m for m in messages if m.role == "user"]
        ai_messages = [m for m in messages if m.role == "assistant"]
        
        # Count constitutional decisions
        blocked_messages = 0
        modified_responses = 0
        
        for message in messages:
            if message.metadata:
                decision = message.metadata.get("constitutional_decision")
                if decision and not decision.get("allowed", True):
                    blocked_messages += 1
                
                if message.metadata.get("was_modified"):
                    modified_responses += 1
        
        return {
            "message_count": len(messages),
            "user_messages": len(user_messages),
            "ai_messages": len(ai_messages),
            "blocked_messages": blocked_messages,
            "modified_responses": modified_responses,
            "start_time": messages[0].timestamp.isoformat() if messages else None,
            "last_activity": messages[-1].timestamp.isoformat() if messages else None
        }
    
    def get_governance_stats(self) -> Dict[str, Any]:
        """Get governance statistics."""
        constitution_stats = self.constitutional_engine.get_constitution_stats()
        
        # Calculate conversation stats
        total_conversations = len(self.conversations)
        total_messages = sum(len(msgs) for msgs in self.conversations.values())
        
        # Count governance actions
        blocked_count = 0
        modified_count = 0
        
        for messages in self.conversations.values():
            for message in messages:
                if message.metadata:
                    decision = message.metadata.get("constitutional_decision")
                    if decision and not decision.get("allowed", True):
                        blocked_count += 1
                    
                    if message.metadata.get("was_modified"):
                        modified_count += 1
        
        return {
            "constitution": constitution_stats,
            "conversations": {
                "total_conversations": total_conversations,
                "total_messages": total_messages,
                "blocked_messages": blocked_count,
                "modified_responses": modified_count,
                "governance_rate": (blocked_count + modified_count) / total_messages if total_messages > 0 else 0
            },
            "users": {
                "total_users": len(self.user_preferences),
                "users_with_preferences": len([p for p in self.user_preferences.values() if p])
            }
        }

