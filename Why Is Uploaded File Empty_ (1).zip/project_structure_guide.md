# WhisperLeaf Project Structure Guide

## Organized Project Directory Structure

The WhisperLeaf system has been organized into the following directory structure:

```
whisperleaf_project/
├── core/                    # Core system components
│   ├── memory_manager.py    # Secure memory storage and retrieval
│   ├── memory_models.py     # Data models for memories
│   ├── memory_search.py     # Advanced memory search capabilities
│   ├── journal_processor.py # Journal entry processing
│   ├── vault.py            # Document vault management
│   ├── database.py         # Database abstraction layer
│   ├── models.py           # Core data models
│   └── main.py             # Main application entry point
│
├── emotional/              # Emotional processing framework
│   ├── emotional_processor.py    # Core emotional analysis
│   ├── emotion_detector.py       # Emotion detection algorithms
│   ├── crisis_detector.py        # Crisis detection and intervention
│   ├── tone_engine.py            # Tone management and consistency
│   ├── big_mood.py               # Big Mood 5-color system
│   ├── crisis_responder.py       # Crisis response protocols
│   └── emotional_constitution.py # Emotional safety framework
│
├── curation/               # Content curation engine
│   ├── curation_api.py     # Unified curation API
│   ├── content_filter.py   # Intelligent content filtering
│   ├── rss_processor.py    # RSS feed processing
│   ├── web_scraper.py      # Web content scraping
│   ├── source_manager.py   # Content source management
│   └── feed_monitor.py     # Feed monitoring and scheduling
│
├── backup/                 # Backup and recovery system
│   ├── backup_system.py    # Time Capsule backup system
│   └── recovery_manager.py # Recovery and restoration
│
├── tests/                  # Comprehensive test suite
│   ├── test_integration.py      # Integration testing
│   ├── test_memory_vault.py     # Memory system tests
│   ├── test_emotional_engine.py # Emotional processing tests
│   ├── test_content_filter.py   # Content filtering tests
│   ├── test_constitutional.py   # Constitutional AI tests
│   └── [additional test files]
│
├── docs/                   # Documentation files
│   ├── README.md           # Main project documentation
│   ├── *.md               # Various documentation files
│   └── guides/            # User and developer guides
│
├── config/                 # Configuration files
│   ├── constitutional_rules.yaml # Constitutional AI rules
│   ├── config.yaml        # System configuration
│   ├── .env               # Environment variables
│   └── requirements.txt   # Python dependencies
│
└── scripts/               # Utility scripts
    ├── start_system.sh    # System startup script
    ├── stop_system.sh     # System shutdown script
    └── check_status.sh    # System status check
```

## Key Components Overview

### Core System (`core/`)
- **Memory Manager**: Secure storage and retrieval of emotional memories with encryption
- **Memory Models**: Data structures for different types of memories (journal, emotional, general)
- **Memory Search**: Advanced search across temporal, emotional, and content dimensions
- **Journal Processor**: Structured reflection and mood tracking capabilities
- **Vault**: Document storage and management system
- **Database**: SQLite-based data persistence layer

### Emotional Processing (`emotional/`)
- **Emotional Processor**: Core emotional analysis and response generation
- **Emotion Detector**: Natural language processing for emotion identification
- **Crisis Detector**: Multi-level risk assessment and intervention protocols
- **Tone Engine**: Emotional consistency and response tone management
- **Big Mood System**: 5-color mood classification framework
- **Crisis Responder**: Emergency response and resource recommendation
- **Emotional Constitution**: Safety framework for emotional AI behavior

### Content Curation (`curation/`)
- **Curation API**: Unified interface for all curation operations
- **Content Filter**: Quality assessment and relevance scoring
- **RSS Processor**: Automated RSS feed monitoring and processing
- **Web Scraper**: Intelligent web content extraction
- **Source Manager**: Configuration and management of content sources
- **Feed Monitor**: Scheduling and monitoring of content sources

### Backup System (`backup/`)
- **Backup System**: Comprehensive Time Capsule backup with multiple strategies
- **Recovery Manager**: Point-in-time recovery and restoration capabilities

### Testing Framework (`tests/`)
- **Integration Tests**: End-to-end system validation
- **Component Tests**: Individual component validation
- **Performance Tests**: System performance and scalability validation
- **Security Tests**: Privacy and security validation

## Configuration Management

### Constitutional Rules (`config/constitutional_rules.yaml`)
Defines the AI behavior governance framework with user-defined rules for:
- Emotional safety protocols
- Crisis intervention procedures
- Privacy protection requirements
- User autonomy preservation

### System Configuration (`config/config.yaml`)
Core system settings including:
- Database configuration
- API endpoints and ports
- Processing parameters
- Security settings

### Environment Variables (`config/.env`)
Sensitive configuration including:
- Encryption keys
- API credentials
- Database passwords
- Security tokens

### Dependencies (`config/requirements.txt`)
Python package dependencies for:
- FastAPI web framework
- SQLite database operations
- Cryptography libraries
- Natural language processing
- Content processing tools

## Deployment Scripts

### System Startup (`scripts/start_system.sh`)
Automated system initialization including:
- Database setup and migration
- Service startup and configuration
- Health check validation
- Logging initialization

### System Shutdown (`scripts/stop_system.sh`)
Graceful system shutdown including:
- Service termination
- Database connection cleanup
- Backup completion
- Resource cleanup

### Status Monitoring (`scripts/check_status.sh`)
System health monitoring including:
- Service status validation
- Performance metrics collection
- Error log analysis
- Resource utilization monitoring

## Development Workflow

1. **Setup**: Use configuration files to establish development environment
2. **Development**: Work within modular component structure
3. **Testing**: Utilize comprehensive test suite for validation
4. **Deployment**: Use deployment scripts for consistent deployment
5. **Monitoring**: Employ status scripts for ongoing system health

## Integration Points

- **API Layer**: RESTful endpoints connecting all components
- **Database Layer**: Shared data persistence across components
- **Configuration Layer**: Centralized configuration management
- **Security Layer**: Consistent privacy and security implementation
- **Logging Layer**: Comprehensive system monitoring and debugging

This organized structure supports independent component development while maintaining system integration and consistency.

