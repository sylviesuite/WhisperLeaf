import ChatInterface from './components/ChatInterface.jsx'
import './App.css'

function App() {
  return <ChatInterface />
}

export default App
