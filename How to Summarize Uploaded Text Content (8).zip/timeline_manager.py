"""
WhisperLeaf Mood Timeline Manager
Manages emotional timeline tracking, pattern recognition, and growth analytics
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import sqlite3
import json
import logging
from pathlib import Path
import statistics
from collections import defaultdict, Counter

from .timeline_models import (
    MoodEntry, MoodPattern, TimelineSummary, GrowthMetric, 
    EmotionalInsight, TimelineVisualization, TimelineGranularity,
    MoodTrend, PatternType
)

logger = logging.getLogger(__name__)

class MoodTimelineManager:
    """
    Manages mood timeline tracking, pattern recognition, and emotional analytics
    """
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        self.db_path = self.data_dir / "mood_timeline.db"
        self.patterns_file = self.data_dir / "mood_patterns.json"
        self.insights_file = self.data_dir / "emotional_insights.json"
        
        # Initialize database
        self._init_database()
        
        # Load existing patterns and insights
        self.patterns = self._load_patterns()
        self.insights = self._load_insights()
        
        # Analytics cache
        self.analytics_cache = {}
        self.cache_expiry = {}
        
        # Timeline statistics
        self.timeline_stats = {
            'total_entries': 0,
            'entries_by_mood': defaultdict(int),
            'entries_by_source': defaultdict(int),
            'patterns_detected': 0,
            'insights_generated': 0,
            'last_entry': None,
            'first_entry': None,
            'tracking_days': 0
        }
        
        self._update_statistics()
        
        logger.info(f"MoodTimelineManager initialized with {self.timeline_stats['total_entries']} entries")
    
    def _init_database(self):
        """Initialize SQLite database for mood timeline"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS mood_entries (
                    entry_id TEXT PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    mood TEXT NOT NULL,
                    intensity REAL NOT NULL,
                    emotions TEXT NOT NULL,
                    context TEXT NOT NULL,
                    notes TEXT,
                    tags TEXT,
                    source TEXT DEFAULT 'manual',
                    confidence REAL DEFAULT 1.0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS growth_metrics (
                    metric_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    category TEXT,
                    baseline_value REAL,
                    current_value REAL,
                    target_value REAL,
                    measurement_unit TEXT,
                    tracking_period INTEGER,
                    last_updated TEXT,
                    trend TEXT,
                    milestones TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS timeline_summaries (
                    summary_id TEXT PRIMARY KEY,
                    period_start TEXT NOT NULL,
                    period_end TEXT NOT NULL,
                    granularity TEXT NOT NULL,
                    summary_data TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes for better performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_mood_entries_timestamp ON mood_entries(timestamp)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_mood_entries_mood ON mood_entries(mood)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_mood_entries_source ON mood_entries(source)")
    
    def _load_patterns(self) -> Dict[str, MoodPattern]:
        """Load mood patterns from file"""
        if not self.patterns_file.exists():
            return {}
        
        try:
            with open(self.patterns_file, 'r') as f:
                patterns_data = json.load(f)
            
            patterns = {}
            for pattern_id, pattern_data in patterns_data.items():
                patterns[pattern_id] = MoodPattern.from_dict(pattern_data)
            
            return patterns
        except Exception as e:
            logger.error(f"Error loading patterns: {e}")
            return {}
    
    def _save_patterns(self):
        """Save mood patterns to file"""
        try:
            patterns_data = {
                pattern_id: pattern.to_dict()
                for pattern_id, pattern in self.patterns.items()
            }
            
            with open(self.patterns_file, 'w') as f:
                json.dump(patterns_data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving patterns: {e}")
    
    def _load_insights(self) -> Dict[str, EmotionalInsight]:
        """Load emotional insights from file"""
        if not self.insights_file.exists():
            return {}
        
        try:
            with open(self.insights_file, 'r') as f:
                insights_data = json.load(f)
            
            insights = {}
            for insight_id, insight_data in insights_data.items():
                insights[insight_id] = EmotionalInsight(
                    insight_id=insight_data['insight_id'],
                    timestamp=datetime.fromisoformat(insight_data['timestamp']),
                    category=insight_data['category'],
                    title=insight_data['title'],
                    description=insight_data['description'],
                    confidence=insight_data['confidence'],
                    supporting_data=insight_data['supporting_data'],
                    actionable_suggestions=insight_data['actionable_suggestions'],
                    related_patterns=insight_data['related_patterns'],
                    priority=insight_data['priority']
                )
            
            return insights
        except Exception as e:
            logger.error(f"Error loading insights: {e}")
            return {}
    
    def _save_insights(self):
        """Save emotional insights to file"""
        try:
            insights_data = {
                insight_id: insight.to_dict()
                for insight_id, insight in self.insights.items()
            }
            
            with open(self.insights_file, 'w') as f:
                json.dump(insights_data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving insights: {e}")
    
    def _update_statistics(self):
        """Update timeline statistics"""
        with sqlite3.connect(self.db_path) as conn:
            # Total entries
            cursor = conn.execute("SELECT COUNT(*) FROM mood_entries")
            self.timeline_stats['total_entries'] = cursor.fetchone()[0]
            
            # Entries by mood
            cursor = conn.execute("SELECT mood, COUNT(*) FROM mood_entries GROUP BY mood")
            self.timeline_stats['entries_by_mood'] = dict(cursor.fetchall())
            
            # Entries by source
            cursor = conn.execute("SELECT source, COUNT(*) FROM mood_entries GROUP BY source")
            self.timeline_stats['entries_by_source'] = dict(cursor.fetchall())
            
            # First and last entries
            cursor = conn.execute("SELECT MIN(timestamp), MAX(timestamp) FROM mood_entries")
            result = cursor.fetchone()
            if result[0] and result[1]:
                self.timeline_stats['first_entry'] = datetime.fromisoformat(result[0])
                self.timeline_stats['last_entry'] = datetime.fromisoformat(result[1])
                
                # Calculate tracking days
                delta = self.timeline_stats['last_entry'] - self.timeline_stats['first_entry']
                self.timeline_stats['tracking_days'] = delta.days + 1
        
        # Pattern and insight counts
        self.timeline_stats['patterns_detected'] = len(self.patterns)
        self.timeline_stats['insights_generated'] = len(self.insights)
    
    def add_mood_entry(self, mood: str, intensity: float, emotions: List[str],
                      context: Dict[str, Any], notes: Optional[str] = None,
                      tags: Optional[List[str]] = None, source: str = "manual",
                      confidence: float = 1.0, timestamp: Optional[datetime] = None) -> str:
        """Add a new mood entry to the timeline"""
        
        if timestamp is None:
            timestamp = datetime.now()
        
        entry_id = f"mood_{timestamp.strftime('%Y%m%d_%H%M%S_%f')}"
        
        mood_entry = MoodEntry(
            entry_id=entry_id,
            timestamp=timestamp,
            mood=mood,
            intensity=intensity,
            emotions=emotions,
            context=context,
            notes=notes,
            tags=tags or [],
            source=source,
            confidence=confidence
        )
        
        # Store in database
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO mood_entries 
                (entry_id, timestamp, mood, intensity, emotions, context, notes, tags, source, confidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                entry_id,
                timestamp.isoformat(),
                mood,
                intensity,
                json.dumps(emotions),
                json.dumps(context),
                notes,
                json.dumps(tags or []),
                source,
                confidence
            ))
        
        # Update statistics
        self._update_statistics()
        
        # Clear relevant caches
        self._clear_analytics_cache()
        
        # Trigger pattern analysis if we have enough data
        if self.timeline_stats['total_entries'] % 10 == 0:  # Every 10 entries
            self._analyze_patterns()
        
        logger.info(f"Added mood entry: {mood} ({intensity}) at {timestamp}")
        
        return entry_id
    
    def get_mood_entries(self, start_date: Optional[datetime] = None,
                        end_date: Optional[datetime] = None,
                        mood_filter: Optional[List[str]] = None,
                        limit: Optional[int] = None) -> List[MoodEntry]:
        """Retrieve mood entries with optional filtering"""
        
        query = "SELECT * FROM mood_entries WHERE 1=1"
        params = []
        
        if start_date:
            query += " AND timestamp >= ?"
            params.append(start_date.isoformat())
        
        if end_date:
            query += " AND timestamp <= ?"
            params.append(end_date.isoformat())
        
        if mood_filter:
            placeholders = ','.join(['?' for _ in mood_filter])
            query += f" AND mood IN ({placeholders})"
            params.extend(mood_filter)
        
        query += " ORDER BY timestamp DESC"
        
        if limit:
            query += " LIMIT ?"
            params.append(limit)
        
        entries = []
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(query, params)
            for row in cursor.fetchall():
                entry = MoodEntry(
                    entry_id=row[0],
                    timestamp=datetime.fromisoformat(row[1]),
                    mood=row[2],
                    intensity=row[3],
                    emotions=json.loads(row[4]),
                    context=json.loads(row[5]),
                    notes=row[6],
                    tags=json.loads(row[7]) if row[7] else [],
                    source=row[8],
                    confidence=row[9]
                )
                entries.append(entry)
        
        return entries
    
    def get_timeline_summary(self, start_date: datetime, end_date: datetime,
                           granularity: TimelineGranularity = TimelineGranularity.DAILY) -> TimelineSummary:
        """Generate a timeline summary for a specific period"""
        
        # Check cache first
        cache_key = f"summary_{start_date.isoformat()}_{end_date.isoformat()}_{granularity.value}"
        if cache_key in self.analytics_cache:
            cache_time = self.cache_expiry.get(cache_key, datetime.min)
            if datetime.now() - cache_time < timedelta(hours=1):
                return self.analytics_cache[cache_key]
        
        entries = self.get_mood_entries(start_date, end_date)
        
        if not entries:
            return TimelineSummary(
                period_start=start_date,
                period_end=end_date,
                granularity=granularity,
                total_entries=0,
                mood_distribution={},
                average_intensity=0.0,
                dominant_mood="unknown",
                mood_trend=MoodTrend.UNKNOWN,
                volatility_score=0.0,
                growth_indicators=[],
                challenges_identified=[],
                patterns_detected=[],
                notable_events=[]
            )
        
        # Calculate mood distribution
        mood_counts = Counter(entry.mood for entry in entries)
        dominant_mood = mood_counts.most_common(1)[0][0] if mood_counts else "unknown"
        
        # Calculate average intensity
        intensities = [entry.intensity for entry in entries]
        average_intensity = statistics.mean(intensities)
        
        # Calculate volatility (standard deviation of intensities)
        volatility_score = statistics.stdev(intensities) if len(intensities) > 1 else 0.0
        
        # Determine mood trend
        mood_trend = self._calculate_mood_trend(entries)
        
        # Identify growth indicators and challenges
        growth_indicators = self._identify_growth_indicators(entries)
        challenges_identified = self._identify_challenges(entries)
        
        # Find relevant patterns
        relevant_patterns = [
            pattern.pattern_id for pattern in self.patterns.values()
            if pattern.start_date <= end_date and (pattern.end_date is None or pattern.end_date >= start_date)
        ]
        
        # Identify notable events
        notable_events = self._identify_notable_events(entries)
        
        summary = TimelineSummary(
            period_start=start_date,
            period_end=end_date,
            granularity=granularity,
            total_entries=len(entries),
            mood_distribution=dict(mood_counts),
            average_intensity=average_intensity,
            dominant_mood=dominant_mood,
            mood_trend=mood_trend,
            volatility_score=volatility_score,
            growth_indicators=growth_indicators,
            challenges_identified=challenges_identified,
            patterns_detected=relevant_patterns,
            notable_events=notable_events
        )
        
        # Cache the result
        self.analytics_cache[cache_key] = summary
        self.cache_expiry[cache_key] = datetime.now()
        
        return summary
    
    def _calculate_mood_trend(self, entries: List[MoodEntry]) -> MoodTrend:
        """Calculate overall mood trend from entries"""
        if len(entries) < 3:
            return MoodTrend.UNKNOWN
        
        # Sort by timestamp
        sorted_entries = sorted(entries, key=lambda x: x.timestamp)
        
        # Calculate trend based on intensity changes
        intensities = [entry.intensity for entry in sorted_entries]
        
        # Simple linear trend calculation
        n = len(intensities)
        x_values = list(range(n))
        
        # Calculate slope
        x_mean = statistics.mean(x_values)
        y_mean = statistics.mean(intensities)
        
        numerator = sum((x - x_mean) * (y - y_mean) for x, y in zip(x_values, intensities))
        denominator = sum((x - x_mean) ** 2 for x in x_values)
        
        if denominator == 0:
            return MoodTrend.STABLE
        
        slope = numerator / denominator
        
        # Determine trend based on slope and volatility
        volatility = statistics.stdev(intensities) if len(intensities) > 1 else 0
        
        if volatility > 0.3:  # High volatility
            return MoodTrend.VOLATILE
        elif slope > 0.05:  # Positive trend
            return MoodTrend.IMPROVING
        elif slope < -0.05:  # Negative trend
            return MoodTrend.DECLINING
        else:
            return MoodTrend.STABLE
    
    def _identify_growth_indicators(self, entries: List[MoodEntry]) -> List[str]:
        """Identify positive growth indicators from entries"""
        indicators = []
        
        # Check for positive emotions
        positive_emotions = ['joy', 'gratitude', 'peace', 'love', 'hope', 'confidence']
        for entry in entries:
            if any(emotion in positive_emotions for emotion in entry.emotions):
                indicators.append("Increased positive emotions")
                break
        
        # Check for self-awareness indicators
        awareness_keywords = ['understand', 'realize', 'learn', 'grow', 'insight']
        for entry in entries:
            if entry.notes and any(keyword in entry.notes.lower() for keyword in awareness_keywords):
                indicators.append("Enhanced self-awareness")
                break
        
        # Check for coping strategies
        coping_keywords = ['cope', 'manage', 'handle', 'strategy', 'technique']
        for entry in entries:
            if entry.notes and any(keyword in entry.notes.lower() for keyword in coping_keywords):
                indicators.append("Developing coping strategies")
                break
        
        return indicators
    
    def _identify_challenges(self, entries: List[MoodEntry]) -> List[str]:
        """Identify challenges from entries"""
        challenges = []
        
        # Check for negative emotion patterns
        negative_emotions = ['anxiety', 'depression', 'anger', 'fear', 'despair']
        negative_count = sum(1 for entry in entries 
                           if any(emotion in negative_emotions for emotion in entry.emotions))
        
        if negative_count > len(entries) * 0.6:  # More than 60% negative
            challenges.append("High frequency of difficult emotions")
        
        # Check for low intensity periods
        low_intensity_count = sum(1 for entry in entries if entry.intensity < 0.3)
        if low_intensity_count > len(entries) * 0.5:
            challenges.append("Extended periods of low emotional energy")
        
        # Check for crisis indicators
        crisis_keywords = ['crisis', 'emergency', 'help', 'can\'t cope', 'overwhelmed']
        for entry in entries:
            if entry.notes and any(keyword in entry.notes.lower() for keyword in crisis_keywords):
                challenges.append("Crisis or overwhelming situations")
                break
        
        return challenges
    
    def _identify_notable_events(self, entries: List[MoodEntry]) -> List[Dict[str, Any]]:
        """Identify notable events from entries"""
        events = []
        
        # Find significant mood changes
        sorted_entries = sorted(entries, key=lambda x: x.timestamp)
        for i in range(1, len(sorted_entries)):
            prev_entry = sorted_entries[i-1]
            curr_entry = sorted_entries[i]
            
            intensity_change = abs(curr_entry.intensity - prev_entry.intensity)
            if intensity_change > 0.5:  # Significant change
                events.append({
                    'type': 'mood_shift',
                    'timestamp': curr_entry.timestamp.isoformat(),
                    'description': f"Significant mood shift from {prev_entry.mood} to {curr_entry.mood}",
                    'intensity_change': intensity_change
                })
        
        # Find entries with detailed notes (likely significant)
        for entry in entries:
            if entry.notes and len(entry.notes) > 100:  # Detailed entry
                events.append({
                    'type': 'detailed_reflection',
                    'timestamp': entry.timestamp.isoformat(),
                    'description': f"Detailed reflection in {entry.mood} mood",
                    'note_length': len(entry.notes)
                })
        
        return events[:10]  # Return top 10 events
    
    def _analyze_patterns(self):
        """Analyze mood entries for patterns"""
        # Get recent entries for pattern analysis
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)  # Last 30 days
        entries = self.get_mood_entries(start_date, end_date)
        
        if len(entries) < 7:  # Need at least a week of data
            return
        
        # Analyze daily patterns
        self._analyze_daily_patterns(entries)
        
        # Analyze weekly patterns
        self._analyze_weekly_patterns(entries)
        
        # Analyze trigger-based patterns
        self._analyze_trigger_patterns(entries)
        
        # Save patterns
        self._save_patterns()
        
        logger.info(f"Pattern analysis complete. Found {len(self.patterns)} patterns.")
    
    def _analyze_daily_patterns(self, entries: List[MoodEntry]):
        """Analyze daily mood patterns"""
        # Group entries by hour of day
        hourly_moods = defaultdict(list)
        for entry in entries:
            hour = entry.timestamp.hour
            hourly_moods[hour].append(entry.mood)
        
        # Look for consistent patterns
        if len(hourly_moods) >= 3:  # At least 3 different hours
            # Find most common mood for each hour
            hourly_dominant = {}
            for hour, moods in hourly_moods.items():
                mood_counts = Counter(moods)
                if mood_counts.most_common(1)[0][1] >= 2:  # At least 2 occurrences
                    hourly_dominant[hour] = mood_counts.most_common(1)[0][0]
            
            if len(hourly_dominant) >= 2:
                pattern_id = f"daily_pattern_{datetime.now().strftime('%Y%m%d')}"
                pattern = MoodPattern(
                    pattern_id=pattern_id,
                    pattern_type=PatternType.DAILY_CYCLE,
                    name="Daily Mood Cycle",
                    description=f"Consistent mood patterns throughout the day",
                    start_date=min(entry.timestamp for entry in entries),
                    end_date=None,
                    frequency="daily",
                    strength=0.7,  # Moderate strength
                    mood_sequence=list(hourly_dominant.values()),
                    triggers=["time_of_day"],
                    context_factors={"hourly_patterns": hourly_dominant},
                    confidence=0.8,
                    examples=[entry.entry_id for entry in entries[:5]]
                )
                self.patterns[pattern_id] = pattern
    
    def _analyze_weekly_patterns(self, entries: List[MoodEntry]):
        """Analyze weekly mood patterns"""
        # Group entries by day of week
        weekly_moods = defaultdict(list)
        for entry in entries:
            day_of_week = entry.timestamp.weekday()  # 0 = Monday
            weekly_moods[day_of_week].append(entry.mood)
        
        # Look for consistent weekly patterns
        if len(weekly_moods) >= 5:  # At least 5 different days
            weekly_dominant = {}
            for day, moods in weekly_moods.items():
                mood_counts = Counter(moods)
                if mood_counts.most_common(1)[0][1] >= 2:
                    weekly_dominant[day] = mood_counts.most_common(1)[0][0]
            
            if len(weekly_dominant) >= 3:
                pattern_id = f"weekly_pattern_{datetime.now().strftime('%Y%m%d')}"
                pattern = MoodPattern(
                    pattern_id=pattern_id,
                    pattern_type=PatternType.WEEKLY_CYCLE,
                    name="Weekly Mood Cycle",
                    description="Consistent mood patterns throughout the week",
                    start_date=min(entry.timestamp for entry in entries),
                    end_date=None,
                    frequency="weekly",
                    strength=0.6,
                    mood_sequence=list(weekly_dominant.values()),
                    triggers=["day_of_week"],
                    context_factors={"weekly_patterns": weekly_dominant},
                    confidence=0.7,
                    examples=[entry.entry_id for entry in entries[:5]]
                )
                self.patterns[pattern_id] = pattern
    
    def _analyze_trigger_patterns(self, entries: List[MoodEntry]):
        """Analyze trigger-based patterns"""
        # Look for context-based triggers
        context_mood_map = defaultdict(list)
        
        for entry in entries:
            for key, value in entry.context.items():
                if isinstance(value, str):
                    context_mood_map[f"{key}:{value}"].append(entry.mood)
        
        # Find strong correlations
        for context_key, moods in context_mood_map.items():
            if len(moods) >= 3:  # At least 3 occurrences
                mood_counts = Counter(moods)
                dominant_mood = mood_counts.most_common(1)[0]
                
                if dominant_mood[1] / len(moods) >= 0.7:  # 70% consistency
                    pattern_id = f"trigger_pattern_{context_key.replace(':', '_')}"
                    pattern = MoodPattern(
                        pattern_id=pattern_id,
                        pattern_type=PatternType.TRIGGER_BASED,
                        name=f"Trigger Pattern: {context_key}",
                        description=f"Mood pattern triggered by {context_key}",
                        start_date=min(entry.timestamp for entry in entries),
                        end_date=None,
                        frequency="trigger_based",
                        strength=dominant_mood[1] / len(moods),
                        mood_sequence=[dominant_mood[0]],
                        triggers=[context_key],
                        context_factors={"trigger": context_key, "consistency": dominant_mood[1] / len(moods)},
                        confidence=0.8,
                        examples=[entry.entry_id for entry in entries if 
                                context_key.split(':')[0] in entry.context and 
                                str(entry.context[context_key.split(':')[0]]) == context_key.split(':')[1]][:3]
                    )
                    self.patterns[pattern_id] = pattern
    
    def _clear_analytics_cache(self):
        """Clear analytics cache"""
        self.analytics_cache.clear()
        self.cache_expiry.clear()
    
    def get_patterns(self, pattern_type: Optional[PatternType] = None) -> List[MoodPattern]:
        """Get mood patterns, optionally filtered by type"""
        patterns = list(self.patterns.values())
        
        if pattern_type:
            patterns = [p for p in patterns if p.pattern_type == pattern_type]
        
        return sorted(patterns, key=lambda x: x.confidence, reverse=True)
    
    def get_timeline_statistics(self) -> Dict[str, Any]:
        """Get comprehensive timeline statistics"""
        return {
            'timeline_stats': self.timeline_stats,
            'patterns_summary': {
                'total_patterns': len(self.patterns),
                'patterns_by_type': {
                    ptype.value: len([p for p in self.patterns.values() if p.pattern_type == ptype])
                    for ptype in PatternType
                },
                'average_pattern_strength': statistics.mean([p.strength for p in self.patterns.values()]) if self.patterns else 0
            },
            'insights_summary': {
                'total_insights': len(self.insights),
                'insights_by_category': Counter(insight.category for insight in self.insights.values()),
                'high_priority_insights': len([i for i in self.insights.values() if i.priority in ['high', 'urgent']])
            }
        }
    
    def generate_visualization_data(self, start_date: datetime, end_date: datetime,
                                  chart_type: str = "line") -> TimelineVisualization:
        """Generate data for timeline visualization"""
        entries = self.get_mood_entries(start_date, end_date)
        
        # Prepare data points
        data_points = []
        for entry in entries:
            data_points.append({
                'timestamp': entry.timestamp.isoformat(),
                'mood': entry.mood,
                'intensity': entry.intensity,
                'emotions': entry.emotions,
                'notes': entry.notes[:100] if entry.notes else None  # Truncate for display
            })
        
        # Create annotations for patterns and notable events
        annotations = []
        for pattern in self.patterns.values():
            if pattern.start_date <= end_date and (pattern.end_date is None or pattern.end_date >= start_date):
                annotations.append({
                    'type': 'pattern',
                    'timestamp': pattern.start_date.isoformat(),
                    'title': pattern.name,
                    'description': pattern.description
                })
        
        # Styling based on Big Mood colors
        styling = {
            'colors': {
                'blue': '#4A90E2',
                'green': '#7ED321',
                'yellow': '#F5A623',
                'purple': '#9013FE',
                'red': '#D0021B'
            },
            'theme': 'emotional_timeline',
            'responsive': True
        }
        
        visualization = TimelineVisualization(
            visualization_id=f"timeline_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}",
            title=f"Emotional Timeline: {start_date.strftime('%B %d')} - {end_date.strftime('%B %d, %Y')}",
            chart_type=chart_type,
            time_range=(start_date, end_date),
            granularity=TimelineGranularity.DAILY,
            data_points=data_points,
            annotations=annotations,
            styling=styling,
            interactive_elements=['zoom', 'hover', 'filter_by_mood', 'pattern_overlay']
        )
        
        return visualization

