"""
Chat API Server - Provides REST API for the Constitutional AI Chat Interface.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import logging
import sys
import os

# Add constitutional modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'constitutional'))

from constitutional.ai_governor import AIGovernor, AIResponse
from constitutional.constitution import ConstitutionalContext

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Sovereign AI Chat API",
    description="Constitutional AI-powered chat interface API",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize AI Governor
ai_governor = AIGovernor(
    ollama_url="http://localhost:11434",
    constitution_config="./data/chat_constitution.json"
)

# Pydantic models for API requests
class ChatMessage(BaseModel):
    user_id: str
    conversation_id: str
    message: str
    context: Optional[Dict[str, Any]] = None

class ConstitutionalRuleRequest(BaseModel):
    name: str
    description: str
    rule_type: str
    priority: str
    scope: str
    condition: str
    action: str
    tags: List[str] = []
    examples: List[str] = []

class UserPreferencesRequest(BaseModel):
    user_id: str
    preferences: Dict[str, Any]

# API Endpoints

@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "Sovereign AI Chat API",
        "version": "1.0.0",
        "status": "running",
        "description": "Constitutional AI-powered chat interface",
        "endpoints": {
            "chat": "/api/chat",
            "constitution": "/api/constitution",
            "preferences": "/api/preferences",
            "stats": "/api/stats"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "ai_governor": "active",
        "constitutional_engine": "active"
    }

@app.post("/api/chat")
async def chat(message_request: ChatMessage):
    """Process a chat message through constitutional AI governance."""
    try:
        logger.info(f"Processing chat message from user {message_request.user_id}")
        
        # Process message through AI Governor
        response = ai_governor.process_user_message(
            user_id=message_request.user_id,
            conversation_id=message_request.conversation_id,
            message=message_request.message,
            context=message_request.context or {}
        )
        
        # Convert response to API format
        api_response = {
            "success": True,
            "response": {
                "content": response.content,
                "model": response.model,
                "timestamp": response.timestamp.isoformat(),
                "generation_time_ms": response.generation_time_ms,
                "token_count": response.token_count,
                "confidence": response.confidence,
                "was_modified": response.was_modified,
                "modification_reason": response.modification_reason,
                "original_content": response.original_content if response.was_modified else None,
                "constitutional_decision": {
                    "allowed": response.constitutional_decision.allowed if response.constitutional_decision else True,
                    "confidence": response.constitutional_decision.confidence if response.constitutional_decision else 1.0,
                    "applied_rules": response.constitutional_decision.applied_rules if response.constitutional_decision else [],
                    "violated_rules": response.constitutional_decision.violated_rules if response.constitutional_decision else [],
                    "reasoning": response.constitutional_decision.reasoning if response.constitutional_decision else "",
                    "suggestions": response.constitutional_decision.suggestions if response.constitutional_decision else [],
                    "processing_time_ms": response.constitutional_decision.processing_time_ms if response.constitutional_decision else 0.0
                } if response.constitutional_decision else None
            },
            "conversation_id": message_request.conversation_id,
            "user_id": message_request.user_id
        }
        
        return api_response
        
    except Exception as e:
        logger.error(f"Error processing chat message: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

@app.get("/api/conversation/{conversation_id}")
async def get_conversation(conversation_id: str):
    """Get conversation history and summary."""
    try:
        summary = ai_governor.get_conversation_summary(conversation_id)
        
        # Get recent messages (simplified - in a real implementation, you'd store these)
        conversation_history = ai_governor._get_conversation_history(conversation_id)
        
        messages = []
        for msg in conversation_history[-20:]:  # Last 20 messages
            messages.append({
                "role": msg.role,
                "content": msg.content,
                "timestamp": msg.timestamp.isoformat(),
                "metadata": msg.metadata
            })
        
        return {
            "conversation_id": conversation_id,
            "summary": summary,
            "messages": messages
        }
        
    except Exception as e:
        logger.error(f"Error getting conversation {conversation_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

@app.post("/api/preferences")
async def set_user_preferences(preferences_request: UserPreferencesRequest):
    """Set user preferences for constitutional AI."""
    try:
        ai_governor.set_user_preferences(
            preferences_request.user_id,
            preferences_request.preferences
        )
        
        return {
            "success": True,
            "message": f"Preferences updated for user {preferences_request.user_id}",
            "preferences": preferences_request.preferences
        }
        
    except Exception as e:
        logger.error(f"Error setting preferences: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

@app.get("/api/preferences/{user_id}")
async def get_user_preferences(user_id: str):
    """Get user preferences."""
    try:
        preferences = ai_governor.user_preferences.get(user_id, {})
        
        return {
            "user_id": user_id,
            "preferences": preferences
        }
        
    except Exception as e:
        logger.error(f"Error getting preferences for user {user_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

@app.get("/api/constitution/rules")
async def list_constitutional_rules():
    """List all constitutional rules."""
    try:
        rules = ai_governor.constitutional_engine.list_rules(enabled_only=False)
        
        rules_data = []
        for rule in rules:
            rules_data.append({
                "id": rule.id,
                "name": rule.name,
                "description": rule.description,
                "rule_type": rule.rule_type.value,
                "priority": rule.priority.name,
                "scope": rule.scope.value,
                "condition": rule.condition,
                "action": rule.action,
                "enabled": rule.enabled,
                "weight": rule.weight,
                "tags": rule.tags,
                "examples": rule.examples,
                "times_applied": rule.times_applied,
                "times_violated": rule.times_violated,
                "created_at": rule.created_at.isoformat(),
                "last_applied": rule.last_applied.isoformat() if rule.last_applied else None
            })
        
        return {
            "rules": rules_data,
            "total_rules": len(rules_data)
        }
        
    except Exception as e:
        logger.error(f"Error listing constitutional rules: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

@app.post("/api/constitution/rules")
async def add_constitutional_rule(rule_request: ConstitutionalRuleRequest):
    """Add a new constitutional rule."""
    try:
        from constitutional.constitution import ConstitutionalRule, RuleType, RulePriority, RuleScope
        
        # Create rule object
        rule = ConstitutionalRule(
            id=f"{rule_request.name.lower().replace(' ', '_')}_{int(datetime.now().timestamp())}",
            name=rule_request.name,
            description=rule_request.description,
            rule_type=RuleType(rule_request.rule_type),
            priority=RulePriority[rule_request.priority.upper()],
            scope=RuleScope(rule_request.scope),
            condition=rule_request.condition,
            action=rule_request.action,
            tags=rule_request.tags,
            examples=rule_request.examples
        )
        
        success = ai_governor.constitutional_engine.add_rule(rule)
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to add constitutional rule")
        
        return {
            "success": True,
            "message": "Constitutional rule added successfully",
            "rule_id": rule.id,
            "rule": {
                "id": rule.id,
                "name": rule.name,
                "description": rule.description,
                "rule_type": rule.rule_type.value,
                "priority": rule.priority.name
            }
        }
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Invalid rule parameters: {e}")
    except Exception as e:
        logger.error(f"Error adding constitutional rule: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

@app.delete("/api/constitution/rules/{rule_id}")
async def delete_constitutional_rule(rule_id: str):
    """Delete a constitutional rule."""
    try:
        success = ai_governor.constitutional_engine.remove_rule(rule_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Constitutional rule not found")
        
        return {
            "success": True,
            "message": f"Constitutional rule {rule_id} deleted successfully"
        }
        
    except Exception as e:
        logger.error(f"Error deleting constitutional rule {rule_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

@app.get("/api/stats")
async def get_system_stats():
    """Get comprehensive system statistics."""
    try:
        governance_stats = ai_governor.get_governance_stats()
        
        return {
            "system": {
                "status": "running",
                "timestamp": datetime.now(timezone.utc).isoformat()
            },
            "governance": governance_stats,
            "api": {
                "version": "1.0.0",
                "endpoints_available": 12
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting system stats: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

@app.get("/api/stats/constitution")
async def get_constitution_stats():
    """Get constitutional engine statistics."""
    try:
        stats = ai_governor.constitutional_engine.get_constitution_stats()
        
        return {
            "constitution": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting constitution stats: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8003)

