import React from 'react';
import { MessageCircle, BookOpen, TrendingUp, Clock, Settings, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const Navigation = ({ currentView, onViewChange }) => {
  const navItems = [
    {
      id: 'chat',
      label: 'Chat',
      icon: MessageCircle,
      description: 'Talk with WhisperLeaf',
      color: 'from-green-400 to-blue-500'
    },
    {
      id: 'journal',
      label: 'Journal',
      icon: BookOpen,
      description: 'Write & reflect',
      color: 'from-purple-400 to-blue-500'
    },
    {
      id: 'timeline',
      label: 'Timeline',
      icon: TrendingUp,
      description: 'Mood patterns',
      color: 'from-blue-400 to-indigo-500'
    },
    {
      id: 'capsules',
      label: 'Time Capsules',
      icon: Clock,
      description: 'Future messages',
      color: 'from-indigo-400 to-purple-500'
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      description: 'AI rules & privacy',
      color: 'from-gray-400 to-gray-600'
    }
  ];

  return (
    <div className="bg-white/90 backdrop-blur-sm border-b border-gray-200 px-4 py-2">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-gray-800">WhisperLeaf</h1>
              <p className="text-xs text-gray-600">Sovereign Emotional AI</p>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <Button
                  key={item.id}
                  onClick={() => onViewChange(item.id)}
                  variant={isActive ? "default" : "ghost"}
                  className={`relative flex flex-col items-center space-y-1 h-auto py-2 px-3 ${
                    isActive 
                      ? `bg-gradient-to-r ${item.color} text-white hover:opacity-90` 
                      : 'hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-xs font-medium">{item.label}</span>
                  {isActive && (
                    <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full" />
                  )}
                </Button>
              );
            })}
          </div>

          {/* Status */}
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="bg-green-100 border-green-300 text-green-800 text-xs">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse" />
              Online
            </Badge>
            <Badge variant="outline" className="bg-blue-100 border-blue-300 text-blue-800 text-xs">
              Local AI
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navigation;

