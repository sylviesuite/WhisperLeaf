import React, { useState, useRef, useEffect } from 'react';
import { Save, Search, Calendar, Heart, Brain, Sparkles, BookOpen, Clock, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';

const JournalInterface = () => {
  const [journalEntry, setJournalEntry] = useState('');
  const [entryTitle, setEntryTitle] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [emotionalAnalysis, setEmotionalAnalysis] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [recentEntries, setRecentEntries] = useState([
    {
      id: 1,
      title: "Reflecting on Today's Challenges",
      content: "Today was particularly difficult. I found myself struggling with feelings of overwhelm as work demands increased. However, I'm grateful for the support from my colleagues and the small victories I achieved.",
      date: new Date(Date.now() - 86400000), // Yesterday
      mood: 'blue',
      emotions: ['overwhelmed', 'grateful', 'supported'],
      insights: ['Recognizing support systems', 'Finding gratitude in difficulty'],
      tags: ['work', 'gratitude', 'support']
    },
    {
      id: 2,
      title: "A Moment of Joy",
      content: "Spent the afternoon in the garden, watching the flowers bloom. There's something deeply peaceful about connecting with nature. I felt my anxiety melt away as I focused on the present moment.",
      date: new Date(Date.now() - 172800000), // 2 days ago
      mood: 'green',
      emotions: ['peaceful', 'present', 'connected'],
      insights: ['Nature as healing', 'Present moment awareness'],
      tags: ['nature', 'mindfulness', 'peace']
    },
    {
      id: 3,
      title: "Creative Breakthrough",
      content: "Had an amazing creative session today! Ideas were flowing freely and I felt completely in the zone. This is what I live for - those moments when everything clicks and creativity takes over.",
      date: new Date(Date.now() - 259200000), // 3 days ago
      mood: 'purple',
      emotions: ['inspired', 'focused', 'energized'],
      insights: ['Creative flow state', 'Passion-driven energy'],
      tags: ['creativity', 'flow', 'inspiration']
    }
  ]);

  const textareaRef = useRef(null);

  // Big Mood color mapping
  const moodColors = {
    blue: { bg: 'bg-blue-100', border: 'border-blue-300', text: 'text-blue-800', name: 'Reflective' },
    green: { bg: 'bg-green-100', border: 'border-green-300', text: 'text-green-800', name: 'Calm' },
    yellow: { bg: 'bg-yellow-100', border: 'border-yellow-300', text: 'text-yellow-800', name: 'Energetic' },
    purple: { bg: 'bg-purple-100', border: 'border-purple-300', text: 'text-purple-800', name: 'Creative' },
    red: { bg: 'bg-red-100', border: 'border-red-300', text: 'text-red-800', name: 'Intense' }
  };

  const analyzeEntry = async () => {
    if (!journalEntry.trim()) return;

    setIsAnalyzing(true);
    
    // Simulate emotional analysis
    setTimeout(() => {
      const analysis = performEmotionalAnalysis(journalEntry);
      setEmotionalAnalysis(analysis);
      setIsAnalyzing(false);
    }, 2000);
  };

  const performEmotionalAnalysis = (text) => {
    const lowerText = text.toLowerCase();
    
    // Simple emotion detection (in real app, this would use the emotional engine)
    let primaryMood = 'green';
    let emotions = [];
    let insights = [];
    let intensity = 0.5;

    if (lowerText.includes('anxious') || lowerText.includes('worried') || lowerText.includes('stressed')) {
      primaryMood = 'yellow';
      emotions = ['anxious', 'concerned', 'tense'];
      insights = ['Recognizing anxiety patterns', 'Opportunity for grounding techniques'];
      intensity = 0.7;
    } else if (lowerText.includes('sad') || lowerText.includes('down') || lowerText.includes('difficult')) {
      primaryMood = 'blue';
      emotions = ['reflective', 'processing', 'thoughtful'];
      insights = ['Processing difficult emotions', 'Growth through reflection'];
      intensity = 0.6;
    } else if (lowerText.includes('creative') || lowerText.includes('inspired') || lowerText.includes('ideas')) {
      primaryMood = 'purple';
      emotions = ['inspired', 'creative', 'energized'];
      insights = ['Creative energy flowing', 'Inspiration as fuel for growth'];
      intensity = 0.8;
    } else if (lowerText.includes('grateful') || lowerText.includes('peaceful') || lowerText.includes('calm')) {
      primaryMood = 'green';
      emotions = ['grateful', 'peaceful', 'centered'];
      insights = ['Cultivating gratitude', 'Finding inner peace'];
      intensity = 0.4;
    } else {
      emotions = ['reflective', 'aware', 'present'];
      insights = ['Self-awareness growing', 'Mindful observation'];
    }

    // Generate suggested tags
    const suggestedTags = [];
    if (lowerText.includes('work')) suggestedTags.push('work');
    if (lowerText.includes('family') || lowerText.includes('friend')) suggestedTags.push('relationships');
    if (lowerText.includes('nature') || lowerText.includes('garden')) suggestedTags.push('nature');
    if (lowerText.includes('creative') || lowerText.includes('art')) suggestedTags.push('creativity');
    if (lowerText.includes('grateful') || lowerText.includes('thankful')) suggestedTags.push('gratitude');

    return {
      primaryMood,
      emotions,
      insights,
      intensity,
      suggestedTags,
      wordCount: text.split(' ').length,
      sentiment: intensity > 0.6 ? 'challenging' : intensity < 0.4 ? 'positive' : 'neutral',
      themes: extractThemes(text)
    };
  };

  const extractThemes = (text) => {
    const themes = [];
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('growth') || lowerText.includes('learn') || lowerText.includes('develop')) {
      themes.push('Personal Growth');
    }
    if (lowerText.includes('relationship') || lowerText.includes('friend') || lowerText.includes('family')) {
      themes.push('Relationships');
    }
    if (lowerText.includes('work') || lowerText.includes('career') || lowerText.includes('job')) {
      themes.push('Career & Work');
    }
    if (lowerText.includes('health') || lowerText.includes('exercise') || lowerText.includes('wellness')) {
      themes.push('Health & Wellness');
    }
    if (lowerText.includes('creative') || lowerText.includes('art') || lowerText.includes('music')) {
      themes.push('Creativity & Expression');
    }
    
    return themes.length > 0 ? themes : ['Self-Reflection'];
  };

  const saveEntry = () => {
    if (!journalEntry.trim()) return;

    const newEntry = {
      id: Date.now(),
      title: entryTitle || `Journal Entry - ${new Date().toLocaleDateString()}`,
      content: journalEntry,
      date: new Date(),
      mood: emotionalAnalysis?.primaryMood || 'green',
      emotions: emotionalAnalysis?.emotions || ['reflective'],
      insights: emotionalAnalysis?.insights || [],
      tags: emotionalAnalysis?.suggestedTags || [],
      analysis: emotionalAnalysis
    };

    setRecentEntries(prev => [newEntry, ...prev]);
    setJournalEntry('');
    setEntryTitle('');
    setEmotionalAnalysis(null);
  };

  const searchEntries = (query) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    const results = recentEntries.filter(entry => 
      entry.title.toLowerCase().includes(query.toLowerCase()) ||
      entry.content.toLowerCase().includes(query.toLowerCase()) ||
      entry.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase())) ||
      entry.emotions.some(emotion => emotion.toLowerCase().includes(query.toLowerCase()))
    );

    setSearchResults(results);
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  useEffect(() => {
    if (journalEntry.length > 50) {
      const debounceTimer = setTimeout(() => {
        analyzeEntry();
      }, 1000);
      return () => clearTimeout(debounceTimer);
    }
  }, [journalEntry]);

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-purple-200 p-4">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-blue-500 rounded-full flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-800">Journal & Memory</h1>
              <p className="text-sm text-gray-600">Reflect, analyze, and explore your emotional journey</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="bg-purple-100 border-purple-300 text-purple-800">
              <Brain className="w-3 h-3 mr-1" />
              AI Analysis
            </Badge>
          </div>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Main Journal Area */}
        <div className="flex-1 p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* New Entry Card */}
            <Card className="bg-white/90 backdrop-blur-sm shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Heart className="w-5 h-5 text-purple-500" />
                  <span>New Journal Entry</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="entry-title">Entry Title (Optional)</Label>
                  <Input
                    id="entry-title"
                    value={entryTitle}
                    onChange={(e) => setEntryTitle(e.target.value)}
                    placeholder="Give your entry a meaningful title..."
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="journal-content">Your Thoughts & Feelings</Label>
                  <Textarea
                    id="journal-content"
                    ref={textareaRef}
                    value={journalEntry}
                    onChange={(e) => setJournalEntry(e.target.value)}
                    placeholder="Share what's on your mind and in your heart. Write freely about your thoughts, feelings, experiences, and reflections..."
                    className="mt-1 min-h-[200px] resize-none"
                    rows={8}
                  />
                  <div className="flex justify-between items-center mt-2 text-sm text-gray-500">
                    <span>{journalEntry.length} characters</span>
                    {journalEntry.length > 50 && (
                      <span className="flex items-center space-x-1">
                        <Brain className="w-3 h-3" />
                        <span>AI analysis {isAnalyzing ? 'in progress...' : 'ready'}</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Emotional Analysis */}
                {emotionalAnalysis && (
                  <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2 mb-3">
                        <Sparkles className="w-4 h-4 text-purple-500" />
                        <span className="font-medium text-purple-800">Emotional Analysis</span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-medium text-sm text-gray-700 mb-2">Primary Mood</h4>
                          <Badge className={`${moodColors[emotionalAnalysis.primaryMood].bg} ${moodColors[emotionalAnalysis.primaryMood].border} ${moodColors[emotionalAnalysis.primaryMood].text}`}>
                            {moodColors[emotionalAnalysis.primaryMood].name}
                          </Badge>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-sm text-gray-700 mb-2">Emotions Detected</h4>
                          <div className="flex flex-wrap gap-1">
                            {emotionalAnalysis.emotions.map((emotion, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {emotion}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-sm text-gray-700 mb-2">Key Insights</h4>
                          <ul className="text-sm text-gray-600 space-y-1">
                            {emotionalAnalysis.insights.map((insight, index) => (
                              <li key={index} className="flex items-start space-x-1">
                                <span className="text-purple-500 mt-1">•</span>
                                <span>{insight}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-sm text-gray-700 mb-2">Suggested Tags</h4>
                          <div className="flex flex-wrap gap-1">
                            {emotionalAnalysis.suggestedTags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs bg-blue-50">
                                <Tag className="w-2 h-2 mr-1" />
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="flex justify-end space-x-2">
                  <Button
                    onClick={analyzeEntry}
                    disabled={journalEntry.length < 10 || isAnalyzing}
                    variant="outline"
                  >
                    <Brain className="w-4 h-4 mr-2" />
                    {isAnalyzing ? 'Analyzing...' : 'Analyze'}
                  </Button>
                  <Button
                    onClick={saveEntry}
                    disabled={!journalEntry.trim()}
                    className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Entry
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Sidebar - Memory Search & Recent Entries */}
        <div className="w-80 bg-white/50 backdrop-blur-sm border-l border-purple-200 p-4">
          <div className="space-y-6">
            {/* Memory Search */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center space-x-2">
                  <Search className="w-4 h-4" />
                  <span>Memory Search</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    searchEntries(e.target.value);
                  }}
                  placeholder="Search your memories..."
                  className="mb-3"
                />
                
                {searchResults.length > 0 && (
                  <ScrollArea className="h-40">
                    <div className="space-y-2">
                      {searchResults.map((entry) => (
                        <div key={entry.id} className="p-2 bg-gray-50 rounded-lg text-xs">
                          <div className="font-medium truncate">{entry.title}</div>
                          <div className="text-gray-500 truncate">{entry.content.substring(0, 60)}...</div>
                          <div className="flex items-center space-x-1 mt-1">
                            <div className={`w-2 h-2 rounded-full ${moodColors[entry.mood].bg.replace('bg-', 'bg-')}`} />
                            <span className="text-gray-400">{formatDate(entry.date)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>

            {/* Recent Entries */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center space-x-2">
                  <Calendar className="w-4 h-4" />
                  <span>Recent Entries</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {recentEntries.map((entry) => (
                      <Card key={entry.id} className="p-3 bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer">
                        <div className="space-y-2">
                          <div className="flex items-start justify-between">
                            <h4 className="font-medium text-sm truncate flex-1">{entry.title}</h4>
                            <Badge className={`ml-2 ${moodColors[entry.mood].bg} ${moodColors[entry.mood].border} ${moodColors[entry.mood].text} text-xs`}>
                              {moodColors[entry.mood].name}
                            </Badge>
                          </div>
                          
                          <p className="text-xs text-gray-600 line-clamp-2">
                            {entry.content.substring(0, 100)}...
                          </p>
                          
                          <div className="flex items-center justify-between text-xs text-gray-500">
                            <div className="flex items-center space-x-1">
                              <Clock className="w-3 h-3" />
                              <span>{formatDate(entry.date)}</span>
                            </div>
                            <div className="flex space-x-1">
                              {entry.tags.slice(0, 2).map((tag, index) => (
                                <Badge key={index} variant="outline" className="text-xs px-1 py-0">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JournalInterface;

