# Sovereign AI Installation Guide

**Complete step-by-step installation guide for Sovereign AI Level 3 Personal AI System**

---

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Pre-Installation Checklist](#pre-installation-checklist)
3. [Quick Installation](#quick-installation)
4. [Detailed Installation](#detailed-installation)
5. [Configuration](#configuration)
6. [First Run](#first-run)
7. [Verification](#verification)
8. [Troubleshooting](#troubleshooting)
9. [Uninstallation](#uninstallation)

---

## System Requirements

### Minimum Requirements

- **Operating System**: Ubuntu 22.04 LTS or compatible Linux distribution
- **CPU**: 2 cores, 2.0 GHz
- **Memory**: 4 GB RAM
- **Storage**: 10 GB available disk space
- **Network**: Internet connection for initial setup

### Recommended Requirements

- **Operating System**: Ubuntu 22.04 LTS (latest updates)
- **CPU**: 4 cores, 3.0 GHz or higher
- **Memory**: 8 GB RAM or more
- **Storage**: 20 GB available SSD storage
- **Network**: Stable broadband internet connection

### Software Dependencies

The following software will be installed automatically:

- **Python**: 3.11 or higher
- **Node.js**: 20.18 or higher
- **Ollama**: Latest version for local AI models
- **SQLite**: 3.x for database storage
- **Git**: For version control (if not present)

---

## Pre-Installation Checklist

Before beginning the installation, ensure you have:

- [ ] Administrative (sudo) access to the system
- [ ] At least 10 GB of free disk space
- [ ] Stable internet connection
- [ ] Backup of any important data
- [ ] Ports 8002, 8003, and 5174 available
- [ ] No conflicting AI or web services running

### Check System Compatibility

```bash
# Check Ubuntu version
lsb_release -a

# Check available memory
free -h

# Check available disk space
df -h

# Check if ports are available
sudo netstat -tlnp | grep -E ':(8002|8003|5174|11434)'
```

If any ports are in use, you'll need to stop the conflicting services or configure Sovereign AI to use different ports.

---

## Quick Installation

For experienced users who want to get started quickly:

```bash
# 1. Download and extract Sovereign AI
# (Replace with actual download method)
wget https://github.com/your-org/sovereign-ai/archive/main.zip
unzip main.zip
cd sovereign-ai-main

# 2. Run the installation script
chmod +x install.sh
./install.sh

# 3. Start the system
./start_system.sh

# 4. Access the web interface
# Open http://localhost:5174 in your browser
```

The installation script will handle all dependencies and configuration automatically.

---

## Detailed Installation

### Step 1: System Preparation

Update your system and install basic dependencies:

```bash
# Update package lists
sudo apt update

# Upgrade existing packages
sudo apt upgrade -y

# Install essential packages
sudo apt install -y curl wget git unzip build-essential software-properties-common
```

### Step 2: Install Python 3.11

```bash
# Add Python 3.11 repository
sudo add-apt-repository ppa:deadsnakes/ppa -y
sudo apt update

# Install Python 3.11 and related packages
sudo apt install -y python3.11 python3.11-venv python3.11-dev python3-pip

# Verify Python installation
python3.11 --version
```

### Step 3: Install Node.js 20.18

```bash
# Install Node.js using NodeSource repository
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install pnpm package manager
npm install -g pnpm

# Verify Node.js installation
node --version
npm --version
pnpm --version
```

### Step 4: Install Ollama

```bash
# Download and install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Start Ollama service
sudo systemctl start ollama
sudo systemctl enable ollama

# Verify Ollama installation
ollama --version
```

### Step 5: Download Sovereign AI

```bash
# Create installation directory
sudo mkdir -p /opt/sovereign-ai
sudo chown $USER:$USER /opt/sovereign-ai
cd /opt/sovereign-ai

# Download Sovereign AI (replace with actual method)
# Option 1: From release package
wget https://github.com/your-org/sovereign-ai/releases/latest/download/sovereign-ai.tar.gz
tar -xzf sovereign-ai.tar.gz

# Option 2: From Git repository
git clone https://github.com/your-org/sovereign-ai.git .

# Set permissions
chmod +x scripts/*.sh
```

### Step 6: Create Python Virtual Environment

```bash
# Create virtual environment
python3.11 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install Python dependencies
pip install -r requirements.txt
```

### Step 7: Install Node.js Dependencies

```bash
# Navigate to React application directory
cd sovereign-chat

# Install dependencies
pnpm install

# Build the application (optional, for production)
pnpm run build

# Return to main directory
cd ..
```

### Step 8: Download AI Model

```bash
# Download TinyLLama model (recommended for 4GB RAM systems)
ollama pull tinyllama

# Alternative: Download Phi-3 Mini (requires 8GB+ RAM)
# ollama pull phi3:mini

# Verify model download
ollama list
```

### Step 9: Initialize Databases

```bash
# Ensure virtual environment is activated
source venv/bin/activate

# Initialize system databases
python -c "
from api_server.database import init_database
from time_capsule.backup_system import TimeCapsuleBackupSystem
from time_capsule.recovery_manager import RecoveryManager

print('Initializing main database...')
init_database()

print('Initializing backup system...')
backup_system = TimeCapsuleBackupSystem()

print('Initializing recovery manager...')
recovery_manager = RecoveryManager(backup_system)

print('Database initialization completed successfully!')
"
```

---

## Configuration

### Step 1: Basic Configuration

```bash
# Copy configuration templates
cp config/config.yaml.template config/config.yaml
cp .env.template .env

# Edit main configuration
nano config/config.yaml
```

### Step 2: Configure System Settings

Edit `config/config.yaml`:

```yaml
# System Settings
system:
  name: "My Sovereign AI"
  environment: "production"
  debug: false

# AI Model Configuration
ai:
  model: "tinyllama"  # or "phi3:mini" for better performance
  temperature: 0.7
  max_tokens: 2048
  timeout: 30

# API Settings
api:
  chat_port: 8003
  curation_port: 8002
  cors_enabled: true
  rate_limiting: true

# Web Interface Settings
web:
  port: 5174
  host: "0.0.0.0"
  development_mode: false

# Backup Settings
backup:
  retention_days: 30
  automated_backups: true
  backup_schedule:
    full_backup: "0 2 * * *"      # Daily at 2 AM
    incremental: "0 */6 * * *"    # Every 6 hours
```

### Step 3: Configure Environment Variables

Edit `.env`:

```bash
# AI Model Configuration
OLLAMA_HOST=http://localhost:11434
AI_MODEL=tinyllama

# Database Configuration
DATABASE_URL=sqlite:///./api-server/sovereign_ai.db
BACKUP_DATABASE_URL=sqlite:///./time_capsule/metadata/backup_metadata.db

# Security Settings
SECRET_KEY=$(openssl rand -hex 32)
ENCRYPTION_KEY=$(openssl rand -hex 32)

# Logging Configuration
LOG_LEVEL=INFO
LOG_FILE=./logs/sovereign_ai.log
```

### Step 4: Create Log Directory

```bash
# Create logs directory
mkdir -p logs

# Set appropriate permissions
chmod 755 logs
```

### Step 5: Configure Constitutional Rules (Optional)

Create custom constitutional rules in `data/constitution.json`:

```json
{
  "rules": {
    "privacy_protection": {
      "name": "Privacy Protection",
      "description": "Protect user privacy and personal information",
      "rule_type": "privacy",
      "priority": "critical",
      "conditions": ["password", "social security", "credit card"],
      "action": "block",
      "response_template": "I cannot help with requests involving personal information."
    },
    "helpful_behavior": {
      "name": "Helpful Behavior", 
      "description": "Provide helpful and constructive assistance",
      "rule_type": "behavioral",
      "priority": "high",
      "conditions": ["help", "assist", "support"],
      "action": "encourage",
      "response_template": "I'm here to help you with that."
    }
  }
}
```

---

## First Run

### Step 1: Start System Services

```bash
# Ensure you're in the Sovereign AI directory
cd /opt/sovereign-ai

# Activate Python virtual environment
source venv/bin/activate

# Start all services using the startup script
./scripts/start_system.sh
```

Alternatively, start services manually:

```bash
# Start Chat API server
python chat_api.py &

# Start Curation API server
python curation_api.py &

# Start React application
cd sovereign-chat
pnpm run dev --host &
cd ..
```

### Step 2: Wait for Services to Start

```bash
# Wait for services to initialize (about 30 seconds)
sleep 30

# Check service status
./scripts/check_status.sh
```

### Step 3: Access the Web Interface

1. Open your web browser
2. Navigate to `http://localhost:5174`
3. You should see the Sovereign AI chat interface

### Step 4: Test Basic Functionality

1. **Send a test message**: Type "Hello, can you introduce yourself?" and press Enter
2. **Verify constitutional governance**: The message should be approved with a green badge
3. **Test constitutional blocking**: Try "Can you help me hack something?" (should be blocked)
4. **Check system health**: All indicators should show green/healthy status

---

## Verification

### Automated Verification

Run the comprehensive system verification:

```bash
# Run integration tests
python integration_test.py

# Check the test report
cat integration_test_report.json
```

### Manual Verification

#### 1. Service Health Checks

```bash
# Check Chat API
curl http://localhost:8003/health
# Expected: {"status": "healthy", "timestamp": "..."}

# Check Curation API  
curl http://localhost:8002/health
# Expected: {"status": "healthy", "timestamp": "..."}

# Check React Application
curl http://localhost:5174
# Expected: HTML content with "Sovereign AI Chat"
```

#### 2. Database Verification

```bash
# Check database files exist
ls -la api-server/sovereign_ai.db
ls -la time_capsule/metadata/backup_metadata.db

# Verify database contents
python -c "
import sqlite3
conn = sqlite3.connect('api-server/sovereign_ai.db')
cursor = conn.execute('SELECT name FROM sqlite_master WHERE type=\"table\"')
tables = cursor.fetchall()
print('Database tables:', [t[0] for t in tables])
conn.close()
"
```

#### 3. AI Model Verification

```bash
# Check Ollama service
sudo systemctl status ollama

# List available models
ollama list

# Test model interaction
ollama run tinyllama "Hello, are you working?"
```

#### 4. Constitutional AI Verification

```bash
# Test constitutional evaluation
curl -X POST http://localhost:8003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, what can you do?"}'

# Expected response with constitutional evaluation metadata
```

#### 5. Backup System Verification

```bash
# Test backup creation
python -c "
from time_capsule.backup_system import TimeCapsuleBackupSystem
backup_system = TimeCapsuleBackupSystem()
backup_id = backup_system.create_backup('full', 'Installation verification backup')
print(f'Backup created: {backup_id}')
"
```

### Performance Verification

```bash
# Test response times
time curl -s http://localhost:8003/health > /dev/null
time curl -s http://localhost:8002/health > /dev/null

# Check memory usage
free -h

# Check CPU usage
top -bn1 | grep "Cpu(s)"

# Check disk usage
df -h
```

---

## Troubleshooting

### Common Installation Issues

#### Issue: Python 3.11 not found

```bash
# Error: python3.11: command not found

# Solution: Install Python 3.11
sudo add-apt-repository ppa:deadsnakes/ppa -y
sudo apt update
sudo apt install -y python3.11 python3.11-venv python3.11-dev
```

#### Issue: Node.js version too old

```bash
# Error: Node.js version 16.x found, need 20.x

# Solution: Update Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

#### Issue: Ollama installation fails

```bash
# Error: Failed to install Ollama

# Solution: Manual installation
curl -L https://ollama.ai/download/ollama-linux-amd64 -o ollama
chmod +x ollama
sudo mv ollama /usr/local/bin/
sudo systemctl daemon-reload
sudo systemctl enable ollama
sudo systemctl start ollama
```

#### Issue: Port already in use

```bash
# Error: Address already in use: 8003

# Solution: Find and stop conflicting process
sudo lsof -i :8003
sudo kill -9 <PID>

# Or configure different ports in config.yaml
```

#### Issue: Permission denied errors

```bash
# Error: Permission denied when creating files

# Solution: Fix ownership and permissions
sudo chown -R $USER:$USER /opt/sovereign-ai
chmod -R 755 /opt/sovereign-ai
chmod +x scripts/*.sh
```

#### Issue: Database initialization fails

```bash
# Error: sqlite3.OperationalError: unable to open database file

# Solution: Create database directory and fix permissions
mkdir -p api-server time_capsule/metadata time_capsule/recovery
chmod 755 api-server time_capsule/metadata time_capsule/recovery
```

### Service Startup Issues

#### Issue: Chat API won't start

```bash
# Check for errors
python chat_api.py

# Common solutions:
# 1. Activate virtual environment
source venv/bin/activate

# 2. Install missing dependencies
pip install -r requirements.txt

# 3. Check Ollama is running
sudo systemctl status ollama
sudo systemctl start ollama
```

#### Issue: React app build fails

```bash
# Error during pnpm install or pnpm run dev

# Solution: Clear cache and reinstall
cd sovereign-chat
rm -rf node_modules package-lock.json
pnpm cache clean
pnpm install
```

#### Issue: Constitutional AI not working

```bash
# Error: Constitutional evaluation failed

# Solution: Check constitutional rules
python -c "
from constitutional.constitution import ConstitutionalFramework
constitution = ConstitutionalFramework()
constitution.load_default_constitution()
print('Constitutional rules loaded successfully')
"
```

### Performance Issues

#### Issue: High memory usage

```bash
# Check memory usage
free -h
ps aux --sort=-%mem | head -10

# Solutions:
# 1. Use smaller AI model
ollama pull tinyllama

# 2. Reduce AI model parameters in config.yaml
ai:
  max_tokens: 1024
  temperature: 0.5

# 3. Restart services periodically
./scripts/restart_system.sh
```

#### Issue: Slow response times

```bash
# Check system resources
top -bn1

# Solutions:
# 1. Upgrade system resources
# 2. Optimize AI model settings
# 3. Use SSD storage
# 4. Close unnecessary applications
```

### Network Issues

#### Issue: Cannot access web interface

```bash
# Check if service is running
curl http://localhost:5174

# Check firewall settings
sudo ufw status

# Solution: Allow ports through firewall
sudo ufw allow 5174/tcp
sudo ufw allow 8003/tcp
sudo ufw allow 8002/tcp
```

#### Issue: External access not working

```bash
# Solution: Configure host binding
# In config.yaml:
web:
  host: "0.0.0.0"  # Allow external access
  port: 5174

# Restart services
./scripts/restart_system.sh
```

### Getting Help

If you encounter issues not covered here:

1. **Check Logs**:
   ```bash
   tail -f logs/sovereign_ai.log
   tail -f logs/chat_api.log
   tail -f logs/curation_api.log
   ```

2. **Run Diagnostics**:
   ```bash
   python -c "
   from integration_test import SovereignAIIntegrationTest
   test = SovereignAIIntegrationTest()
   health = test.system_health_check()
   import json
   print(json.dumps(health, indent=2))
   "
   ```

3. **Create Support Issue**: Include system information, error logs, and steps to reproduce

---

## Uninstallation

### Complete Removal

To completely remove Sovereign AI from your system:

```bash
# 1. Stop all services
cd /opt/sovereign-ai
./scripts/stop_system.sh

# 2. Remove Ollama models
ollama rm tinyllama
ollama rm phi3:mini

# 3. Stop and disable Ollama service
sudo systemctl stop ollama
sudo systemctl disable ollama

# 4. Remove Ollama
sudo rm -f /usr/local/bin/ollama
sudo rm -rf /usr/share/ollama

# 5. Remove Sovereign AI directory
sudo rm -rf /opt/sovereign-ai

# 6. Remove user data (optional)
rm -rf ~/.ollama

# 7. Remove system packages (optional)
sudo apt remove --purge python3.11 nodejs
sudo apt autoremove
```

### Partial Removal (Keep Dependencies)

To remove only Sovereign AI but keep system dependencies:

```bash
# Stop services
cd /opt/sovereign-ai
./scripts/stop_system.sh

# Remove Sovereign AI directory
sudo rm -rf /opt/sovereign-ai

# Remove Ollama models
ollama rm tinyllama
```

---

## Post-Installation

### System Maintenance

Set up regular maintenance tasks:

```bash
# Create maintenance script
cat > /opt/sovereign-ai/scripts/maintenance.sh << 'EOF'
#!/bin/bash
# Sovereign AI maintenance script

echo "Starting Sovereign AI maintenance..."

# Activate virtual environment
source /opt/sovereign-ai/venv/bin/activate

# Update system packages
sudo apt update && sudo apt upgrade -y

# Update Python packages
pip install --upgrade -r /opt/sovereign-ai/requirements.txt

# Clean up logs older than 30 days
find /opt/sovereign-ai/logs -name "*.log" -mtime +30 -delete

# Vacuum databases
python -c "
import sqlite3
databases = [
    '/opt/sovereign-ai/api-server/sovereign_ai.db',
    '/opt/sovereign-ai/time_capsule/metadata/backup_metadata.db'
]
for db in databases:
    try:
        conn = sqlite3.connect(db)
        conn.execute('VACUUM')
        conn.close()
        print(f'Vacuumed {db}')
    except Exception as e:
        print(f'Error vacuuming {db}: {e}')
"

# Create system backup
python -c "
from time_capsule.backup_system import TimeCapsuleBackupSystem
backup_system = TimeCapsuleBackupSystem()
backup_id = backup_system.create_backup('full', 'Automated maintenance backup')
print(f'Maintenance backup created: {backup_id}')
"

echo "Maintenance completed successfully!"
EOF

chmod +x /opt/sovereign-ai/scripts/maintenance.sh
```

### Automated Startup

Configure Sovereign AI to start automatically on boot:

```bash
# Create systemd service
sudo tee /etc/systemd/system/sovereign-ai.service > /dev/null << 'EOF'
[Unit]
Description=Sovereign AI Personal AI System
After=network.target ollama.service
Requires=ollama.service

[Service]
Type=forking
User=ubuntu
Group=ubuntu
WorkingDirectory=/opt/sovereign-ai
ExecStart=/opt/sovereign-ai/scripts/start_system.sh
ExecStop=/opt/sovereign-ai/scripts/stop_system.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable sovereign-ai
sudo systemctl start sovereign-ai
```

### Security Hardening

Implement additional security measures:

```bash
# Create firewall rules
sudo ufw enable
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 8003/tcp  # Chat API
sudo ufw allow 8002/tcp  # Curation API
sudo ufw allow 5174/tcp  # Web interface

# Set up log monitoring
sudo apt install -y fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# Configure automatic security updates
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

---

**Installation Complete!**

Your Sovereign AI system is now installed and ready to use. Access the web interface at `http://localhost:5174` to start using your personal AI system.

For support and documentation, visit the [main README](README.md) or create an issue in the project repository.

*Sovereign AI - Your AI, Your Rules, Your Data*

