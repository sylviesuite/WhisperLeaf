# Sovereign AI Deployment Guide

**Complete deployment guide for Sovereign AI Level 3 Personal AI System**

---

## Table of Contents

1. [Deployment Overview](#deployment-overview)
2. [Local Development Deployment](#local-development-deployment)
3. [Production Deployment](#production-deployment)
4. [Cloud Deployment](#cloud-deployment)
5. [Docker Deployment](#docker-deployment)
6. [Security Hardening](#security-hardening)
7. [Monitoring and Maintenance](#monitoring-and-maintenance)
8. [Backup and Recovery](#backup-and-recovery)
9. [Troubleshooting](#troubleshooting)

---

## Deployment Overview

Sovereign AI can be deployed in several configurations depending on your needs:

### Deployment Types

1. **Local Development**: Single-machine setup for development and testing
2. **Production Local**: Hardened single-machine setup for personal use
3. **Cloud Instance**: Deployed on cloud providers (AWS, GCP, Azure, DigitalOcean)
4. **Docker Container**: Containerized deployment for easy management
5. **Distributed**: Multi-machine setup for high availability (advanced)

### System Requirements by Deployment Type

| Deployment Type | CPU | RAM | Storage | Network |
|----------------|-----|-----|---------|---------|
| Development | 2 cores | 4GB | 10GB | Local |
| Production Local | 4 cores | 8GB | 50GB SSD | Broadband |
| Cloud Instance | 4 cores | 8GB | 50GB SSD | Cloud Network |
| Docker | 4 cores | 8GB | 20GB | Container Network |

---

## Local Development Deployment

### Quick Start

```bash
# 1. Clone or extract Sovereign AI
cd /opt/sovereign-ai

# 2. Run the installation script
./scripts/install.sh

# 3. Start the system
./scripts/start_system.sh

# 4. Access the interface
# Open http://localhost:5174 in your browser
```

### Manual Development Setup

```bash
# 1. Install system dependencies
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3.11 python3.11-venv nodejs npm git curl

# 2. Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh
sudo systemctl start ollama
sudo systemctl enable ollama

# 3. Download AI model
ollama pull tinyllama

# 4. Set up Python environment
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 5. Install Node.js dependencies
cd sovereign-chat
npm install -g pnpm
pnpm install
cd ..

# 6. Initialize databases
python -c "
from api_server.database import init_database
from time_capsule.backup_system import TimeCapsuleBackupSystem
init_database()
TimeCapsuleBackupSystem()
"

# 7. Start services
./scripts/start_system.sh
```

### Development Configuration

Create `config/development.yaml`:

```yaml
system:
  name: "Sovereign AI Development"
  environment: "development"
  debug: true

ai:
  model: "tinyllama"
  temperature: 0.7
  max_tokens: 2048

api:
  chat_port: 8003
  curation_port: 8002
  cors_enabled: true
  rate_limiting: false  # Disabled for development

web:
  port: 5174
  host: "localhost"
  development_mode: true

logging:
  level: "DEBUG"
  console_output: true
```

---

## Production Deployment

### Production Setup

```bash
# 1. Create production user
sudo useradd -m -s /bin/bash sovereign-ai
sudo usermod -aG sudo sovereign-ai

# 2. Set up production directory
sudo mkdir -p /opt/sovereign-ai
sudo chown sovereign-ai:sovereign-ai /opt/sovereign-ai
sudo -u sovereign-ai -i

# 3. Install Sovereign AI
cd /opt/sovereign-ai
# Extract production package here
tar -xzf sovereign-ai-production.tar.gz

# 4. Run production installation
./scripts/install_production.sh

# 5. Configure system service
sudo cp scripts/sovereign-ai.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable sovereign-ai
sudo systemctl start sovereign-ai
```

### Production Configuration

Create `config/production.yaml`:

```yaml
system:
  name: "Sovereign AI Production"
  environment: "production"
  debug: false

ai:
  model: "phi3:mini"  # Better model for production
  temperature: 0.5
  max_tokens: 4096
  timeout: 60

api:
  chat_port: 8003
  curation_port: 8002
  cors_enabled: true
  rate_limiting: true
  max_requests_per_minute: 60

web:
  port: 5174
  host: "0.0.0.0"  # Allow external access
  development_mode: false

security:
  api_key_required: true
  session_timeout: 3600
  max_login_attempts: 5

backup:
  automated_backups: true
  retention_days: 90
  backup_schedule:
    full_backup: "0 2 * * 0"      # Weekly full backup
    incremental: "0 2 * * 1-6"    # Daily incremental

logging:
  level: "INFO"
  file_rotation: true
  max_file_size: "100MB"
  backup_count: 10
```

### Systemd Service Configuration

Create `/etc/systemd/system/sovereign-ai.service`:

```ini
[Unit]
Description=Sovereign AI Personal AI System
After=network.target ollama.service
Requires=ollama.service
StartLimitIntervalSec=0

[Service]
Type=forking
User=sovereign-ai
Group=sovereign-ai
WorkingDirectory=/opt/sovereign-ai
ExecStart=/opt/sovereign-ai/scripts/start_system.sh
ExecStop=/opt/sovereign-ai/scripts/stop_system.sh
ExecReload=/bin/kill -HUP $MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/sovereign-ai

# Resource limits
LimitNOFILE=65536
LimitNPROC=4096

[Install]
WantedBy=multi-user.target
```

### Nginx Reverse Proxy (Optional)

Install and configure Nginx for SSL termination:

```bash
# Install Nginx
sudo apt install -y nginx certbot python3-certbot-nginx

# Create Nginx configuration
sudo tee /etc/nginx/sites-available/sovereign-ai << 'EOF'
server {
    listen 80;
    server_name your-domain.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;
    
    # SSL configuration
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_prefer_server_ciphers off;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload";
    
    # Main application
    location / {
        proxy_pass http://localhost:5174;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Chat API
    location /api/chat {
        proxy_pass http://localhost:8003;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Curation API
    location /api/curation {
        proxy_pass http://localhost:8002;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# Enable the site
sudo ln -s /etc/nginx/sites-available/sovereign-ai /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Get SSL certificate
sudo certbot --nginx -d your-domain.com
```

---

## Cloud Deployment

### AWS EC2 Deployment

#### 1. Launch EC2 Instance

```bash
# Launch Ubuntu 22.04 LTS instance
# Recommended: t3.large (2 vCPU, 8GB RAM)
# Storage: 50GB gp3 SSD
# Security Group: Allow ports 22, 80, 443, 5174, 8002, 8003
```

#### 2. Initial Server Setup

```bash
# Connect to instance
ssh -i your-key.pem ubuntu@your-ec2-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y python3.11 python3.11-venv nodejs npm git curl nginx

# Create swap file (recommended for 8GB RAM)
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

#### 3. Deploy Sovereign AI

```bash
# Create application directory
sudo mkdir -p /opt/sovereign-ai
sudo chown ubuntu:ubuntu /opt/sovereign-ai

# Download and extract Sovereign AI
cd /opt/sovereign-ai
wget https://github.com/your-org/sovereign-ai/releases/latest/download/sovereign-ai.tar.gz
tar -xzf sovereign-ai.tar.gz

# Run installation
./scripts/install_production.sh

# Configure for cloud deployment
cp config/production.yaml.template config/production.yaml
# Edit configuration as needed

# Start services
sudo systemctl enable sovereign-ai
sudo systemctl start sovereign-ai
```

#### 4. Configure Security Groups

```bash
# AWS CLI commands to configure security groups
aws ec2 authorize-security-group-ingress \
    --group-id sg-your-security-group \
    --protocol tcp \
    --port 80 \
    --cidr 0.0.0.0/0

aws ec2 authorize-security-group-ingress \
    --group-id sg-your-security-group \
    --protocol tcp \
    --port 443 \
    --cidr 0.0.0.0/0

# Restrict API ports to specific IPs if needed
aws ec2 authorize-security-group-ingress \
    --group-id sg-your-security-group \
    --protocol tcp \
    --port 5174 \
    --cidr your-ip/32
```

### Google Cloud Platform Deployment

#### 1. Create Compute Engine Instance

```bash
# Create instance using gcloud CLI
gcloud compute instances create sovereign-ai-instance \
    --zone=us-central1-a \
    --machine-type=e2-standard-2 \
    --network-interface=network-tier=PREMIUM,subnet=default \
    --maintenance-policy=MIGRATE \
    --provisioning-model=STANDARD \
    --service-account=your-service-account@your-project.iam.gserviceaccount.com \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --create-disk=auto-delete=yes,boot=yes,device-name=sovereign-ai-instance,image=projects/ubuntu-os-cloud/global/images/ubuntu-2204-jammy-v20231030,mode=rw,size=50,type=projects/your-project/zones/us-central1-a/diskTypes/pd-ssd \
    --no-shielded-secure-boot \
    --shielded-vtpm \
    --shielded-integrity-monitoring \
    --reservation-affinity=any
```

#### 2. Configure Firewall Rules

```bash
# Allow HTTP and HTTPS traffic
gcloud compute firewall-rules create allow-sovereign-ai-web \
    --allow tcp:80,tcp:443 \
    --source-ranges 0.0.0.0/0 \
    --description "Allow web traffic for Sovereign AI"

# Allow API access (restrict source ranges as needed)
gcloud compute firewall-rules create allow-sovereign-ai-api \
    --allow tcp:5174,tcp:8002,tcp:8003 \
    --source-ranges your-ip/32 \
    --description "Allow API access for Sovereign AI"
```

### DigitalOcean Deployment

#### 1. Create Droplet

```bash
# Using doctl CLI
doctl compute droplet create sovereign-ai \
    --region nyc1 \
    --image ubuntu-22-04-x64 \
    --size s-2vcpu-4gb \
    --ssh-keys your-ssh-key-id \
    --enable-monitoring \
    --enable-ipv6
```

#### 2. Configure Firewall

```bash
# Create firewall
doctl compute firewall create \
    --name sovereign-ai-firewall \
    --inbound-rules "protocol:tcp,ports:22,source_addresses:0.0.0.0/0,source_addresses:::/0 protocol:tcp,ports:80,source_addresses:0.0.0.0/0,source_addresses:::/0 protocol:tcp,ports:443,source_addresses:0.0.0.0/0,source_addresses:::/0" \
    --outbound-rules "protocol:tcp,ports:all,destination_addresses:0.0.0.0/0,destination_addresses:::/0 protocol:udp,ports:all,destination_addresses:0.0.0.0/0,destination_addresses:::/0"

# Apply firewall to droplet
doctl compute firewall add-droplets sovereign-ai-firewall --droplet-ids your-droplet-id
```

---

## Docker Deployment

### Dockerfile

Create `Dockerfile`:

```dockerfile
FROM ubuntu:22.04

# Set environment variables
ENV DEBIAN_FRONTEND=noninteractive
ENV PYTHONUNBUFFERED=1
ENV NODE_VERSION=20.18.0

# Install system dependencies
RUN apt-get update && apt-get install -y \
    python3.11 \
    python3.11-venv \
    python3.11-dev \
    python3-pip \
    nodejs \
    npm \
    curl \
    wget \
    git \
    sqlite3 \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Install pnpm
RUN npm install -g pnpm

# Create application user
RUN useradd -m -s /bin/bash sovereign-ai

# Set working directory
WORKDIR /opt/sovereign-ai

# Copy application files
COPY . .

# Change ownership
RUN chown -R sovereign-ai:sovereign-ai /opt/sovereign-ai

# Switch to application user
USER sovereign-ai

# Create virtual environment and install Python dependencies
RUN python3.11 -m venv venv && \
    . venv/bin/activate && \
    pip install --upgrade pip && \
    pip install -r requirements.txt

# Install Node.js dependencies
RUN cd sovereign-chat && pnpm install

# Initialize databases
RUN . venv/bin/activate && python -c "
from api_server.database import init_database
from time_capsule.backup_system import TimeCapsuleBackupSystem
init_database()
TimeCapsuleBackupSystem()
"

# Create necessary directories
RUN mkdir -p logs pids data/backups

# Expose ports
EXPOSE 5174 8002 8003

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \
    CMD curl -f http://localhost:8003/health || exit 1

# Start script
COPY scripts/docker-entrypoint.sh /usr/local/bin/
RUN chmod +x /usr/local/bin/docker-entrypoint.sh

ENTRYPOINT ["/usr/local/bin/docker-entrypoint.sh"]
```

### Docker Compose

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  sovereign-ai:
    build: .
    container_name: sovereign-ai
    restart: unless-stopped
    ports:
      - "5174:5174"
      - "8002:8002"
      - "8003:8003"
    volumes:
      - sovereign_ai_data:/opt/sovereign-ai/data
      - sovereign_ai_logs:/opt/sovereign-ai/logs
      - sovereign_ai_backups:/opt/sovereign-ai/data/backups
    environment:
      - ENVIRONMENT=production
      - AI_MODEL=tinyllama
      - LOG_LEVEL=INFO
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8003/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    networks:
      - sovereign_ai_network

  ollama:
    image: ollama/ollama:latest
    container_name: ollama
    restart: unless-stopped
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    environment:
      - OLLAMA_HOST=0.0.0.0
    networks:
      - sovereign_ai_network

  nginx:
    image: nginx:alpine
    container_name: sovereign-ai-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - sovereign-ai
    networks:
      - sovereign_ai_network

volumes:
  sovereign_ai_data:
  sovereign_ai_logs:
  sovereign_ai_backups:
  ollama_data:

networks:
  sovereign_ai_network:
    driver: bridge
```

### Docker Entrypoint Script

Create `scripts/docker-entrypoint.sh`:

```bash
#!/bin/bash
set -e

# Wait for Ollama to be ready
echo "Waiting for Ollama to be ready..."
while ! curl -s http://ollama:11434/api/tags >/dev/null; do
    sleep 5
done

# Download AI model if not present
echo "Checking for AI model..."
if ! curl -s http://ollama:11434/api/tags | grep -q "tinyllama"; then
    echo "Downloading TinyLLama model..."
    curl -X POST http://ollama:11434/api/pull -d '{"name": "tinyllama"}'
fi

# Start Sovereign AI services
echo "Starting Sovereign AI services..."
cd /opt/sovereign-ai
source venv/bin/activate

# Start services in background
python chat_api.py &
python curation_api.py &

# Start React app in foreground
cd sovereign-chat
exec pnpm run dev --host
```

### Build and Run

```bash
# Build the image
docker build -t sovereign-ai:latest .

# Run with Docker Compose
docker-compose up -d

# Check status
docker-compose ps
docker-compose logs -f sovereign-ai

# Access the application
# http://localhost:5174
```

---

## Security Hardening

### System Security

```bash
# 1. Update system packages
sudo apt update && sudo apt upgrade -y

# 2. Configure automatic security updates
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades

# 3. Configure firewall
sudo ufw enable
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# 4. Install and configure fail2ban
sudo apt install -y fail2ban
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local

# Edit /etc/fail2ban/jail.local
sudo tee -a /etc/fail2ban/jail.local << 'EOF'

[sovereign-ai-chat]
enabled = true
port = 8003
filter = sovereign-ai-chat
logpath = /opt/sovereign-ai/logs/chat_api.log
maxretry = 5
bantime = 3600

[sovereign-ai-curation]
enabled = true
port = 8002
filter = sovereign-ai-curation
logpath = /opt/sovereign-ai/logs/curation_api.log
maxretry = 5
bantime = 3600
EOF

# 5. Restart fail2ban
sudo systemctl restart fail2ban
```

### Application Security

```bash
# 1. Generate secure API keys
openssl rand -hex 32 > /opt/sovereign-ai/config/api_key.txt
chmod 600 /opt/sovereign-ai/config/api_key.txt

# 2. Set up SSL certificates (Let's Encrypt)
sudo certbot --nginx -d your-domain.com

# 3. Configure secure headers in Nginx
# Add to your Nginx configuration:
add_header X-Frame-Options DENY;
add_header X-Content-Type-Options nosniff;
add_header X-XSS-Protection "1; mode=block";
add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload";
add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';";

# 4. Set proper file permissions
sudo chown -R sovereign-ai:sovereign-ai /opt/sovereign-ai
sudo chmod -R 750 /opt/sovereign-ai
sudo chmod -R 640 /opt/sovereign-ai/config
sudo chmod -R 600 /opt/sovereign-ai/config/*.key
```

### Database Security

```bash
# 1. Set database file permissions
chmod 600 /opt/sovereign-ai/api-server/sovereign_ai.db
chmod 600 /opt/sovereign-ai/time_capsule/metadata/backup_metadata.db

# 2. Enable database encryption (if using SQLCipher)
# Add to your Python configuration:
DATABASE_URL="sqlite+pysqlcipher://:password@/path/to/database.db"

# 3. Regular database backups with encryption
# Add to crontab:
0 2 * * * /opt/sovereign-ai/scripts/backup_databases.sh
```

---

## Monitoring and Maintenance

### System Monitoring

#### 1. Install Monitoring Tools

```bash
# Install system monitoring tools
sudo apt install -y htop iotop nethogs

# Install log monitoring
sudo apt install -y logwatch

# Configure logwatch
sudo tee /etc/logwatch/conf/logfiles/sovereign-ai.conf << 'EOF'
LogFile = /opt/sovereign-ai/logs/*.log
Archive = /opt/sovereign-ai/logs/*.log.*
EOF
```

#### 2. Set Up Health Monitoring

Create `/opt/sovereign-ai/scripts/health_monitor.sh`:

```bash
#!/bin/bash

# Health monitoring script
HEALTH_LOG="/opt/sovereign-ai/logs/health.log"
ALERT_EMAIL="admin@yourdomain.com"

check_service() {
    local service=$1
    local url=$2
    
    if ! curl -s "$url" | grep -q "healthy"; then
        echo "$(date): $service is unhealthy" >> "$HEALTH_LOG"
        echo "$service is down" | mail -s "Sovereign AI Alert" "$ALERT_EMAIL"
        return 1
    fi
    return 0
}

# Check all services
check_service "Chat API" "http://localhost:8003/health"
check_service "Curation API" "http://localhost:8002/health"

# Check system resources
CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
MEMORY_USAGE=$(free | grep "Mem:" | awk '{printf "%.1f", $3/$2 * 100.0}')

if (( $(echo "$CPU_USAGE > 90" | bc -l) )); then
    echo "$(date): High CPU usage: $CPU_USAGE%" >> "$HEALTH_LOG"
fi

if (( $(echo "$MEMORY_USAGE > 90" | bc -l) )); then
    echo "$(date): High memory usage: $MEMORY_USAGE%" >> "$HEALTH_LOG"
fi
```

#### 3. Set Up Automated Monitoring

```bash
# Add to crontab
crontab -e

# Add these lines:
# Check health every 5 minutes
*/5 * * * * /opt/sovereign-ai/scripts/health_monitor.sh

# Daily system status report
0 8 * * * /opt/sovereign-ai/scripts/check_status.sh > /tmp/daily_status.txt && mail -s "Daily Status Report" admin@yourdomain.com < /tmp/daily_status.txt

# Weekly log rotation
0 0 * * 0 /opt/sovereign-ai/scripts/rotate_logs.sh
```

### Log Management

#### 1. Log Rotation Configuration

Create `/etc/logrotate.d/sovereign-ai`:

```
/opt/sovereign-ai/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 sovereign-ai sovereign-ai
    postrotate
        systemctl reload sovereign-ai
    endscript
}
```

#### 2. Log Analysis Scripts

Create `/opt/sovereign-ai/scripts/analyze_logs.sh`:

```bash
#!/bin/bash

LOG_DIR="/opt/sovereign-ai/logs"
REPORT_FILE="/tmp/log_analysis_$(date +%Y%m%d).txt"

echo "Sovereign AI Log Analysis - $(date)" > "$REPORT_FILE"
echo "================================================" >> "$REPORT_FILE"

# Error analysis
echo -e "\nError Summary:" >> "$REPORT_FILE"
grep -i error "$LOG_DIR"/*.log | wc -l | xargs echo "Total errors:" >> "$REPORT_FILE"

# Top error messages
echo -e "\nTop Error Messages:" >> "$REPORT_FILE"
grep -i error "$LOG_DIR"/*.log | cut -d: -f3- | sort | uniq -c | sort -nr | head -10 >> "$REPORT_FILE"

# Performance metrics
echo -e "\nPerformance Metrics:" >> "$REPORT_FILE"
grep "processing_time" "$LOG_DIR"/*.log | awk '{sum+=$NF; count++} END {print "Average processing time:", sum/count "ms"}' >> "$REPORT_FILE"

# Constitutional violations
echo -e "\nConstitutional Violations:" >> "$REPORT_FILE"
grep "blocked" "$LOG_DIR"/chat_api.log | wc -l | xargs echo "Total blocked messages:" >> "$REPORT_FILE"

echo "Log analysis complete: $REPORT_FILE"
```

### Performance Optimization

#### 1. Database Optimization

```bash
# Create database maintenance script
cat > /opt/sovereign-ai/scripts/db_maintenance.sh << 'EOF'
#!/bin/bash

cd /opt/sovereign-ai
source venv/bin/activate

python3 << 'PYTHON'
import sqlite3
import os

databases = [
    'api-server/sovereign_ai.db',
    'time_capsule/metadata/backup_metadata.db'
]

for db_path in databases:
    if os.path.exists(db_path):
        print(f"Optimizing {db_path}...")
        conn = sqlite3.connect(db_path)
        
        # Vacuum database
        conn.execute('VACUUM')
        
        # Analyze tables
        conn.execute('ANALYZE')
        
        # Reindex
        conn.execute('REINDEX')
        
        conn.close()
        print(f"Optimization complete for {db_path}")
PYTHON
EOF

chmod +x /opt/sovereign-ai/scripts/db_maintenance.sh

# Add to weekly cron
echo "0 3 * * 0 /opt/sovereign-ai/scripts/db_maintenance.sh" | crontab -
```

#### 2. System Optimization

```bash
# Optimize system settings
sudo tee -a /etc/sysctl.conf << 'EOF'
# Sovereign AI optimizations
net.core.somaxconn = 1024
net.core.netdev_max_backlog = 5000
net.ipv4.tcp_max_syn_backlog = 1024
vm.swappiness = 10
vm.dirty_ratio = 15
vm.dirty_background_ratio = 5
EOF

sudo sysctl -p
```

---

## Backup and Recovery

### Automated Backup Strategy

#### 1. System-Level Backups

```bash
# Create system backup script
cat > /opt/sovereign-ai/scripts/system_backup.sh << 'EOF'
#!/bin/bash

BACKUP_DIR="/opt/sovereign-ai/backups/system"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="system_backup_$DATE"

mkdir -p "$BACKUP_DIR"

# Create system backup
tar -czf "$BACKUP_DIR/$BACKUP_NAME.tar.gz" \
    --exclude='/opt/sovereign-ai/logs' \
    --exclude='/opt/sovereign-ai/pids' \
    --exclude='/opt/sovereign-ai/backups' \
    /opt/sovereign-ai

# Upload to cloud storage (optional)
# aws s3 cp "$BACKUP_DIR/$BACKUP_NAME.tar.gz" s3://your-backup-bucket/

# Clean up old backups (keep last 7 days)
find "$BACKUP_DIR" -name "system_backup_*.tar.gz" -mtime +7 -delete

echo "System backup completed: $BACKUP_NAME.tar.gz"
EOF

chmod +x /opt/sovereign-ai/scripts/system_backup.sh
```

#### 2. Database Backups

```bash
# Create database backup script
cat > /opt/sovereign-ai/scripts/db_backup.sh << 'EOF'
#!/bin/bash

BACKUP_DIR="/opt/sovereign-ai/backups/databases"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p "$BACKUP_DIR"

# Backup main database
sqlite3 /opt/sovereign-ai/api-server/sovereign_ai.db ".backup $BACKUP_DIR/sovereign_ai_$DATE.db"

# Backup metadata database
sqlite3 /opt/sovereign-ai/time_capsule/metadata/backup_metadata.db ".backup $BACKUP_DIR/backup_metadata_$DATE.db"

# Compress backups
gzip "$BACKUP_DIR"/*_$DATE.db

# Clean up old backups (keep last 30 days)
find "$BACKUP_DIR" -name "*.db.gz" -mtime +30 -delete

echo "Database backups completed for $DATE"
EOF

chmod +x /opt/sovereign-ai/scripts/db_backup.sh
```

#### 3. Automated Backup Schedule

```bash
# Add to crontab
crontab -e

# Add these lines:
# Daily database backup at 1 AM
0 1 * * * /opt/sovereign-ai/scripts/db_backup.sh

# Weekly system backup at 2 AM on Sundays
0 2 * * 0 /opt/sovereign-ai/scripts/system_backup.sh

# Monthly full backup with cloud upload
0 3 1 * * /opt/sovereign-ai/scripts/full_backup.sh
```

### Disaster Recovery

#### 1. Recovery Procedures

Create `/opt/sovereign-ai/scripts/disaster_recovery.sh`:

```bash
#!/bin/bash

RECOVERY_MODE="$1"
BACKUP_FILE="$2"

case "$RECOVERY_MODE" in
    "system")
        echo "Performing system recovery from $BACKUP_FILE"
        
        # Stop services
        ./scripts/stop_system.sh
        
        # Backup current state
        mv /opt/sovereign-ai /opt/sovereign-ai.backup.$(date +%Y%m%d_%H%M%S)
        
        # Extract backup
        tar -xzf "$BACKUP_FILE" -C /
        
        # Restart services
        ./scripts/start_system.sh
        ;;
        
    "database")
        echo "Performing database recovery from $BACKUP_FILE"
        
        # Stop services
        ./scripts/stop_system.sh
        
        # Backup current databases
        cp /opt/sovereign-ai/api-server/sovereign_ai.db /opt/sovereign-ai/api-server/sovereign_ai.db.backup
        
        # Restore database
        gunzip -c "$BACKUP_FILE" > /opt/sovereign-ai/api-server/sovereign_ai.db
        
        # Restart services
        ./scripts/start_system.sh
        ;;
        
    *)
        echo "Usage: $0 {system|database} <backup_file>"
        exit 1
        ;;
esac
```

#### 2. Recovery Testing

```bash
# Create recovery test script
cat > /opt/sovereign-ai/scripts/test_recovery.sh << 'EOF'
#!/bin/bash

echo "Testing disaster recovery procedures..."

# Test database backup and restore
echo "Testing database backup/restore..."
./scripts/db_backup.sh
LATEST_DB_BACKUP=$(ls -t /opt/sovereign-ai/backups/databases/*.gz | head -1)
./scripts/disaster_recovery.sh database "$LATEST_DB_BACKUP"

# Verify system health
sleep 30
./scripts/check_status.sh

echo "Recovery test completed"
EOF

chmod +x /opt/sovereign-ai/scripts/test_recovery.sh
```

---

## Troubleshooting

### Common Deployment Issues

#### 1. Service Startup Failures

```bash
# Check service status
systemctl status sovereign-ai

# Check logs
journalctl -u sovereign-ai -f

# Check application logs
tail -f /opt/sovereign-ai/logs/*.log

# Common fixes:
# - Check port availability: sudo lsof -i :8003
# - Verify permissions: ls -la /opt/sovereign-ai
# - Check disk space: df -h
# - Verify dependencies: pip list, npm list
```

#### 2. Database Issues

```bash
# Check database integrity
sqlite3 /opt/sovereign-ai/api-server/sovereign_ai.db "PRAGMA integrity_check;"

# Repair database if needed
sqlite3 /opt/sovereign-ai/api-server/sovereign_ai.db ".recover" | sqlite3 recovered.db

# Check database locks
sudo lsof /opt/sovereign-ai/api-server/sovereign_ai.db
```

#### 3. Performance Issues

```bash
# Monitor system resources
htop
iotop
nethogs

# Check AI model performance
curl -X POST http://localhost:11434/api/generate \
  -H "Content-Type: application/json" \
  -d '{"model": "tinyllama", "prompt": "Hello", "stream": false}'

# Optimize AI model settings
# Edit config/production.yaml:
ai:
  temperature: 0.3  # Lower for faster responses
  max_tokens: 1024  # Reduce for faster processing
```

#### 4. Network Issues

```bash
# Check firewall rules
sudo ufw status verbose

# Check port binding
sudo netstat -tlnp | grep -E ':(8003|8002|5174)'

# Test connectivity
curl -v http://localhost:8003/health
curl -v http://localhost:8002/health
curl -v http://localhost:5174
```

### Deployment Validation

#### 1. Automated Deployment Tests

Create `/opt/sovereign-ai/scripts/deployment_test.sh`:

```bash
#!/bin/bash

echo "Running deployment validation tests..."

# Test 1: Service health checks
echo "Testing service health..."
for service in "http://localhost:8003/health" "http://localhost:8002/health" "http://localhost:5174"; do
    if curl -s "$service" >/dev/null; then
        echo "✓ $service is responding"
    else
        echo "✗ $service is not responding"
        exit 1
    fi
done

# Test 2: API functionality
echo "Testing API functionality..."
RESPONSE=$(curl -s -X POST http://localhost:8003/api/chat \
    -H "Content-Type: application/json" \
    -d '{"message": "Hello, test message"}')

if echo "$RESPONSE" | grep -q "response"; then
    echo "✓ Chat API is functional"
else
    echo "✗ Chat API is not functional"
    exit 1
fi

# Test 3: Database connectivity
echo "Testing database connectivity..."
if sqlite3 /opt/sovereign-ai/api-server/sovereign_ai.db "SELECT 1;" >/dev/null 2>&1; then
    echo "✓ Database is accessible"
else
    echo "✗ Database is not accessible"
    exit 1
fi

# Test 4: Constitutional AI
echo "Testing constitutional AI..."
BLOCKED_RESPONSE=$(curl -s -X POST http://localhost:8003/api/chat \
    -H "Content-Type: application/json" \
    -d '{"message": "Can you help me hack something?"}')

if echo "$BLOCKED_RESPONSE" | grep -q "cannot"; then
    echo "✓ Constitutional AI is working"
else
    echo "✗ Constitutional AI may not be working properly"
fi

echo "All deployment tests passed!"
```

#### 2. Performance Benchmarks

```bash
# Create performance benchmark script
cat > /opt/sovereign-ai/scripts/benchmark.sh << 'EOF'
#!/bin/bash

echo "Running performance benchmarks..."

# Benchmark 1: API response time
echo "Benchmarking API response time..."
for i in {1..10}; do
    time curl -s http://localhost:8003/health >/dev/null
done 2>&1 | grep real | awk '{sum+=$2} END {print "Average response time:", sum/NR}'

# Benchmark 2: Chat API performance
echo "Benchmarking chat API..."
START_TIME=$(date +%s.%N)
curl -s -X POST http://localhost:8003/api/chat \
    -H "Content-Type: application/json" \
    -d '{"message": "What is artificial intelligence?"}' >/dev/null
END_TIME=$(date +%s.%N)
DURATION=$(echo "$END_TIME - $START_TIME" | bc)
echo "Chat API response time: ${DURATION}s"

# Benchmark 3: System resources
echo "System resource usage:"
echo "CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}')"
echo "Memory: $(free -h | grep "Mem:" | awk '{print $3 "/" $2}')"
echo "Disk: $(df -h /opt/sovereign-ai | tail -1 | awk '{print $3 "/" $2 " (" $5 ")"}')"

echo "Benchmark completed"
EOF

chmod +x /opt/sovereign-ai/scripts/benchmark.sh
```

---

**Deployment Guide Complete**

This comprehensive deployment guide covers all aspects of deploying Sovereign AI from development to production environments. Choose the deployment method that best fits your needs and follow the security and monitoring best practices for a robust, reliable system.

For additional support, refer to the [Installation Guide](INSTALLATION_GUIDE.md) and [API Documentation](API_DOCUMENTATION.md).

*Sovereign AI - Your AI, Your Rules, Your Data*

