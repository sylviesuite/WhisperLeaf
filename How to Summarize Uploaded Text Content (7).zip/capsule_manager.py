#!/usr/bin/env python3
"""
Time Capsule Manager for WhisperLeaf

Manages the creation, storage, retrieval, and opening of time capsules.
Provides sophisticated temporal bookmarking and future self communication.
"""

import sqlite3
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
import logging
from cryptography.fernet import Fernet
import base64

from .capsule_models import (
    TimeCapsule, CapsuleType, CapsuleStatus, EmotionalSnapshot,
    FutureMessage, MilestoneMarker, CapsuleCollection
)

class TimeCapsuleManager:
    """Manages time capsules with secure storage and retrieval"""
    
    def __init__(self, data_dir: str = "data", encryption_key: Optional[str] = None):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        self.db_path = self.data_dir / "time_capsules.db"
        self.logger = logging.getLogger(__name__)
        
        # Initialize encryption
        if encryption_key:
            self.cipher = Fernet(encryption_key.encode())
        else:
            # Generate a key for this session (in production, this should be user-provided)
            key = Fernet.generate_key()
            self.cipher = Fernet(key)
        
        self._init_database()
    
    def _init_database(self):
        """Initialize the time capsule database"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS time_capsules (
                    capsule_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    description TEXT,
                    capsule_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    sealed_until TEXT,
                    opened_at TEXT,
                    tags TEXT,
                    privacy_level TEXT DEFAULT 'private',
                    creator_notes TEXT,
                    opening_conditions TEXT,
                    emotional_significance REAL DEFAULT 0.5,
                    growth_relevance REAL DEFAULT 0.5,
                    view_count INTEGER DEFAULT 0,
                    last_viewed TEXT,
                    content_data TEXT NOT NULL
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS capsule_collections (
                    collection_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    capsule_ids TEXT,
                    created_at TEXT NOT NULL,
                    tags TEXT
                )
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_capsules_status ON time_capsules(status)
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_capsules_type ON time_capsules(capsule_type)
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_capsules_created ON time_capsules(created_at)
            """)
    
    def _encrypt_content(self, content: str) -> str:
        """Encrypt sensitive content"""
        return base64.b64encode(self.cipher.encrypt(content.encode())).decode()
    
    def _decrypt_content(self, encrypted_content: str) -> str:
        """Decrypt sensitive content"""
        return self.cipher.decrypt(base64.b64decode(encrypted_content.encode())).decode()
    
    def create_emotional_snapshot_capsule(
        self,
        title: str,
        emotional_snapshot: EmotionalSnapshot,
        sealed_until: Optional[datetime] = None,
        description: str = "",
        tags: List[str] = None,
        creator_notes: str = None
    ) -> TimeCapsule:
        """Create a time capsule with an emotional snapshot"""
        
        capsule = TimeCapsule(
            title=title,
            description=description,
            capsule_type=CapsuleType.EMOTIONAL_SNAPSHOT,
            sealed_until=sealed_until,
            emotional_snapshot=emotional_snapshot,
            tags=tags or [],
            creator_notes=creator_notes,
            emotional_significance=emotional_snapshot.intensity,
            growth_relevance=0.6  # Emotional snapshots are moderately relevant for growth
        )
        
        self._store_capsule(capsule)
        
        self.logger.info(f"Created emotional snapshot capsule: {capsule.capsule_id}")
        return capsule
    
    def create_future_message_capsule(
        self,
        title: str,
        future_message: FutureMessage,
        sealed_until: datetime,
        description: str = "",
        tags: List[str] = None,
        creator_notes: str = None
    ) -> TimeCapsule:
        """Create a time capsule with a message to future self"""
        
        capsule = TimeCapsule(
            title=title,
            description=description,
            capsule_type=CapsuleType.FUTURE_MESSAGE,
            sealed_until=sealed_until,
            future_message=future_message,
            tags=tags or [],
            creator_notes=creator_notes,
            emotional_significance=future_message.sender_emotional_state.intensity,
            growth_relevance=0.8  # Future messages are highly relevant for growth
        )
        
        self._store_capsule(capsule)
        
        self.logger.info(f"Created future message capsule: {capsule.capsule_id}")
        return capsule
    
    def create_milestone_capsule(
        self,
        title: str,
        milestone_marker: MilestoneMarker,
        sealed_until: Optional[datetime] = None,
        description: str = "",
        tags: List[str] = None,
        creator_notes: str = None
    ) -> TimeCapsule:
        """Create a time capsule marking a significant milestone"""
        
        capsule = TimeCapsule(
            title=title,
            description=description,
            capsule_type=CapsuleType.MILESTONE_MARKER,
            sealed_until=sealed_until,
            milestone_marker=milestone_marker,
            tags=tags or [],
            creator_notes=creator_notes,
            emotional_significance=milestone_marker.significance_score,
            growth_relevance=0.9  # Milestones are very relevant for growth
        )
        
        self._store_capsule(capsule)
        
        self.logger.info(f"Created milestone capsule: {capsule.capsule_id}")
        return capsule
    
    def _store_capsule(self, capsule: TimeCapsule):
        """Store a time capsule in the database"""
        content_data = json.dumps(capsule.to_dict())
        
        # Encrypt sensitive content if privacy level requires it
        if capsule.privacy_level in ['confidential', 'encrypted']:
            content_data = self._encrypt_content(content_data)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO time_capsules (
                    capsule_id, title, description, capsule_type, status,
                    created_at, sealed_until, opened_at, tags, privacy_level,
                    creator_notes, opening_conditions, emotional_significance,
                    growth_relevance, view_count, last_viewed, content_data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                capsule.capsule_id,
                capsule.title,
                capsule.description,
                capsule.capsule_type.value,
                capsule.status.value,
                capsule.created_at.isoformat(),
                capsule.sealed_until.isoformat() if capsule.sealed_until else None,
                capsule.opened_at.isoformat() if capsule.opened_at else None,
                json.dumps(capsule.tags),
                capsule.privacy_level,
                capsule.creator_notes,
                json.dumps(capsule.opening_conditions),
                capsule.emotional_significance,
                capsule.growth_relevance,
                capsule.view_count,
                capsule.last_viewed.isoformat() if capsule.last_viewed else None,
                content_data
            ))
    
    def get_capsule(self, capsule_id: str) -> Optional[TimeCapsule]:
        """Retrieve a time capsule by ID"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM time_capsules WHERE capsule_id = ?",
                (capsule_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                return None
            
            # Decrypt content if necessary
            content_data = row['content_data']
            if row['privacy_level'] in ['confidential', 'encrypted']:
                content_data = self._decrypt_content(content_data)
            
            capsule_dict = json.loads(content_data)
            return TimeCapsule.from_dict(capsule_dict)
    
    def get_ready_capsules(self) -> List[TimeCapsule]:
        """Get all capsules that are ready to be opened"""
        ready_capsules = []
        
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("""
                SELECT capsule_id FROM time_capsules 
                WHERE status = 'sealed' 
                AND (sealed_until IS NULL OR sealed_until <= ?)
                ORDER BY created_at ASC
            """, (datetime.now().isoformat(),))
            
            for row in cursor.fetchall():
                capsule = self.get_capsule(row['capsule_id'])
                if capsule and capsule.is_ready_to_open():
                    ready_capsules.append(capsule)
        
        return ready_capsules
    
    def open_capsule(self, capsule_id: str) -> Dict[str, Any]:
        """Open a time capsule and return its contents"""
        capsule = self.get_capsule(capsule_id)
        if not capsule:
            raise ValueError(f"Capsule {capsule_id} not found")
        
        contents = capsule.open_capsule()
        
        # Update the capsule in storage
        self._store_capsule(capsule)
        
        self.logger.info(f"Opened time capsule: {capsule_id}")
        return contents
    
    def search_capsules(
        self,
        query: str = None,
        capsule_type: CapsuleType = None,
        status: CapsuleStatus = None,
        tags: List[str] = None,
        date_range: Tuple[datetime, datetime] = None,
        limit: int = 50
    ) -> List[TimeCapsule]:
        """Search for time capsules with various filters"""
        
        conditions = []
        params = []
        
        if query:
            conditions.append("(title LIKE ? OR description LIKE ?)")
            params.extend([f"%{query}%", f"%{query}%"])
        
        if capsule_type:
            conditions.append("capsule_type = ?")
            params.append(capsule_type.value)
        
        if status:
            conditions.append("status = ?")
            params.append(status.value)
        
        if tags:
            # Simple tag search (could be improved with proper tag indexing)
            tag_conditions = []
            for tag in tags:
                tag_conditions.append("tags LIKE ?")
                params.append(f"%{tag}%")
            conditions.append(f"({' OR '.join(tag_conditions)})")
        
        if date_range:
            conditions.append("created_at BETWEEN ? AND ?")
            params.extend([date_range[0].isoformat(), date_range[1].isoformat()])
        
        where_clause = " AND ".join(conditions) if conditions else "1=1"
        
        capsules = []
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(f"""
                SELECT capsule_id FROM time_capsules 
                WHERE {where_clause}
                ORDER BY created_at DESC
                LIMIT ?
            """, params + [limit])
            
            for row in cursor.fetchall():
                capsule = self.get_capsule(row['capsule_id'])
                if capsule:
                    capsules.append(capsule)
        
        return capsules
    
    def get_capsule_timeline(
        self,
        start_date: datetime = None,
        end_date: datetime = None
    ) -> List[Dict[str, Any]]:
        """Get a timeline view of all capsules"""
        
        if not start_date:
            start_date = datetime.now() - timedelta(days=365)  # Last year
        if not end_date:
            end_date = datetime.now() + timedelta(days=365)   # Next year
        
        timeline_items = []
        
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("""
                SELECT capsule_id, title, capsule_type, status, created_at, 
                       sealed_until, opened_at, emotional_significance, growth_relevance
                FROM time_capsules 
                WHERE created_at BETWEEN ? AND ?
                ORDER BY created_at ASC
            """, (start_date.isoformat(), end_date.isoformat()))
            
            for row in cursor.fetchall():
                timeline_items.append({
                    'capsule_id': row['capsule_id'],
                    'title': row['title'],
                    'type': row['capsule_type'],
                    'status': row['status'],
                    'created_at': row['created_at'],
                    'sealed_until': row['sealed_until'],
                    'opened_at': row['opened_at'],
                    'emotional_significance': row['emotional_significance'],
                    'growth_relevance': row['growth_relevance']
                })
        
        return timeline_items
    
    def create_collection(
        self,
        name: str,
        description: str = "",
        capsule_ids: List[str] = None,
        tags: List[str] = None
    ) -> CapsuleCollection:
        """Create a collection of related time capsules"""
        
        collection = CapsuleCollection(
            name=name,
            description=description,
            capsule_ids=capsule_ids or [],
            tags=tags or []
        )
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO capsule_collections (
                    collection_id, name, description, capsule_ids, created_at, tags
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                collection.collection_id,
                collection.name,
                collection.description,
                json.dumps(collection.capsule_ids),
                collection.created_at.isoformat(),
                json.dumps(collection.tags)
            ))
        
        self.logger.info(f"Created capsule collection: {collection.collection_id}")
        return collection
    
    def get_collection(self, collection_id: str) -> Optional[CapsuleCollection]:
        """Get a capsule collection by ID"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM capsule_collections WHERE collection_id = ?",
                (collection_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                return None
            
            return CapsuleCollection(
                collection_id=row['collection_id'],
                name=row['name'],
                description=row['description'],
                capsule_ids=json.loads(row['capsule_ids']),
                created_at=datetime.fromisoformat(row['created_at']),
                tags=json.loads(row['tags'])
            )
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get time capsule statistics"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            # Basic counts
            cursor = conn.execute("SELECT COUNT(*) as total FROM time_capsules")
            total_capsules = cursor.fetchone()['total']
            
            # Status breakdown
            cursor = conn.execute("""
                SELECT status, COUNT(*) as count 
                FROM time_capsules 
                GROUP BY status
            """)
            status_breakdown = {row['status']: row['count'] for row in cursor.fetchall()}
            
            # Type breakdown
            cursor = conn.execute("""
                SELECT capsule_type, COUNT(*) as count 
                FROM time_capsules 
                GROUP BY capsule_type
            """)
            type_breakdown = {row['capsule_type']: row['count'] for row in cursor.fetchall()}
            
            # Ready to open
            cursor = conn.execute("""
                SELECT COUNT(*) as ready_count FROM time_capsules 
                WHERE status = 'sealed' 
                AND (sealed_until IS NULL OR sealed_until <= ?)
            """, (datetime.now().isoformat(),))
            ready_count = cursor.fetchone()['ready_count']
            
            # Average emotional significance
            cursor = conn.execute("""
                SELECT AVG(emotional_significance) as avg_significance,
                       AVG(growth_relevance) as avg_growth_relevance
                FROM time_capsules
            """)
            averages = cursor.fetchone()
            
            return {
                'total_capsules': total_capsules,
                'status_breakdown': status_breakdown,
                'type_breakdown': type_breakdown,
                'ready_to_open': ready_count,
                'average_emotional_significance': averages['avg_significance'] or 0,
                'average_growth_relevance': averages['avg_growth_relevance'] or 0,
                'database_path': str(self.db_path)
            }

