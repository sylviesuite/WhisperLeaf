"""
WhisperLeaf Growth Tracking and Analytics Engine
Quantitative tracking of emotional development and resilience
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from collections import defaultdict
from dataclasses import dataclass
import logging
from enum import Enum

logger = logging.getLogger(__name__)

class GrowthPhase(Enum):
    """Emotional growth phases"""
    DISCOVERY = "discovery"
    DEVELOPMENT = "development"
    INTEGRATION = "integration"
    MASTERY = "mastery"
    TRANSFORMATION = "transformation"

class ResilienceLevel(Enum):
    """Emotional resilience levels"""
    DEVELOPING = "developing"
    MODERATE = "moderate"
    STRONG = "strong"
    EXCEPTIONAL = "exceptional"

@dataclass
class GrowthMetric:
    """Individual growth metric tracking"""
    metric_id: str
    metric_name: str
    current_value: float
    baseline_value: float
    target_value: float
    improvement_rate: float
    confidence: float
    measurement_period: timedelta
    last_updated: datetime

@dataclass
class GrowthMilestone:
    """Significant growth achievement"""
    milestone_id: str
    milestone_name: str
    achievement_date: datetime
    description: str
    evidence: List[str]
    impact_score: float
    celebration_worthy: bool
    growth_areas: List[str]

@dataclass
class ResilienceProfile:
    """Comprehensive resilience assessment"""
    profile_id: str
    overall_resilience: ResilienceLevel
    resilience_score: float
    strengths: List[str]
    growth_areas: List[str]
    coping_strategies: List[str]
    stress_tolerance: float
    recovery_speed: float
    adaptation_ability: float
    support_utilization: float

class EmotionalGrowthTracker:
    """
    Advanced emotional growth tracking and analytics system
    """
    
    def __init__(self):
        self.growth_metrics = {}
        self.milestones = {}
        self.resilience_profiles = {}
        
        # Growth tracking parameters
        self.baseline_period = timedelta(days=14)
        self.measurement_window = timedelta(days=7)
        self.milestone_threshold = 0.7
        self.resilience_assessment_period = timedelta(days=30)
        
        # Growth metric definitions
        self.metric_definitions = self._initialize_growth_metrics()
        
        logger.info("EmotionalGrowthTracker initialized")
    
    def _initialize_growth_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Initialize growth metric definitions"""
        return {
            'emotional_awareness': {
                'name': 'Emotional Awareness',
                'description': 'Ability to recognize and understand emotions',
                'calculation': 'emotion_recognition_accuracy',
                'target_range': (0.7, 1.0),
                'improvement_indicators': ['emotion_vocabulary', 'emotion_accuracy', 'self_reflection_depth']
            },
            'emotional_regulation': {
                'name': 'Emotional Regulation',
                'description': 'Ability to manage and control emotional responses',
                'calculation': 'regulation_effectiveness',
                'target_range': (0.6, 1.0),
                'improvement_indicators': ['intensity_stability', 'recovery_time', 'coping_strategy_use']
            },
            'resilience': {
                'name': 'Emotional Resilience',
                'description': 'Ability to bounce back from emotional challenges',
                'calculation': 'resilience_score',
                'target_range': (0.7, 1.0),
                'improvement_indicators': ['bounce_back_speed', 'stress_tolerance', 'adaptation_ability']
            },
            'self_compassion': {
                'name': 'Self-Compassion',
                'description': 'Kindness and understanding toward oneself',
                'calculation': 'self_compassion_score',
                'target_range': (0.6, 1.0),
                'improvement_indicators': ['self_kindness', 'mindfulness', 'common_humanity']
            },
            'emotional_intelligence': {
                'name': 'Emotional Intelligence',
                'description': 'Overall emotional intelligence and social awareness',
                'calculation': 'ei_composite_score',
                'target_range': (0.7, 1.0),
                'improvement_indicators': ['empathy', 'social_awareness', 'relationship_management']
            },
            'growth_mindset': {
                'name': 'Growth Mindset',
                'description': 'Belief in ability to develop and improve',
                'calculation': 'growth_mindset_score',
                'target_range': (0.6, 1.0),
                'improvement_indicators': ['learning_orientation', 'challenge_acceptance', 'effort_valuation']
            },
            'life_satisfaction': {
                'name': 'Life Satisfaction',
                'description': 'Overall satisfaction and well-being',
                'calculation': 'satisfaction_score',
                'target_range': (0.6, 1.0),
                'improvement_indicators': ['mood_positivity', 'goal_achievement', 'relationship_quality']
            }
        }
    
    def track_growth_metrics(self, mood_entries: List[Any], journal_entries: List[Any] = None) -> Dict[str, GrowthMetric]:
        """Track all growth metrics from user data"""
        
        if len(mood_entries) < 7:
            return {}
        
        # Convert to DataFrame for analysis
        df = self._entries_to_dataframe(mood_entries)
        
        metrics = {}
        
        for metric_id, definition in self.metric_definitions.items():
            try:
                metric = self._calculate_growth_metric(metric_id, definition, df, journal_entries)
                if metric:
                    metrics[metric_id] = metric
                    self.growth_metrics[metric_id] = metric
            except Exception as e:
                logger.error(f"Error calculating metric {metric_id}: {e}")
        
        return metrics
    
    def _calculate_growth_metric(self, metric_id: str, definition: Dict[str, Any], 
                                df: pd.DataFrame, journal_entries: List[Any] = None) -> Optional[GrowthMetric]:
        """Calculate individual growth metric"""
        
        current_time = datetime.now()
        
        # Calculate baseline (first 2 weeks of data)
        baseline_data = df[df['timestamp'] <= df['timestamp'].min() + self.baseline_period]
        recent_data = df[df['timestamp'] >= df['timestamp'].max() - self.measurement_window]
        
        if len(baseline_data) < 3 or len(recent_data) < 3:
            return None
        
        # Calculate metric values based on type
        if metric_id == 'emotional_awareness':
            baseline_value = self._calculate_emotional_awareness(baseline_data)
            current_value = self._calculate_emotional_awareness(recent_data)
            target_value = 0.8
        
        elif metric_id == 'emotional_regulation':
            baseline_value = self._calculate_emotional_regulation(baseline_data)
            current_value = self._calculate_emotional_regulation(recent_data)
            target_value = 0.7
        
        elif metric_id == 'resilience':
            baseline_value = self._calculate_resilience(baseline_data)
            current_value = self._calculate_resilience(recent_data)
            target_value = 0.75
        
        elif metric_id == 'self_compassion':
            baseline_value = self._calculate_self_compassion(baseline_data, journal_entries)
            current_value = self._calculate_self_compassion(recent_data, journal_entries)
            target_value = 0.7
        
        elif metric_id == 'emotional_intelligence':
            baseline_value = self._calculate_emotional_intelligence(baseline_data)
            current_value = self._calculate_emotional_intelligence(recent_data)
            target_value = 0.75
        
        elif metric_id == 'growth_mindset':
            baseline_value = self._calculate_growth_mindset(baseline_data, journal_entries)
            current_value = self._calculate_growth_mindset(recent_data, journal_entries)
            target_value = 0.7
        
        elif metric_id == 'life_satisfaction':
            baseline_value = self._calculate_life_satisfaction(baseline_data)
            current_value = self._calculate_life_satisfaction(recent_data)
            target_value = 0.7
        
        else:
            return None
        
        # Calculate improvement rate
        time_diff = (recent_data['timestamp'].max() - baseline_data['timestamp'].min()).days
        if time_diff > 0:
            improvement_rate = (current_value - baseline_value) / time_diff
        else:
            improvement_rate = 0.0
        
        # Calculate confidence based on data quality
        confidence = min(1.0, (len(baseline_data) + len(recent_data)) / 20)
        
        return GrowthMetric(
            metric_id=metric_id,
            metric_name=definition['name'],
            current_value=current_value,
            baseline_value=baseline_value,
            target_value=target_value,
            improvement_rate=improvement_rate,
            confidence=confidence,
            measurement_period=self.measurement_window,
            last_updated=current_time
        )
    
    def _calculate_emotional_awareness(self, df: pd.DataFrame) -> float:
        """Calculate emotional awareness score"""
        
        # Factors: emotion vocabulary, accuracy, depth of understanding
        emotion_variety = df['emotions'].str.split(',').apply(len).mean()
        emotion_consistency = 1.0 - df['mood'].value_counts(normalize=True).std()
        confidence_avg = df['confidence'].mean()
        
        # Normalize and combine
        variety_score = min(1.0, emotion_variety / 5.0)  # Max 5 emotions per entry
        consistency_score = min(1.0, emotion_consistency)
        confidence_score = confidence_avg
        
        awareness_score = (variety_score * 0.4 + consistency_score * 0.3 + confidence_score * 0.3)
        return min(1.0, awareness_score)
    
    def _calculate_emotional_regulation(self, df: pd.DataFrame) -> float:
        """Calculate emotional regulation score"""
        
        # Factors: intensity stability, recovery patterns, mood transitions
        intensity_stability = 1.0 - min(1.0, df['intensity'].std())
        
        # Calculate recovery patterns (how quickly intensity decreases after peaks)
        recovery_scores = []
        for i in range(1, len(df)):
            if df.iloc[i-1]['intensity'] > 0.7 and df.iloc[i]['intensity'] < df.iloc[i-1]['intensity']:
                recovery_scores.append(df.iloc[i-1]['intensity'] - df.iloc[i]['intensity'])
        
        recovery_effectiveness = np.mean(recovery_scores) if recovery_scores else 0.5
        
        # Mood transition smoothness
        mood_changes = (df['mood'] != df['mood'].shift(1)).sum()
        transition_smoothness = 1.0 - min(1.0, mood_changes / len(df))
        
        regulation_score = (intensity_stability * 0.4 + recovery_effectiveness * 0.3 + 
                          transition_smoothness * 0.3)
        return min(1.0, regulation_score)
    
    def _calculate_resilience(self, df: pd.DataFrame) -> float:
        """Calculate resilience score"""
        
        # Factors: bounce-back speed, stress tolerance, adaptation
        
        # Bounce-back speed: how quickly mood improves after low points
        bounce_back_scores = []
        for i in range(len(df) - 2):
            if (df.iloc[i]['mood'] in ['blue', 'red'] and 
                df.iloc[i+1]['mood'] in ['green', 'purple'] and
                df.iloc[i+2]['mood'] in ['green', 'purple']):
                bounce_back_scores.append(1.0)
            elif (df.iloc[i]['mood'] in ['blue', 'red'] and 
                  df.iloc[i+1]['mood'] in ['green', 'purple']):
                bounce_back_scores.append(0.7)
        
        bounce_back_speed = np.mean(bounce_back_scores) if bounce_back_scores else 0.5
        
        # Stress tolerance: ability to maintain stability under pressure
        high_intensity_entries = df[df['intensity'] > 0.7]
        if len(high_intensity_entries) > 0:
            stress_tolerance = 1.0 - high_intensity_entries['intensity'].std()
        else:
            stress_tolerance = 0.8  # No high stress = good tolerance
        
        # Adaptation: variety in coping strategies and contexts
        context_variety = len([col for col in df.columns if col.startswith('context_') 
                             and df[col].nunique() > 1])
        adaptation_ability = min(1.0, context_variety / 5.0)
        
        resilience_score = (bounce_back_speed * 0.4 + stress_tolerance * 0.3 + 
                          adaptation_ability * 0.3)
        return min(1.0, resilience_score)
    
    def _calculate_self_compassion(self, df: pd.DataFrame, journal_entries: List[Any] = None) -> float:
        """Calculate self-compassion score"""
        
        # Base score from mood data
        positive_mood_ratio = len(df[df['mood'].isin(['green', 'purple'])]) / len(df)
        self_kindness_base = positive_mood_ratio
        
        # Mindfulness: emotional awareness and acceptance
        mindfulness_score = df['confidence'].mean()  # Confidence in emotional awareness
        
        # Common humanity: connection with others (inferred from context)
        social_context_cols = [col for col in df.columns if 'social' in col.lower() or 'friend' in col.lower()]
        if social_context_cols:
            social_connection = df[social_context_cols].notna().any(axis=1).mean()
        else:
            social_connection = 0.5  # Neutral assumption
        
        # Enhanced scoring from journal entries if available
        if journal_entries:
            # Look for self-compassionate language
            compassion_keywords = ['forgive', 'understand', 'gentle', 'kind', 'patient', 'accept']
            self_criticism_keywords = ['stupid', 'failure', 'worthless', 'terrible', 'awful']
            
            compassion_count = 0
            criticism_count = 0
            
            for entry in journal_entries[-10:]:  # Recent entries
                content = entry.content.lower()
                compassion_count += sum(1 for word in compassion_keywords if word in content)
                criticism_count += sum(1 for word in self_criticism_keywords if word in content)
            
            if compassion_count + criticism_count > 0:
                journal_compassion = compassion_count / (compassion_count + criticism_count)
                self_kindness_base = (self_kindness_base + journal_compassion) / 2
        
        self_compassion_score = (self_kindness_base * 0.4 + mindfulness_score * 0.3 + 
                               social_connection * 0.3)
        return min(1.0, self_compassion_score)
    
    def _calculate_emotional_intelligence(self, df: pd.DataFrame) -> float:
        """Calculate emotional intelligence score"""
        
        # Factors: emotional awareness, empathy, social skills, self-management
        
        # Emotional awareness (already calculated)
        awareness_score = self._calculate_emotional_awareness(df)
        
        # Self-management (regulation)
        regulation_score = self._calculate_emotional_regulation(df)
        
        # Social awareness (inferred from context and mood patterns)
        social_contexts = [col for col in df.columns if 'social' in col.lower() or 'people' in col.lower()]
        if social_contexts:
            social_mood_stability = 1.0 - df[df[social_contexts].notna().any(axis=1)]['intensity'].std()
        else:
            social_mood_stability = 0.6  # Neutral assumption
        
        # Relationship management (mood stability in social contexts)
        relationship_score = min(1.0, social_mood_stability)
        
        ei_score = (awareness_score * 0.3 + regulation_score * 0.3 + 
                   social_mood_stability * 0.2 + relationship_score * 0.2)
        return min(1.0, ei_score)
    
    def _calculate_growth_mindset(self, df: pd.DataFrame, journal_entries: List[Any] = None) -> float:
        """Calculate growth mindset score"""
        
        # Base score from mood patterns showing learning and adaptation
        mood_variety = df['mood'].nunique() / 5.0  # Variety indicates openness to experience
        challenge_acceptance = len(df[df['intensity'] > 0.6]) / len(df)  # Willingness to face challenges
        
        base_score = (mood_variety + challenge_acceptance) / 2
        
        # Enhanced scoring from journal entries
        if journal_entries:
            growth_keywords = ['learn', 'grow', 'improve', 'develop', 'progress', 'challenge', 'opportunity']
            fixed_keywords = ['can\'t', 'never', 'always', 'impossible', 'hopeless', 'stuck']
            
            growth_count = 0
            fixed_count = 0
            
            for entry in journal_entries[-10:]:  # Recent entries
                content = entry.content.lower()
                growth_count += sum(1 for word in growth_keywords if word in content)
                fixed_count += sum(1 for word in fixed_keywords if word in content)
            
            if growth_count + fixed_count > 0:
                journal_growth = growth_count / (growth_count + fixed_count)
                base_score = (base_score + journal_growth) / 2
        
        return min(1.0, base_score)
    
    def _calculate_life_satisfaction(self, df: pd.DataFrame) -> float:
        """Calculate life satisfaction score"""
        
        # Factors: mood positivity, intensity stability, overall well-being
        positive_moods = ['green', 'purple']
        mood_positivity = len(df[df['mood'].isin(positive_moods)]) / len(df)
        
        # Intensity should be moderate (not too low, not too high)
        optimal_intensity_range = (0.4, 0.8)
        optimal_intensity_ratio = len(df[
            (df['intensity'] >= optimal_intensity_range[0]) & 
            (df['intensity'] <= optimal_intensity_range[1])
        ]) / len(df)
        
        # Overall emotional stability
        emotional_stability = 1.0 - min(1.0, df['intensity'].std())
        
        satisfaction_score = (mood_positivity * 0.4 + optimal_intensity_ratio * 0.3 + 
                            emotional_stability * 0.3)
        return min(1.0, satisfaction_score)
    
    def detect_growth_milestones(self, metrics: Dict[str, GrowthMetric]) -> List[GrowthMilestone]:
        """Detect significant growth milestones"""
        milestones = []
        
        for metric_id, metric in metrics.items():
            # Check for significant improvement
            improvement = metric.current_value - metric.baseline_value
            
            if improvement >= 0.2 and metric.confidence >= 0.7:
                milestone = GrowthMilestone(
                    milestone_id=f"milestone_{metric_id}_{datetime.now().strftime('%Y%m%d')}",
                    milestone_name=f"Significant {metric.metric_name} Improvement",
                    achievement_date=metric.last_updated,
                    description=f"Achieved {improvement:.2f} improvement in {metric.metric_name}",
                    evidence=[
                        f"Baseline: {metric.baseline_value:.2f}",
                        f"Current: {metric.current_value:.2f}",
                        f"Improvement rate: {metric.improvement_rate:.3f}/day"
                    ],
                    impact_score=improvement * metric.confidence,
                    celebration_worthy=improvement >= 0.3,
                    growth_areas=[metric_id]
                )
                milestones.append(milestone)
                self.milestones[milestone.milestone_id] = milestone
            
            # Check for target achievement
            if (metric.current_value >= metric.target_value and 
                metric.baseline_value < metric.target_value and 
                metric.confidence >= 0.6):
                
                milestone = GrowthMilestone(
                    milestone_id=f"target_{metric_id}_{datetime.now().strftime('%Y%m%d')}",
                    milestone_name=f"{metric.metric_name} Target Achieved",
                    achievement_date=metric.last_updated,
                    description=f"Successfully reached target level in {metric.metric_name}",
                    evidence=[
                        f"Target: {metric.target_value:.2f}",
                        f"Achieved: {metric.current_value:.2f}",
                        f"Started from: {metric.baseline_value:.2f}"
                    ],
                    impact_score=1.0,
                    celebration_worthy=True,
                    growth_areas=[metric_id]
                )
                milestones.append(milestone)
                self.milestones[milestone.milestone_id] = milestone
        
        return milestones
    
    def assess_resilience_profile(self, mood_entries: List[Any], 
                                 patterns: List[Dict[str, Any]] = None) -> ResilienceProfile:
        """Create comprehensive resilience assessment"""
        
        df = self._entries_to_dataframe(mood_entries)
        
        # Calculate resilience components
        stress_tolerance = self._calculate_stress_tolerance(df)
        recovery_speed = self._calculate_recovery_speed(df)
        adaptation_ability = self._calculate_adaptation_ability(df)
        support_utilization = self._calculate_support_utilization(df)
        
        # Overall resilience score
        resilience_score = (stress_tolerance * 0.3 + recovery_speed * 0.3 + 
                          adaptation_ability * 0.2 + support_utilization * 0.2)
        
        # Determine resilience level
        if resilience_score >= 0.8:
            resilience_level = ResilienceLevel.EXCEPTIONAL
        elif resilience_score >= 0.65:
            resilience_level = ResilienceLevel.STRONG
        elif resilience_score >= 0.5:
            resilience_level = ResilienceLevel.MODERATE
        else:
            resilience_level = ResilienceLevel.DEVELOPING
        
        # Identify strengths and growth areas
        component_scores = {
            'stress_tolerance': stress_tolerance,
            'recovery_speed': recovery_speed,
            'adaptation_ability': adaptation_ability,
            'support_utilization': support_utilization
        }
        
        strengths = [name for name, score in component_scores.items() if score >= 0.7]
        growth_areas = [name for name, score in component_scores.items() if score < 0.5]
        
        # Identify coping strategies from patterns
        coping_strategies = self._identify_coping_strategies(df, patterns)
        
        profile = ResilienceProfile(
            profile_id=f"resilience_{datetime.now().strftime('%Y%m%d')}",
            overall_resilience=resilience_level,
            resilience_score=resilience_score,
            strengths=strengths,
            growth_areas=growth_areas,
            coping_strategies=coping_strategies,
            stress_tolerance=stress_tolerance,
            recovery_speed=recovery_speed,
            adaptation_ability=adaptation_ability,
            support_utilization=support_utilization
        )
        
        self.resilience_profiles[profile.profile_id] = profile
        return profile
    
    def _calculate_stress_tolerance(self, df: pd.DataFrame) -> float:
        """Calculate stress tolerance score"""
        
        # Look at behavior during high-intensity periods
        high_stress_entries = df[df['intensity'] > 0.7]
        
        if len(high_stress_entries) == 0:
            return 0.8  # No high stress periods = good tolerance
        
        # Measure stability during stress
        stress_stability = 1.0 - min(1.0, high_stress_entries['intensity'].std())
        
        # Measure mood maintenance during stress
        positive_moods_during_stress = len(high_stress_entries[
            high_stress_entries['mood'].isin(['green', 'purple'])
        ]) / len(high_stress_entries)
        
        tolerance_score = (stress_stability * 0.6 + positive_moods_during_stress * 0.4)
        return min(1.0, tolerance_score)
    
    def _calculate_recovery_speed(self, df: pd.DataFrame) -> float:
        """Calculate recovery speed score"""
        
        recovery_times = []
        
        # Find recovery patterns after difficult periods
        for i in range(len(df) - 1):
            if (df.iloc[i]['mood'] in ['blue', 'red'] and df.iloc[i]['intensity'] > 0.6):
                # Look for recovery in subsequent entries
                for j in range(i + 1, min(i + 5, len(df))):  # Look ahead up to 5 entries
                    if (df.iloc[j]['mood'] in ['green', 'purple'] or 
                        df.iloc[j]['intensity'] < df.iloc[i]['intensity'] - 0.3):
                        recovery_time = j - i
                        recovery_times.append(recovery_time)
                        break
        
        if not recovery_times:
            return 0.5  # Neutral score if no recovery patterns found
        
        # Faster recovery = higher score
        avg_recovery_time = np.mean(recovery_times)
        recovery_speed = max(0.0, 1.0 - (avg_recovery_time - 1) / 4)  # Normalize to 0-1
        
        return min(1.0, recovery_speed)
    
    def _calculate_adaptation_ability(self, df: pd.DataFrame) -> float:
        """Calculate adaptation ability score"""
        
        # Measure variety in contexts and responses
        context_cols = [col for col in df.columns if col.startswith('context_')]
        
        if not context_cols:
            return 0.5  # Neutral score if no context data
        
        # Calculate context variety
        context_variety = 0
        for col in context_cols:
            unique_values = df[col].nunique()
            if unique_values > 1:
                context_variety += min(1.0, unique_values / 5.0)
        
        context_variety = context_variety / len(context_cols) if context_cols else 0.5
        
        # Measure mood flexibility across contexts
        mood_flexibility = 0
        for col in context_cols:
            if df[col].nunique() > 1:
                context_mood_variety = df.groupby(col)['mood'].nunique().mean()
                mood_flexibility += min(1.0, context_mood_variety / 3.0)
        
        mood_flexibility = mood_flexibility / len(context_cols) if context_cols else 0.5
        
        adaptation_score = (context_variety * 0.6 + mood_flexibility * 0.4)
        return min(1.0, adaptation_score)
    
    def _calculate_support_utilization(self, df: pd.DataFrame) -> float:
        """Calculate support utilization score"""
        
        # Look for social contexts and support-seeking behaviors
        social_contexts = [col for col in df.columns if 
                          any(keyword in col.lower() for keyword in ['social', 'friend', 'family', 'support'])]
        
        if not social_contexts:
            return 0.4  # Lower score if no social context data
        
        # Measure social engagement during difficult times
        difficult_entries = df[df['intensity'] > 0.6]
        
        if len(difficult_entries) == 0:
            return 0.7  # Good score if no difficult times
        
        social_engagement_during_difficulty = 0
        for col in social_contexts:
            engagement = difficult_entries[col].notna().mean()
            social_engagement_during_difficulty += engagement
        
        support_score = social_engagement_during_difficulty / len(social_contexts) if social_contexts else 0.4
        return min(1.0, support_score)
    
    def _identify_coping_strategies(self, df: pd.DataFrame, patterns: List[Dict[str, Any]] = None) -> List[str]:
        """Identify effective coping strategies"""
        strategies = []
        
        # From context data
        context_cols = [col for col in df.columns if col.startswith('context_')]
        
        for col in context_cols:
            # Find contexts associated with mood improvement
            context_values = df[col].unique()
            for value in context_values:
                if pd.notna(value) and value != 'unknown':
                    context_entries = df[df[col] == value]
                    if len(context_entries) >= 3:
                        avg_mood_quality = self._calculate_mood_quality(context_entries)
                        if avg_mood_quality > 0.6:
                            strategy_name = f"{col.replace('context_', '').replace('_', ' ')}: {value}"
                            strategies.append(strategy_name)
        
        # From patterns
        if patterns:
            for pattern in patterns:
                if pattern.get('strength', 0) > 0.7 and 'positive' in pattern.get('description', '').lower():
                    strategies.append(f"Pattern-based: {pattern.get('name', 'Unknown')}")
        
        # Default strategies if none found
        if not strategies:
            strategies = ['Self-reflection', 'Emotional awareness', 'Time-based recovery']
        
        return strategies[:5]  # Limit to top 5
    
    def _calculate_mood_quality(self, df: pd.DataFrame) -> float:
        """Calculate overall mood quality score"""
        positive_moods = ['green', 'purple']
        mood_positivity = len(df[df['mood'].isin(positive_moods)]) / len(df)
        avg_intensity = df['intensity'].mean()
        
        # Optimal intensity is moderate (0.4-0.7)
        intensity_quality = 1.0 - abs(avg_intensity - 0.55) / 0.45
        
        return (mood_positivity * 0.7 + intensity_quality * 0.3)
    
    def _entries_to_dataframe(self, mood_entries: List[Any]) -> pd.DataFrame:
        """Convert mood entries to pandas DataFrame for analysis"""
        
        data = []
        for entry in mood_entries:
            row = {
                'timestamp': entry.timestamp,
                'mood': entry.mood,
                'intensity': entry.intensity,
                'emotions': ','.join(entry.emotions),
                'source': entry.source,
                'confidence': entry.confidence
            }
            
            # Add context fields
            for key, value in entry.context.items():
                row[f'context_{key}'] = str(value)
            
            data.append(row)
        
        df = pd.DataFrame(data)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        return df
    
    def generate_growth_insights(self, metrics: Dict[str, GrowthMetric], 
                                milestones: List[GrowthMilestone],
                                resilience_profile: ResilienceProfile) -> List[Dict[str, Any]]:
        """Generate insights from growth analysis"""
        insights = []
        
        # Metric insights
        improving_metrics = [m for m in metrics.values() if m.improvement_rate > 0.01]
        declining_metrics = [m for m in metrics.values() if m.improvement_rate < -0.01]
        
        if improving_metrics:
            insights.append({
                'type': 'growth_progress',
                'title': 'Positive Growth Trends',
                'description': f'Showing improvement in {len(improving_metrics)} areas of emotional development',
                'priority': 'medium',
                'actionable': False,
                'celebration': True,
                'metrics': [m.metric_name for m in improving_metrics]
            })
        
        if declining_metrics:
            insights.append({
                'type': 'growth_concerns',
                'title': 'Areas Needing Attention',
                'description': f'{len(declining_metrics)} growth areas showing decline',
                'priority': 'high',
                'actionable': True,
                'support_needed': True,
                'metrics': [m.metric_name for m in declining_metrics]
            })
        
        # Milestone insights
        if milestones:
            celebration_milestones = [m for m in milestones if m.celebration_worthy]
            if celebration_milestones:
                insights.append({
                    'type': 'milestones_achieved',
                    'title': 'Growth Milestones Achieved',
                    'description': f'Congratulations on achieving {len(celebration_milestones)} significant milestones!',
                    'priority': 'low',
                    'actionable': False,
                    'celebration': True,
                    'milestones': [m.milestone_name for m in celebration_milestones]
                })
        
        # Resilience insights
        if resilience_profile.overall_resilience in [ResilienceLevel.STRONG, ResilienceLevel.EXCEPTIONAL]:
            insights.append({
                'type': 'high_resilience',
                'title': 'Strong Emotional Resilience',
                'description': f'Your resilience profile shows {resilience_profile.overall_resilience.value} characteristics',
                'priority': 'low',
                'actionable': False,
                'celebration': True,
                'strengths': resilience_profile.strengths
            })
        elif resilience_profile.overall_resilience == ResilienceLevel.DEVELOPING:
            insights.append({
                'type': 'resilience_development',
                'title': 'Resilience Development Opportunity',
                'description': 'Your resilience profile shows room for growth and development',
                'priority': 'medium',
                'actionable': True,
                'growth_areas': resilience_profile.growth_areas,
                'coping_strategies': resilience_profile.coping_strategies
            })
        
        return insights

