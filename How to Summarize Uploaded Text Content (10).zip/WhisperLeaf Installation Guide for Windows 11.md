# WhisperLeaf Installation Guide for Windows 11
## Dell Inspiron 16 and Other Windows Systems

**🌿 Welcome to WhisperLeaf installation for Windows!** This guide provides step-by-step instructions for installing your sovereign emotional AI companion on Windows 11, specifically optimized for Dell Inspiron 16 and similar systems.

---

## 🎯 Quick Start (Recommended)

### **Option 1: Automated Installation (Easiest)**

1. **Extract the WhisperLeaf package** to your desired location (e.g., `C:\WhisperLeaf`)
2. **Right-click on `install_whisperleaf.bat`** and select **"Run as administrator"**
3. **Follow the on-screen prompts** - the installer will handle everything automatically
4. **Wait for completion** (typically 10-15 minutes)
5. **Double-click "Start WhisperLeaf"** on your desktop when finished

**That's it!** WhisperLeaf will open in your browser at `http://localhost:5173`

### **Option 2: PowerShell Installation (Advanced)**

1. **Open PowerShell as Administrator**
   - Press `Win + X` and select "Windows PowerShell (Admin)"
2. **Navigate to the WhisperLeaf directory**
   ```powershell
   cd "C:\path\to\whisperleaf"
   ```
3. **Run the installation script**
   ```powershell
   .\install_whisperleaf_windows.ps1
   ```
4. **Follow the prompts** and wait for completion

---

## 🖥️ System Requirements

### **Your Dell Inspiron 16 Specifications**

**✅ Excellent Hardware Match:**
- **Processor:** Intel Core i5/i7 or AMD Ryzen 5/7 (More than sufficient)
- **Memory:** 8-16GB RAM (WhisperLeaf needs minimum 4GB)
- **Storage:** 256GB+ SSD (WhisperLeaf needs only 5GB total)
- **Operating System:** Windows 11 (Fully supported)

### **Minimum Requirements (All Systems)**
- **OS:** Windows 10 version 1903 or Windows 11
- **RAM:** 4GB (8GB recommended)
- **Storage:** 5GB free space
- **Internet:** Required for initial setup only
- **Browser:** Chrome, Firefox, or Edge (for web interface)

### **Recommended Specifications**
- **RAM:** 8GB or more for optimal performance
- **Storage:** SSD for faster database operations
- **CPU:** Multi-core processor for faster AI processing

---

## 🔧 Pre-Installation Checklist

### **Before You Begin:**

**✅ Administrative Access**
- Ensure you have administrator privileges on your computer
- You may need to temporarily disable antivirus during installation

**✅ Internet Connection**
- Required for downloading Python and Node.js (if not already installed)
- WhisperLeaf works completely offline after installation

**✅ Available Disk Space**
- Check that you have at least 5GB free space
- Recommended location: `C:\WhisperLeaf` or `C:\Users\[YourName]\WhisperLeaf`

**✅ Antivirus Considerations**
- Some antivirus software may flag the installation scripts
- Temporarily disable real-time protection if needed
- Add WhisperLeaf folder to antivirus exclusions after installation

---

## 📋 Detailed Installation Steps

### **Step 1: Extract WhisperLeaf Package**

1. **Download the WhisperLeaf package** (whisperleaf_complete_package.zip)
2. **Right-click the ZIP file** and select "Extract All..."
3. **Choose installation location:**
   - Recommended: `C:\WhisperLeaf`
   - Alternative: `C:\Users\[YourName]\WhisperLeaf`
4. **Extract all files** to the chosen location

### **Step 2: Run Installation Script**

**Method A: Batch File (Easiest)**
1. **Navigate to the WhisperLeaf folder**
2. **Right-click `install_whisperleaf.bat`**
3. **Select "Run as administrator"**
4. **Click "Yes"** when prompted by User Account Control
5. **Follow the on-screen instructions**

**Method B: PowerShell (Advanced)**
1. **Press `Win + X`** and select "Windows PowerShell (Admin)"
2. **Navigate to WhisperLeaf directory:**
   ```powershell
   cd "C:\WhisperLeaf"
   ```
3. **Run the installation script:**
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
   .\install_whisperleaf_windows.ps1
   ```

### **Step 3: Installation Process**

The installer will automatically:

**🐍 Install Python 3.11** (if needed)
- Downloads Python 3.11.8 from python.org
- Installs with PATH configuration
- Verifies installation success

**📦 Install Node.js** (if needed)
- Downloads Node.js LTS from nodejs.org
- Installs with npm package manager
- Configures PATH variables

**🏗️ Setup WhisperLeaf**
- Creates Python virtual environment
- Installs all Python dependencies
- Installs Node.js dependencies for web interface
- Initializes database and configuration
- Creates desktop shortcuts and startup scripts

### **Step 4: Verify Installation**

After installation completes, you should see:

**✅ Desktop Shortcuts:**
- "Start WhisperLeaf" shortcut on desktop
- Links to WhisperLeaf folder and documentation

**✅ Installation Folder:**
- Complete WhisperLeaf system in chosen directory
- `start_whisperleaf.bat` for easy launching
- All documentation and guides included

**✅ Success Message:**
- Installation completion confirmation
- Instructions for starting WhisperLeaf
- Browser URL: `http://localhost:5173`

---

## 🚀 Starting WhisperLeaf

### **Method 1: Desktop Shortcut (Recommended)**
1. **Double-click "Start WhisperLeaf"** on your desktop
2. **Wait for startup** (30-60 seconds)
3. **WhisperLeaf opens automatically** in your default browser

### **Method 2: Manual Start**
1. **Navigate to WhisperLeaf folder**
2. **Double-click `start_whisperleaf.bat`**
3. **Wait for services to start**
4. **Open browser** to `http://localhost:5173`

### **Method 3: PowerShell Start**
```powershell
cd "C:\WhisperLeaf"
.\start_whisperleaf.ps1
```

### **First Launch Experience**

**When WhisperLeaf starts for the first time:**
1. **API Server starts** (runs in background)
2. **Web interface launches** (React development server)
3. **Browser opens automatically** to WhisperLeaf interface
4. **Welcome screen appears** with setup wizard
5. **Begin your first conversation!**

---

## 🛠️ Troubleshooting Common Issues

### **Installation Problems**

**❌ "Python not found" Error**
```
Solution: Install Python manually
1. Download Python 3.11+ from python.org
2. Run installer with "Add Python to PATH" checked
3. Restart installation script
```

**❌ "Permission denied" Error**
```
Solution: Run as administrator
1. Right-click installation script
2. Select "Run as administrator"
3. Click "Yes" in User Account Control prompt
```

**❌ "PowerShell execution policy" Error**
```
Solution: Allow script execution
1. Open PowerShell as administrator
2. Run: Set-ExecutionPolicy -ExecutionPolicy RemoteSigned
3. Type "Y" to confirm
4. Retry installation
```

**❌ Antivirus blocking installation**
```
Solution: Temporarily disable antivirus
1. Disable real-time protection temporarily
2. Run installation
3. Add WhisperLeaf folder to exclusions
4. Re-enable antivirus protection
```

### **Startup Problems**

**❌ "Port 5173 already in use"**
```
Solution: Kill conflicting process
1. Open Task Manager (Ctrl+Shift+Esc)
2. Find and end any Node.js or npm processes
3. Restart WhisperLeaf
```

**❌ "Cannot connect to API server"**
```
Solution: Check API server status
1. Open Task Manager
2. Look for Python process running main.py
3. If not found, restart WhisperLeaf
4. Check Windows Firewall settings
```

**❌ Browser doesn't open automatically**
```
Solution: Open manually
1. Open your web browser
2. Navigate to: http://localhost:5173
3. Bookmark for future use
```

### **Performance Issues**

**❌ Slow response times**
```
Solutions:
1. Close unnecessary applications to free RAM
2. Ensure WhisperLeaf is on SSD (not HDD)
3. Check Windows Update for system optimization
4. Restart computer if running for extended period
```

**❌ High CPU usage**
```
Solutions:
1. Check for Windows updates
2. Ensure adequate cooling (especially on laptops)
3. Close resource-intensive applications
4. Consider upgrading RAM if using minimum requirements
```

---

## 🔒 Security and Privacy Configuration

### **Windows Firewall Configuration**

WhisperLeaf runs locally and doesn't need external network access, but Windows Firewall may prompt for permissions:

**When prompted:**
1. **Allow access** for Python and Node.js
2. **Select "Private networks"** only
3. **Do NOT allow public network access**

**Manual Firewall Configuration:**
1. Open **Windows Security** → **Firewall & network protection**
2. Click **"Allow an app through firewall"**
3. Add **Python** and **Node.js** for private networks only

### **Privacy Settings**

**WhisperLeaf Privacy Features:**
- **Complete local processing** - no data leaves your computer
- **Encrypted local storage** - all emotional data protected
- **No external connections** - works completely offline
- **No telemetry or tracking** - your data stays private

**Recommended Privacy Settings:**
1. **Disable Windows telemetry** for maximum privacy
2. **Use local Windows account** instead of Microsoft account
3. **Configure Windows Update** to manual if desired
4. **Review app permissions** in Windows Privacy settings

---

## 🎛️ Advanced Configuration

### **Custom Installation Location**

To install WhisperLeaf in a custom location:

```powershell
.\install_whisperleaf_windows.ps1 -InstallPath "D:\MyApps\WhisperLeaf"
```

### **Skip Python Installation**

If you already have Python 3.11+ installed:

```powershell
.\install_whisperleaf_windows.ps1 -SkipPython
```

### **Verbose Installation**

For detailed installation logging:

```powershell
.\install_whisperleaf_windows.ps1 -Verbose
```

### **Multiple User Setup**

For family or shared computer use:

1. **Install WhisperLeaf** in a shared location (e.g., `C:\WhisperLeaf`)
2. **Create separate user accounts** in WhisperLeaf interface
3. **Configure individual privacy settings** for each user
4. **Set up parental controls** if needed for children

---

## 🔄 Updating WhisperLeaf

### **Checking for Updates**

WhisperLeaf includes an update checker:

1. **Open WhisperLeaf interface**
2. **Go to Settings** → **System**
3. **Click "Check for Updates"**
4. **Follow update instructions** if available

### **Manual Update Process**

1. **Backup your data** (Settings → Export Data)
2. **Download new WhisperLeaf version**
3. **Stop current WhisperLeaf** (close browser and command windows)
4. **Extract new version** over existing installation
5. **Run update script** if provided
6. **Restart WhisperLeaf**

---

## 🗑️ Uninstalling WhisperLeaf

### **Complete Removal**

1. **Stop WhisperLeaf** (close all browser windows and command prompts)
2. **Delete WhisperLeaf folder** (e.g., `C:\WhisperLeaf`)
3. **Remove desktop shortcuts**
4. **Optional: Uninstall Python and Node.js** if not needed for other applications

### **Preserving Data**

To keep your emotional data for future use:

1. **Export data** before uninstalling (Settings → Export Data)
2. **Save export file** to safe location
3. **Import data** when reinstalling WhisperLeaf

---

## 📞 Getting Help

### **Built-in Help**

- **Documentation folder** in WhisperLeaf installation
- **Help section** in WhisperLeaf interface
- **Troubleshooting guide** (ADVANCED_FEATURES_GUIDE.md)

### **Common Solutions**

**Installation Issues:**
- Run as administrator
- Temporarily disable antivirus
- Check internet connection
- Ensure sufficient disk space

**Runtime Issues:**
- Restart WhisperLeaf
- Check Task Manager for conflicts
- Clear browser cache
- Restart computer

### **System Information**

For troubleshooting, gather this information:

- **Windows version:** `winver` command
- **Python version:** `python --version`
- **Node.js version:** `node --version`
- **Available RAM:** Task Manager → Performance
- **Free disk space:** File Explorer → This PC

---

## 🎉 Welcome to WhisperLeaf!

**Congratulations!** You've successfully installed WhisperLeaf on your Dell Inspiron 16. Your sovereign emotional AI companion is ready to support your emotional wellness journey.

### **Next Steps:**

1. **Read the USER_GUIDE.md** for basic usage instructions
2. **Review EMOTIONAL_SAFETY_GUIDE.md** for healthy AI interaction
3. **Explore the interface** and start your first conversation
4. **Customize your experience** using the settings panel
5. **Create your first time capsule** for future reflection

### **Key Features to Explore:**

**🗣️ Chat Interface** - Natural conversation with your AI companion  
**📝 Journal Interface** - Reflective writing with guided prompts  
**📊 Mood Timeline** - Visual tracking of emotional patterns  
**⏰ Time Capsules** - Messages to your future self  
**🛡️ Constitutional AI** - Customize AI behavior with your values  
**🔒 Complete Privacy** - Everything stays on your computer  

**Your emotional data belongs to you. Your AI works for you. Your privacy is protected by design.**

**Welcome to the future of sovereign emotional AI!** 🌿

---

## 📋 Installation Checklist

**Pre-Installation:**
- [ ] Administrator access confirmed
- [ ] 5GB+ free disk space available
- [ ] Internet connection active
- [ ] Antivirus temporarily disabled (if needed)

**Installation Process:**
- [ ] WhisperLeaf package extracted
- [ ] Installation script run as administrator
- [ ] Python 3.11+ installed and verified
- [ ] Node.js installed and verified
- [ ] Virtual environment created successfully
- [ ] Dependencies installed without errors
- [ ] Database initialized
- [ ] Desktop shortcuts created

**Post-Installation:**
- [ ] WhisperLeaf starts successfully
- [ ] Browser opens to http://localhost:5173
- [ ] Interface loads without errors
- [ ] First conversation completed
- [ ] Documentation reviewed
- [ ] Antivirus exclusions added
- [ ] System running smoothly

**🎯 Installation Complete!** Your Dell Inspiron 16 is now running WhisperLeaf perfectly! 🌿

---

*This installation guide is specifically optimized for Dell Inspiron 16 and Windows 11 systems. For other Windows versions or hardware configurations, refer to the general DEPLOYMENT_GUIDE.md for additional options and troubleshooting.*

