"""
Vector database integration for semantic search and document embeddings.
"""

import os
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any, Optional, Tuple
import hashlib
import json
from pathlib import Path

class VectorStore:
    """Manages vector embeddings and semantic search for documents."""
    
    def __init__(self, persist_directory: str = "./data/chroma_db"):
        self.persist_directory = Path(persist_directory)
        self.persist_directory.mkdir(parents=True, exist_ok=True)
        
        # Initialize ChromaDB client
        self.client = chromadb.PersistentClient(
            path=str(self.persist_directory),
            settings=Settings(
                anonymized_telemetry=False,
                allow_reset=True
            )
        )
        
        # Initialize embedding model
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Get or create collection
        self.collection = self.client.get_or_create_collection(
            name="documents",
            metadata={"description": "Document embeddings for semantic search"}
        )
    
    def _generate_embedding_id(self, document_id: str, chunk_index: int = 0) -> str:
        """Generate a unique ID for an embedding."""
        return f"{document_id}_{chunk_index}"
    
    def _chunk_text(self, text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
        """Split text into overlapping chunks for better embedding coverage."""
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + chunk_size
            
            # Try to break at a sentence or word boundary
            if end < len(text):
                # Look for sentence boundary
                sentence_end = text.rfind('.', start, end)
                if sentence_end > start + chunk_size // 2:
                    end = sentence_end + 1
                else:
                    # Look for word boundary
                    word_end = text.rfind(' ', start, end)
                    if word_end > start + chunk_size // 2:
                        end = word_end
            
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            
            start = end - overlap
            if start >= len(text):
                break
        
        return chunks
    
    def add_document(
        self,
        document_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Add a document to the vector store."""
        try:
            # Remove existing embeddings for this document
            self.remove_document(document_id)
            
            # Chunk the content
            chunks = self._chunk_text(content)
            
            # Generate embeddings for each chunk
            embeddings = self.embedding_model.encode(chunks).tolist()
            
            # Prepare data for ChromaDB
            ids = [self._generate_embedding_id(document_id, i) for i in range(len(chunks))]
            metadatas = []
            
            for i, chunk in enumerate(chunks):
                chunk_metadata = {
                    "document_id": document_id,
                    "chunk_index": i,
                    "chunk_text": chunk[:500],  # Store first 500 chars for preview
                    "chunk_length": len(chunk)
                }
                if metadata:
                    chunk_metadata.update(metadata)
                metadatas.append(chunk_metadata)
            
            # Add to collection
            self.collection.add(
                embeddings=embeddings,
                documents=chunks,
                metadatas=metadatas,
                ids=ids
            )
            
            return True
            
        except Exception as e:
            print(f"Error adding document to vector store: {e}")
            return False
    
    def remove_document(self, document_id: str) -> bool:
        """Remove all embeddings for a document."""
        try:
            # Query for all chunks of this document
            results = self.collection.get(
                where={"document_id": document_id}
            )
            
            if results['ids']:
                self.collection.delete(ids=results['ids'])
            
            return True
            
        except Exception as e:
            print(f"Error removing document from vector store: {e}")
            return False
    
    def search(
        self,
        query: str,
        n_results: int = 10,
        document_ids: Optional[List[str]] = None,
        metadata_filter: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Search for similar documents using semantic similarity."""
        try:
            # Generate query embedding
            query_embedding = self.embedding_model.encode([query]).tolist()[0]
            
            # Build where clause
            where_clause = {}
            if document_ids:
                where_clause["document_id"] = {"$in": document_ids}
            if metadata_filter:
                where_clause.update(metadata_filter)
            
            # Search in ChromaDB
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=n_results,
                where=where_clause if where_clause else None,
                include=["documents", "metadatas", "distances"]
            )
            
            # Format results
            search_results = []
            for i in range(len(results['ids'][0])):
                result = {
                    "id": results['ids'][0][i],
                    "document_id": results['metadatas'][0][i]['document_id'],
                    "content": results['documents'][0][i],
                    "metadata": results['metadatas'][0][i],
                    "similarity_score": 1 - results['distances'][0][i],  # Convert distance to similarity
                    "distance": results['distances'][0][i]
                }
                search_results.append(result)
            
            return search_results
            
        except Exception as e:
            print(f"Error searching vector store: {e}")
            return []
    
    def get_document_chunks(self, document_id: str) -> List[Dict[str, Any]]:
        """Get all chunks for a specific document."""
        try:
            results = self.collection.get(
                where={"document_id": document_id},
                include=["documents", "metadatas"]
            )
            
            chunks = []
            for i in range(len(results['ids'])):
                chunk = {
                    "id": results['ids'][i],
                    "content": results['documents'][i],
                    "metadata": results['metadatas'][i]
                }
                chunks.append(chunk)
            
            # Sort by chunk index
            chunks.sort(key=lambda x: x['metadata'].get('chunk_index', 0))
            return chunks
            
        except Exception as e:
            print(f"Error getting document chunks: {e}")
            return []
    
    def update_document_metadata(
        self,
        document_id: str,
        metadata_updates: Dict[str, Any]
    ) -> bool:
        """Update metadata for all chunks of a document."""
        try:
            # Get all chunk IDs for this document
            results = self.collection.get(
                where={"document_id": document_id},
                include=["metadatas"]
            )
            
            if not results['ids']:
                return False
            
            # Update metadata for each chunk
            updated_metadatas = []
            for metadata in results['metadatas']:
                updated_metadata = metadata.copy()
                updated_metadata.update(metadata_updates)
                updated_metadatas.append(updated_metadata)
            
            # Update in ChromaDB
            self.collection.update(
                ids=results['ids'],
                metadatas=updated_metadatas
            )
            
            return True
            
        except Exception as e:
            print(f"Error updating document metadata: {e}")
            return False
    
    def get_collection_stats(self) -> Dict[str, Any]:
        """Get statistics about the vector store collection."""
        try:
            count = self.collection.count()
            
            # Get sample of documents to analyze
            sample_results = self.collection.get(
                limit=min(100, count),
                include=["metadatas"]
            )
            
            # Count unique documents
            unique_documents = set()
            content_types = {}
            
            for metadata in sample_results['metadatas']:
                doc_id = metadata.get('document_id')
                if doc_id:
                    unique_documents.add(doc_id)
                
                content_type = metadata.get('content_type', 'unknown')
                content_types[content_type] = content_types.get(content_type, 0) + 1
            
            return {
                "total_chunks": count,
                "unique_documents": len(unique_documents),
                "content_types": content_types,
                "embedding_model": "all-MiniLM-L6-v2",
                "embedding_dimensions": 384
            }
            
        except Exception as e:
            print(f"Error getting collection stats: {e}")
            return {}
    
    def reset_collection(self) -> bool:
        """Reset the entire collection (use with caution)."""
        try:
            self.client.delete_collection("documents")
            self.collection = self.client.get_or_create_collection(
                name="documents",
                metadata={"description": "Document embeddings for semantic search"}
            )
            return True
            
        except Exception as e:
            print(f"Error resetting collection: {e}")
            return False

