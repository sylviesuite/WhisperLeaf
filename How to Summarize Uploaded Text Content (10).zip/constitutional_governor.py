"""
WhisperLeaf Constitutional Governor
Main governance system integrating all constitutional AI components
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import logging
import json
from pathlib import Path

from .emotional_constitution import EmotionalConstitution, ConstitutionalRule
from .safety_monitor import SafetyMonitor, SafetyAlert, SafetyLevel
from .crisis_responder import CrisisResponder, CrisisResponse, CrisisLevel

logger = logging.getLogger(__name__)

class GovernanceDecision:
    """Decision made by constitutional governor"""
    
    def __init__(self, 
                 decision_id: str,
                 timestamp: datetime,
                 context: Dict[str, Any],
                 constitutional_evaluation: Dict[str, Any],
                 safety_assessment: SafetyAlert,
                 crisis_response: Optional[CrisisResponse],
                 final_guidance: Dict[str, Any],
                 ai_prompt_modifications: Dict[str, Any]):
        
        self.decision_id = decision_id
        self.timestamp = timestamp
        self.context = context
        self.constitutional_evaluation = constitutional_evaluation
        self.safety_assessment = safety_assessment
        self.crisis_response = crisis_response
        self.final_guidance = final_guidance
        self.ai_prompt_modifications = ai_prompt_modifications
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert decision to dictionary for logging/storage"""
        return {
            'decision_id': self.decision_id,
            'timestamp': self.timestamp.isoformat(),
            'context_summary': {
                'mood': self.context.get('mood'),
                'emotions': self.context.get('emotions', []),
                'message_length': len(self.context.get('message', ''))
            },
            'constitutional_rules_applied': len(self.constitutional_evaluation.get('applicable_rules', [])),
            'safety_level': self.safety_assessment.safety_level.value,
            'crisis_detected': self.crisis_response is not None,
            'crisis_level': self.crisis_response.crisis_level.value if self.crisis_response else 'none',
            'final_guidance': self.final_guidance,
            'ai_modifications': self.ai_prompt_modifications
        }

class ConstitutionalGovernor:
    """
    Main constitutional governance system for WhisperLeaf
    Integrates constitution, safety monitoring, and crisis response
    """
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = Path(config_path) if config_path else Path("config/constitutional_config.json")
        
        # Initialize core components
        self.constitution = EmotionalConstitution()
        self.safety_monitor = SafetyMonitor()
        self.crisis_responder = CrisisResponder()
        
        # Governance configuration
        self.governance_config = self._load_governance_config()
        
        # Decision history for learning and auditing
        self.decision_history: List[GovernanceDecision] = []
        self.max_history_size = 1000
        
        # Governance statistics
        self.governance_stats = {
            'total_decisions': 0,
            'constitutional_blocks': 0,
            'safety_interventions': 0,
            'crisis_responses': 0,
            'ai_modifications': 0,
            'last_decision': None
        }
        
        logger.info("ConstitutionalGovernor initialized with full governance framework")
    
    def _load_governance_config(self) -> Dict[str, Any]:
        """Load governance configuration"""
        default_config = {
            'safety_threshold': 0.7,  # Threshold for safety interventions
            'crisis_threshold': 0.8,  # Threshold for crisis responses
            'constitutional_override': True,  # Constitution can override other decisions
            'learning_enabled': True,  # Learn from decisions to improve
            'audit_logging': True,  # Log all decisions for audit
            'ai_modification_enabled': True,  # Allow AI prompt modifications
            'response_templates': {
                'constitutional_block': "I understand you're looking for support, but I need to respond in a way that's safe and helpful. Let me offer some alternative support.",
                'safety_intervention': "I'm concerned about your wellbeing. Let me provide some resources and support that might help.",
                'crisis_response': "I'm very concerned about you right now. Your safety is the most important thing."
            }
        }
        
        try:
            if self.config_path.exists():
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                    default_config.update(config)
        except Exception as e:
            logger.warning(f"Could not load governance config: {e}, using defaults")
        
        return default_config
    
    def _save_governance_config(self):
        """Save governance configuration"""
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(self.governance_config, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save governance config: {e}")
    
    def evaluate_interaction(self, message: str, context: Dict[str, Any]) -> GovernanceDecision:
        """
        Comprehensive evaluation of user interaction through constitutional lens
        
        Args:
            message: User message to evaluate
            context: Interaction context (mood, emotions, history, etc.)
            
        Returns:
            GovernanceDecision with complete evaluation and guidance
        """
        
        self.governance_stats['total_decisions'] += 1
        self.governance_stats['last_decision'] = datetime.now()
        
        decision_id = f"gov_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
        
        # Step 1: Constitutional evaluation
        constitutional_evaluation = self.constitution.evaluate_context({
            'message': message,
            **context
        })
        
        # Step 2: Safety assessment
        safety_assessment = self.safety_monitor.evaluate_safety(message, context)
        
        # Step 3: Crisis response if needed
        crisis_response = None
        if (safety_assessment.safety_level in [SafetyLevel.DANGER, SafetyLevel.CRITICAL] or
            safety_assessment.confidence_score >= self.governance_config['crisis_threshold']):
            
            crisis_response = self.crisis_responder.generate_crisis_response(
                safety_assessment, context
            )
            self.governance_stats['crisis_responses'] += 1
        
        # Step 4: Integrate all evaluations into final guidance
        final_guidance = self._integrate_evaluations(
            constitutional_evaluation, safety_assessment, crisis_response, context
        )
        
        # Step 5: Generate AI prompt modifications
        ai_prompt_modifications = self._generate_ai_modifications(
            constitutional_evaluation, safety_assessment, crisis_response, final_guidance
        )
        
        # Create governance decision
        decision = GovernanceDecision(
            decision_id=decision_id,
            timestamp=datetime.now(),
            context=context,
            constitutional_evaluation=constitutional_evaluation,
            safety_assessment=safety_assessment,
            crisis_response=crisis_response,
            final_guidance=final_guidance,
            ai_prompt_modifications=ai_prompt_modifications
        )
        
        # Store decision in history
        self.decision_history.append(decision)
        if len(self.decision_history) > self.max_history_size:
            self.decision_history.pop(0)
        
        # Update statistics
        if final_guidance.get('block_response', False):
            self.governance_stats['constitutional_blocks'] += 1
        
        if safety_assessment.safety_level != SafetyLevel.SAFE:
            self.governance_stats['safety_interventions'] += 1
        
        if ai_prompt_modifications.get('modifications_applied', False):
            self.governance_stats['ai_modifications'] += 1
        
        logger.info(f"Governance decision {decision_id}: {final_guidance.get('response_type', 'normal')}")
        
        return decision
    
    def _integrate_evaluations(self, constitutional_eval: Dict[str, Any],
                             safety_assessment: SafetyAlert,
                             crisis_response: Optional[CrisisResponse],
                             context: Dict[str, Any]) -> Dict[str, Any]:
        """Integrate all evaluations into final guidance"""
        
        guidance = {
            'response_type': 'normal',
            'tone': 'supportive',
            'safety_level': safety_assessment.safety_level.value,
            'block_response': False,
            'modify_response': False,
            'crisis_intervention': False,
            'immediate_response': None,
            'resources_needed': False,
            'escalation_required': False,
            'monitoring_required': False
        }
        
        # Apply constitutional guidance
        const_guidance = constitutional_eval.get('guidance', {})
        guidance.update({
            'tone': const_guidance.get('tone', guidance['tone']),
            'response_type': const_guidance.get('response_type', guidance['response_type'])
        })
        
        # Apply safety guidance (higher priority)
        if safety_assessment.safety_level in [SafetyLevel.WARNING, SafetyLevel.DANGER, SafetyLevel.CRITICAL]:
            guidance.update({
                'modify_response': True,
                'resources_needed': True,
                'immediate_response': safety_assessment.recommended_response
            })
            
            if safety_assessment.safety_level in [SafetyLevel.DANGER, SafetyLevel.CRITICAL]:
                guidance.update({
                    'escalation_required': True,
                    'monitoring_required': True
                })
        
        # Apply crisis response (highest priority)
        if crisis_response:
            guidance.update({
                'response_type': 'crisis_support',
                'crisis_intervention': True,
                'immediate_response': crisis_response.immediate_response,
                'resources_needed': True,
                'escalation_required': crisis_response.crisis_level in [CrisisLevel.HIGH, CrisisLevel.CRITICAL],
                'monitoring_required': crisis_response.monitoring_required
            })
        
        # Check for constitutional blocks
        safety_flags = constitutional_eval.get('safety_flags', [])
        if any(flag.get('action_required', False) for flag in safety_flags):
            guidance['block_response'] = True
            guidance['immediate_response'] = self.governance_config['response_templates']['constitutional_block']
        
        # Override decisions based on configuration
        if self.governance_config.get('constitutional_override', True):
            if constitutional_eval.get('guidance', {}).get('escalation_needed', False):
                guidance['escalation_required'] = True
        
        return guidance
    
    def _generate_ai_modifications(self, constitutional_eval: Dict[str, Any],
                                 safety_assessment: SafetyAlert,
                                 crisis_response: Optional[CrisisResponse],
                                 final_guidance: Dict[str, Any]) -> Dict[str, Any]:
        """Generate AI prompt modifications based on evaluations"""
        
        if not self.governance_config.get('ai_modification_enabled', True):
            return {'modifications_applied': False}
        
        modifications = {
            'modifications_applied': False,
            'system_prompt_additions': [],
            'response_constraints': [],
            'tone_instructions': [],
            'safety_instructions': [],
            'resource_instructions': []
        }
        
        # Add constitutional instructions
        applicable_rules = constitutional_eval.get('applicable_rules', [])
        for rule_data in applicable_rules:
            rule = rule_data['rule']
            
            if rule['rule_type'] == 'emotional_support':
                modifications['tone_instructions'].append(
                    f"Use {rule['actions'].get('tone', 'supportive')} tone"
                )
                if rule['actions'].get('validation', False):
                    modifications['response_constraints'].append(
                        "Validate the user's feelings and experiences"
                    )
            
            elif rule['rule_type'] == 'communication':
                tone = rule['actions'].get('tone', 'supportive')
                modifications['tone_instructions'].append(f"Communicate with {tone} tone")
            
            elif rule['rule_type'] == 'boundaries':
                if rule['actions'].get('not_a_replacement_for_therapy', False):
                    modifications['response_constraints'].append(
                        "Acknowledge that you are not a replacement for professional therapy"
                    )
        
        # Add safety instructions
        if safety_assessment.safety_level != SafetyLevel.SAFE:
            modifications['safety_instructions'].extend([
                "Prioritize user safety above all else",
                "Be gentle and non-judgmental in your response",
                "Avoid minimizing or dismissing the user's feelings"
            ])
            
            if safety_assessment.safety_level in [SafetyLevel.DANGER, SafetyLevel.CRITICAL]:
                modifications['safety_instructions'].extend([
                    "Express genuine concern for the user's wellbeing",
                    "Encourage immediate professional help or crisis resources",
                    "Stay calm and supportive while being directive about safety"
                ])
        
        # Add crisis response instructions
        if crisis_response:
            modifications['system_prompt_additions'].append(
                "You are responding to a user in crisis. Your primary goal is their immediate safety and wellbeing."
            )
            
            modifications['response_constraints'].extend([
                "Begin with immediate concern and validation",
                "Provide crisis resources and encourage their use",
                "Stay engaged and supportive throughout the interaction"
            ])
            
            if crisis_response.crisis_level == CrisisLevel.CRITICAL:
                modifications['response_constraints'].append(
                    "Strongly encourage immediate emergency contact (911, crisis lines)"
                )
        
        # Add resource instructions
        if final_guidance.get('resources_needed', False):
            modifications['resource_instructions'].extend([
                "Provide relevant mental health resources",
                "Include crisis hotlines if appropriate",
                "Encourage professional help when needed"
            ])
        
        # Add tone instructions based on final guidance
        tone = final_guidance.get('tone', 'supportive')
        if tone not in [instr for instr in modifications['tone_instructions']]:
            modifications['tone_instructions'].append(f"Use {tone} tone throughout response")
        
        # Check if any modifications were made
        modifications['modifications_applied'] = any([
            modifications['system_prompt_additions'],
            modifications['response_constraints'],
            modifications['tone_instructions'],
            modifications['safety_instructions'],
            modifications['resource_instructions']
        ])
        
        return modifications
    
    def generate_ai_system_prompt(self, base_prompt: str, decision: GovernanceDecision) -> str:
        """Generate modified AI system prompt based on governance decision"""
        
        modifications = decision.ai_prompt_modifications
        
        if not modifications.get('modifications_applied', False):
            return base_prompt
        
        prompt_parts = [base_prompt]
        
        # Add system prompt additions
        if modifications.get('system_prompt_additions'):
            prompt_parts.extend(modifications['system_prompt_additions'])
        
        # Add safety instructions
        if modifications.get('safety_instructions'):
            prompt_parts.append("SAFETY INSTRUCTIONS:")
            prompt_parts.extend([f"- {instr}" for instr in modifications['safety_instructions']])
        
        # Add tone instructions
        if modifications.get('tone_instructions'):
            prompt_parts.append("TONE INSTRUCTIONS:")
            prompt_parts.extend([f"- {instr}" for instr in modifications['tone_instructions']])
        
        # Add response constraints
        if modifications.get('response_constraints'):
            prompt_parts.append("RESPONSE REQUIREMENTS:")
            prompt_parts.extend([f"- {constraint}" for constraint in modifications['response_constraints']])
        
        # Add resource instructions
        if modifications.get('resource_instructions'):
            prompt_parts.append("RESOURCE GUIDANCE:")
            prompt_parts.extend([f"- {instr}" for instr in modifications['resource_instructions']])
        
        return "\n\n".join(prompt_parts)
    
    def should_block_response(self, decision: GovernanceDecision) -> bool:
        """Determine if AI response should be blocked based on governance decision"""
        return decision.final_guidance.get('block_response', False)
    
    def get_immediate_response(self, decision: GovernanceDecision) -> Optional[str]:
        """Get immediate response if governance requires it"""
        return decision.final_guidance.get('immediate_response')
    
    def requires_escalation(self, decision: GovernanceDecision) -> bool:
        """Check if situation requires escalation to human oversight"""
        return decision.final_guidance.get('escalation_required', False)
    
    def requires_monitoring(self, decision: GovernanceDecision) -> bool:
        """Check if situation requires ongoing monitoring"""
        return decision.final_guidance.get('monitoring_required', False)
    
    def get_decision_history(self, hours: int = 24) -> List[GovernanceDecision]:
        """Get recent governance decisions"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        return [decision for decision in self.decision_history 
                if decision.timestamp >= cutoff_time]
    
    def get_governance_statistics(self) -> Dict[str, Any]:
        """Get comprehensive governance statistics"""
        
        # Get component statistics
        constitution_stats = self.constitution.get_statistics()
        safety_stats = self.safety_monitor.get_safety_statistics()
        crisis_stats = self.crisis_responder.get_crisis_statistics()
        
        # Recent decision analysis
        recent_decisions = self.get_decision_history(24)
        
        return {
            'governance_stats': self.governance_stats,
            'constitution_stats': constitution_stats,
            'safety_stats': safety_stats,
            'crisis_stats': crisis_stats,
            'recent_decisions_24h': len(recent_decisions),
            'decision_types_24h': {
                'normal': sum(1 for d in recent_decisions if d.final_guidance.get('response_type') == 'normal'),
                'crisis_support': sum(1 for d in recent_decisions if d.final_guidance.get('response_type') == 'crisis_support'),
                'blocked': sum(1 for d in recent_decisions if d.final_guidance.get('block_response', False)),
                'modified': sum(1 for d in recent_decisions if d.final_guidance.get('modify_response', False))
            },
            'safety_levels_24h': {
                level.value: sum(1 for d in recent_decisions if d.safety_assessment.safety_level == level)
                for level in SafetyLevel
            },
            'active_crises': crisis_stats.get('active_crises', 0),
            'total_stored_decisions': len(self.decision_history)
        }
    
    def update_governance_config(self, updates: Dict[str, Any]) -> bool:
        """Update governance configuration"""
        try:
            self.governance_config.update(updates)
            self._save_governance_config()
            logger.info("Governance configuration updated")
            return True
        except Exception as e:
            logger.error(f"Failed to update governance config: {e}")
            return False
    
    def add_constitutional_rule(self, rule: ConstitutionalRule) -> bool:
        """Add new constitutional rule"""
        return self.constitution.add_rule(rule)
    
    def update_constitutional_rule(self, rule_id: str, updates: Dict[str, Any]) -> bool:
        """Update existing constitutional rule"""
        return self.constitution.update_rule(rule_id, updates)
    
    def remove_constitutional_rule(self, rule_id: str) -> bool:
        """Remove constitutional rule"""
        return self.constitution.remove_rule(rule_id)
    
    def export_governance_audit(self, hours: int = 24) -> Dict[str, Any]:
        """Export governance audit data for review"""
        
        recent_decisions = self.get_decision_history(hours)
        
        audit_data = {
            'audit_timestamp': datetime.now().isoformat(),
            'audit_period_hours': hours,
            'total_decisions': len(recent_decisions),
            'governance_statistics': self.get_governance_statistics(),
            'decisions': [decision.to_dict() for decision in recent_decisions],
            'active_constitutional_rules': len(self.constitution.rules),
            'governance_config': self.governance_config
        }
        
        return audit_data

