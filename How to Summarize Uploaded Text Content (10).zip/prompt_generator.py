"""
WhisperLeaf Reflective Prompts Generator
Generates personalized prompts for emotional reflection and growth
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from enum import Enum
import random
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)

class PromptType(Enum):
    """Types of reflective prompts"""
    EMOTIONAL_CHECK_IN = "emotional_check_in"
    GRATITUDE = "gratitude"
    GROWTH_REFLECTION = "growth_reflection"
    PATTERN_EXPLORATION = "pattern_exploration"
    GOAL_SETTING = "goal_setting"
    SELF_COMPASSION = "self_compassion"
    MINDFULNESS = "mindfulness"
    RELATIONSHIP = "relationship"
    CREATIVITY = "creativity"
    HEALING = "healing"
    CRISIS_SUPPORT = "crisis_support"

class PromptCategory(Enum):
    """Categories for organizing prompts"""
    DAILY_REFLECTION = "daily_reflection"
    WEEKLY_REVIEW = "weekly_review"
    MONTHLY_DEEP_DIVE = "monthly_deep_dive"
    CRISIS_INTERVENTION = "crisis_intervention"
    GROWTH_MILESTONE = "growth_milestone"
    PATTERN_BREAKING = "pattern_breaking"
    HEALING_JOURNEY = "healing_journey"

@dataclass
class ReflectivePrompt:
    """A personalized reflective prompt"""
    prompt_id: str
    timestamp: datetime
    prompt_type: PromptType
    category: PromptCategory
    mood_context: str
    emotional_context: List[str]
    prompt_text: str
    follow_up_questions: List[str]
    suggested_activities: List[str]
    personalization_factors: Dict[str, Any]
    difficulty_level: str  # gentle, moderate, deep
    estimated_time: str
    tags: List[str]

class ReflectivePromptGenerator:
    """
    Generates personalized reflective prompts based on emotional state,
    patterns, and user preferences
    """
    
    def __init__(self):
        self.prompt_templates = self._load_prompt_templates()
        self.personalization_engine = self._initialize_personalization()
        
        # Generation statistics
        self.generation_stats = {
            'total_prompts_generated': 0,
            'prompts_by_type': {ptype.value: 0 for ptype in PromptType},
            'prompts_by_mood': {},
            'personalization_factors_used': {},
            'last_generation': None
        }
        
        logger.info("ReflectivePromptGenerator initialized with comprehensive prompt library")
    
    def _load_prompt_templates(self) -> Dict[str, Dict[str, Any]]:
        """Load comprehensive prompt templates organized by type and mood"""
        return {
            # Emotional Check-in Prompts
            PromptType.EMOTIONAL_CHECK_IN.value: {
                'blue': {  # Sadness, melancholy
                    'gentle': [
                        "How are you feeling right now, without trying to change or fix anything?",
                        "What would you say to a dear friend who was feeling exactly like you do today?",
                        "What small thing could bring you a moment of comfort right now?",
                        "If your sadness could speak, what would it want you to know?"
                    ],
                    'moderate': [
                        "What emotions are you experiencing alongside the sadness?",
                        "How has this feeling changed or evolved over the past few days?",
                        "What memories or experiences might be connected to how you're feeling?",
                        "What would it look like to honor this feeling while also caring for yourself?"
                    ],
                    'deep': [
                        "What is this sadness teaching you about what matters most to you?",
                        "How might this difficult period be preparing you for growth or change?",
                        "What patterns do you notice in how you experience and process sadness?",
                        "If you could write a letter to yourself from a place of deep compassion, what would it say?"
                    ]
                },
                'green': {  # Calm, balanced
                    'gentle': [
                        "What are you most grateful for in this moment of peace?",
                        "How does this sense of calm feel in your body?",
                        "What helped you find this balance today?",
                        "What would you like to remember about this feeling?"
                    ],
                    'moderate': [
                        "How can you nurture and maintain this sense of balance?",
                        "What insights are emerging for you in this calm space?",
                        "How might you share this peaceful energy with others?",
                        "What goals or intentions feel most aligned with this state?"
                    ],
                    'deep': [
                        "What does this inner peace reveal about your authentic self?",
                        "How has your relationship with calm and balance evolved over time?",
                        "What wisdom emerges when you're in this centered state?",
                        "How might this balance inform your approach to future challenges?"
                    ]
                },
                'yellow': {  # Anxiety, worry
                    'gentle': [
                        "What is one thing you know for certain right now?",
                        "Where in your body do you feel most grounded and safe?",
                        "What would help you feel just 10% more at ease?",
                        "What reassuring truth can you remind yourself of today?"
                    ],
                    'moderate': [
                        "What specific worries are taking up the most mental space right now?",
                        "How might you separate what you can control from what you cannot?",
                        "What coping strategies have helped you through anxiety before?",
                        "What would it feel like to approach your worries with curiosity instead of fear?"
                    ],
                    'deep': [
                        "What deeper needs or values might your anxiety be trying to protect?",
                        "How has anxiety served you in the past, and how might it be limiting you now?",
                        "What would change if you viewed your anxiety as information rather than a problem?",
                        "What would you do if you knew you could handle whatever comes your way?"
                    ]
                },
                'purple': {  # Creative, inspired
                    'gentle': [
                        "What is inspiring you most right now?",
                        "How does this creative energy feel in your body and mind?",
                        "What new possibilities are you sensing?",
                        "What would you create if there were no limitations?"
                    ],
                    'moderate': [
                        "How might you channel this creative energy into meaningful action?",
                        "What patterns or connections are you noticing that others might miss?",
                        "How can you honor and nurture this inspired state?",
                        "What would you like to explore or experiment with?"
                    ],
                    'deep': [
                        "What is your creativity trying to express about your deeper purpose?",
                        "How might this inspired state be guiding you toward growth or change?",
                        "What would it mean to trust your creative instincts completely?",
                        "How might your unique perspective contribute to something larger than yourself?"
                    ]
                },
                'red': {  # Anger, frustration
                    'gentle': [
                        "What is your anger trying to protect or defend?",
                        "What do you need most right now to feel heard and understood?",
                        "How might you honor this feeling while also caring for yourself?",
                        "What would it look like to channel this energy constructively?"
                    ],
                    'moderate': [
                        "What boundaries might need to be set or reinforced?",
                        "What values or needs feel threatened or unmet right now?",
                        "How might you express this feeling in a way that serves you?",
                        "What would change if you approached this situation with both strength and compassion?"
                    ],
                    'deep': [
                        "What is this anger revealing about what matters most deeply to you?",
                        "How might this intensity be fuel for positive change or action?",
                        "What patterns do you notice in what triggers your anger?",
                        "How might you transform this energy into a force for justice or healing?"
                    ]
                }
            },
            
            # Gratitude Prompts
            PromptType.GRATITUDE.value: {
                'universal': [
                    "What three small moments from today brought you joy or peace?",
                    "Who in your life are you most grateful for right now, and why?",
                    "What challenge you've overcome are you most proud of?",
                    "What aspect of your body or health are you thankful for today?",
                    "What place makes you feel most at home and why?",
                    "What skill or ability do you have that you sometimes take for granted?",
                    "What act of kindness (given or received) stands out to you recently?",
                    "What aspect of nature fills you with wonder or appreciation?",
                    "What memory never fails to make you smile?",
                    "What opportunity are you grateful to have right now?"
                ],
                'mood_specific': {
                    'blue': [
                        "Even in this difficult time, what small comfort or support are you grateful for?",
                        "What strength within yourself are you thankful for, even when it's hard to see?",
                        "Who has shown you kindness during challenging times?",
                        "What lesson or insight has emerged from your struggles?"
                    ],
                    'green': [
                        "What aspects of your current peace and balance are you most grateful for?",
                        "What practices or habits have contributed to your sense of well-being?",
                        "What relationships in your life bring you the most joy and stability?",
                        "What opportunities for growth are you excited about?"
                    ]
                }
            },
            
            # Growth Reflection Prompts
            PromptType.GROWTH_REFLECTION.value: {
                'personal_development': [
                    "How have you grown or changed in the past month?",
                    "What belief about yourself have you outgrown recently?",
                    "What fear have you faced that you're proud of confronting?",
                    "How has your relationship with yourself evolved this year?",
                    "What skill or quality would you like to develop further?",
                    "What pattern or habit are you ready to release?",
                    "How do you want to be different a year from now?",
                    "What aspect of your character are you most proud of developing?"
                ],
                'relationship_growth': [
                    "How have your relationships deepened or improved recently?",
                    "What have you learned about love and connection this year?",
                    "How has your ability to set boundaries evolved?",
                    "What relationship pattern are you working to change?",
                    "How have you grown in your capacity for empathy or understanding?",
                    "What does healthy communication look like for you now versus before?",
                    "How have you learned to better support others while caring for yourself?"
                ],
                'life_transitions': [
                    "What major life change are you navigating right now?",
                    "How are you adapting to new circumstances or challenges?",
                    "What aspects of change do you find most difficult or exciting?",
                    "How has your perspective on life shifted recently?",
                    "What are you learning about resilience and adaptability?",
                    "What support do you need during this transition?",
                    "How might this change be preparing you for your next chapter?"
                ]
            },
            
            # Pattern Exploration Prompts
            PromptType.PATTERN_EXPLORATION.value: {
                'emotional_patterns': [
                    "What emotional patterns do you notice repeating in your life?",
                    "What triggers tend to activate your strongest emotional responses?",
                    "How do you typically respond to stress, and how is that working for you?",
                    "What emotions do you find most difficult to sit with or express?",
                    "What patterns in your relationships keep showing up?",
                    "How do you typically handle conflict or disagreement?",
                    "What self-talk patterns do you notice, and how do they affect you?"
                ],
                'behavioral_patterns': [
                    "What habits or behaviors serve you well, and which ones don't?",
                    "How do you typically respond when things don't go as planned?",
                    "What patterns do you notice in how you make decisions?",
                    "How do you usually handle success or achievement?",
                    "What do you do when you're feeling overwhelmed or stressed?",
                    "How do you typically seek or avoid support from others?",
                    "What patterns do you see in how you spend your time and energy?"
                ]
            },
            
            # Self-Compassion Prompts
            PromptType.SELF_COMPASSION.value: {
                'gentle_self_care': [
                    "What would you say to your best friend if they were going through what you're experiencing?",
                    "How can you show yourself the same kindness you'd show someone you love?",
                    "What do you need to forgive yourself for?",
                    "What aspects of your humanity are you struggling to accept?",
                    "How might you comfort your inner child right now?",
                    "What would unconditional self-love look like in your daily life?",
                    "What harsh inner critic voice are you ready to soften?",
                    "How can you honor your efforts and progress, even if they feel small?"
                ],
                'healing_focused': [
                    "What part of yourself needs the most healing and attention right now?",
                    "How might you create more safety and gentleness in your inner world?",
                    "What would it feel like to fully accept yourself as you are today?",
                    "How can you practice patience with your healing process?",
                    "What would change if you treated yourself as someone worthy of love and care?",
                    "How might you honor your sensitivity as a strength rather than a weakness?",
                    "What would it look like to be your own most compassionate advocate?"
                ]
            },
            
            # Crisis Support Prompts
            PromptType.CRISIS_SUPPORT.value: {
                'immediate_grounding': [
                    "What are five things you can see around you right now?",
                    "What are three things you can hear in this moment?",
                    "What is one thing you can touch that feels comforting or grounding?",
                    "What is your breath doing right now? Can you take one slow, deep breath?",
                    "What is one safe place you can imagine yourself in right now?"
                ],
                'safety_and_connection': [
                    "Who is one person you could reach out to for support right now?",
                    "What is one small thing you could do to take care of yourself today?",
                    "What has helped you get through difficult times before?",
                    "What is one reason you're glad to be alive, even if it feels small?",
                    "What would you want someone you love to do if they were feeling like you do right now?"
                ],
                'hope_and_perspective': [
                    "What is one thing that might be different tomorrow?",
                    "What is one small step you could take toward feeling even slightly better?",
                    "What would your future self want you to know right now?",
                    "What is one thing you've survived before that you didn't think you could?",
                    "What would it look like to be gentle with yourself through this difficult time?"
                ]
            }
        }
    
    def _initialize_personalization(self) -> Dict[str, Any]:
        """Initialize personalization engine with user preference tracking"""
        return {
            'preferred_prompt_types': {},
            'effective_difficulty_levels': {},
            'response_patterns': {},
            'timing_preferences': {},
            'topic_interests': {},
            'avoidance_patterns': {},
            'growth_areas': {},
            'trigger_awareness': {}
        }
    
    def generate_prompt(self, context: Dict[str, Any], 
                       preferences: Optional[Dict[str, Any]] = None) -> ReflectivePrompt:
        """
        Generate a personalized reflective prompt based on context and preferences
        
        Args:
            context: Current emotional and situational context
            preferences: User preferences for prompt generation
            
        Returns:
            ReflectivePrompt tailored to the user's current state and needs
        """
        
        self.generation_stats['total_prompts_generated'] += 1
        self.generation_stats['last_generation'] = datetime.now()
        
        # Extract context information
        mood = context.get('mood', 'green')
        emotions = context.get('emotions', [])
        crisis_level = context.get('crisis_level', 'none')
        recent_patterns = context.get('recent_patterns', [])
        time_of_day = context.get('time_of_day', 'any')
        
        # Update statistics
        if mood not in self.generation_stats['prompts_by_mood']:
            self.generation_stats['prompts_by_mood'][mood] = 0
        self.generation_stats['prompts_by_mood'][mood] += 1
        
        # Determine prompt type and category based on context
        prompt_type, category = self._select_prompt_type_and_category(
            mood, emotions, crisis_level, recent_patterns, preferences
        )
        
        # Update type statistics
        self.generation_stats['prompts_by_type'][prompt_type.value] += 1
        
        # Determine difficulty level
        difficulty_level = self._determine_difficulty_level(
            mood, emotions, crisis_level, preferences
        )
        
        # Generate the actual prompt
        prompt_text, follow_up_questions = self._generate_prompt_content(
            prompt_type, mood, difficulty_level, context, preferences
        )
        
        # Generate suggested activities
        suggested_activities = self._generate_suggested_activities(
            prompt_type, mood, emotions, difficulty_level
        )
        
        # Create personalization factors record
        personalization_factors = self._create_personalization_record(
            context, preferences, prompt_type, difficulty_level
        )
        
        # Generate tags for organization
        tags = self._generate_tags(prompt_type, mood, emotions, difficulty_level)
        
        # Estimate time requirement
        estimated_time = self._estimate_time_requirement(prompt_type, difficulty_level)
        
        # Create the prompt
        prompt = ReflectivePrompt(
            prompt_id=f"prompt_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
            timestamp=datetime.now(),
            prompt_type=prompt_type,
            category=category,
            mood_context=mood,
            emotional_context=emotions,
            prompt_text=prompt_text,
            follow_up_questions=follow_up_questions,
            suggested_activities=suggested_activities,
            personalization_factors=personalization_factors,
            difficulty_level=difficulty_level,
            estimated_time=estimated_time,
            tags=tags
        )
        
        logger.info(f"Generated {prompt_type.value} prompt for {mood} mood, {difficulty_level} difficulty")
        
        return prompt
    
    def _select_prompt_type_and_category(self, mood: str, emotions: List[str], 
                                       crisis_level: str, recent_patterns: List[str],
                                       preferences: Optional[Dict[str, Any]]) -> Tuple[PromptType, PromptCategory]:
        """Select appropriate prompt type and category based on context"""
        
        # Crisis situations get priority
        if crisis_level in ['high', 'critical']:
            return PromptType.CRISIS_SUPPORT, PromptCategory.CRISIS_INTERVENTION
        
        # Check for specific emotional needs
        if 'hopelessness' in emotions or 'despair' in emotions:
            return PromptType.SELF_COMPASSION, PromptCategory.HEALING_JOURNEY
        
        if 'anxiety' in emotions or 'worry' in emotions:
            return PromptType.MINDFULNESS, PromptCategory.DAILY_REFLECTION
        
        if 'anger' in emotions or 'frustration' in emotions:
            return PromptType.PATTERN_EXPLORATION, PromptCategory.PATTERN_BREAKING
        
        # Check for growth opportunities
        if recent_patterns and any('growth' in pattern for pattern in recent_patterns):
            return PromptType.GROWTH_REFLECTION, PromptCategory.GROWTH_MILESTONE
        
        # Mood-based selection
        if mood == 'blue':
            return PromptType.SELF_COMPASSION, PromptCategory.HEALING_JOURNEY
        elif mood == 'green':
            return PromptType.GRATITUDE, PromptCategory.DAILY_REFLECTION
        elif mood == 'yellow':
            return PromptType.MINDFULNESS, PromptCategory.DAILY_REFLECTION
        elif mood == 'purple':
            return PromptType.CREATIVITY, PromptCategory.DAILY_REFLECTION
        elif mood == 'red':
            return PromptType.PATTERN_EXPLORATION, PromptCategory.PATTERN_BREAKING
        
        # Default to emotional check-in
        return PromptType.EMOTIONAL_CHECK_IN, PromptCategory.DAILY_REFLECTION
    
    def _determine_difficulty_level(self, mood: str, emotions: List[str], 
                                  crisis_level: str, preferences: Optional[Dict[str, Any]]) -> str:
        """Determine appropriate difficulty level for the prompt"""
        
        # Crisis situations need gentle approach
        if crisis_level in ['moderate', 'high', 'critical']:
            return 'gentle'
        
        # Very difficult emotions need gentle approach
        difficult_emotions = ['despair', 'hopelessness', 'rage', 'panic']
        if any(emotion in difficult_emotions for emotion in emotions):
            return 'gentle'
        
        # Blue mood often needs gentleness
        if mood == 'blue':
            return 'gentle'
        
        # Check user preferences
        if preferences and preferences.get('preferred_difficulty'):
            return preferences['preferred_difficulty']
        
        # Green and purple moods can handle deeper reflection
        if mood in ['green', 'purple']:
            return 'moderate'
        
        # Default to gentle
        return 'gentle'
    
    def _generate_prompt_content(self, prompt_type: PromptType, mood: str, 
                               difficulty_level: str, context: Dict[str, Any],
                               preferences: Optional[Dict[str, Any]]) -> Tuple[str, List[str]]:
        """Generate the actual prompt text and follow-up questions"""
        
        templates = self.prompt_templates.get(prompt_type.value, {})
        
        # Get mood-specific templates if available
        if mood in templates:
            mood_templates = templates[mood]
            if difficulty_level in mood_templates:
                prompt_options = mood_templates[difficulty_level]
            else:
                # Fallback to any available difficulty level
                prompt_options = list(mood_templates.values())[0]
        elif 'universal' in templates:
            prompt_options = templates['universal']
        elif 'mood_specific' in templates and mood in templates['mood_specific']:
            prompt_options = templates['mood_specific'][mood]
        else:
            # Fallback to emotional check-in
            fallback_templates = self.prompt_templates[PromptType.EMOTIONAL_CHECK_IN.value]
            if mood in fallback_templates:
                prompt_options = fallback_templates[mood][difficulty_level]
            else:
                prompt_options = ["How are you feeling right now?"]
        
        # Select a prompt
        if isinstance(prompt_options, list):
            prompt_text = random.choice(prompt_options)
        else:
            prompt_text = str(prompt_options)
        
        # Generate follow-up questions
        follow_up_questions = self._generate_follow_up_questions(
            prompt_type, mood, difficulty_level, context
        )
        
        return prompt_text, follow_up_questions
    
    def _generate_follow_up_questions(self, prompt_type: PromptType, mood: str,
                                    difficulty_level: str, context: Dict[str, Any]) -> List[str]:
        """Generate contextual follow-up questions"""
        
        base_questions = {
            PromptType.EMOTIONAL_CHECK_IN: [
                "What emotions are you noticing right now?",
                "How do these feelings show up in your body?",
                "What do you need most in this moment?"
            ],
            PromptType.GRATITUDE: [
                "What made this meaningful to you?",
                "How does focusing on gratitude change how you feel?",
                "What other positive aspects of your life come to mind?"
            ],
            PromptType.GROWTH_REFLECTION: [
                "What contributed to this growth or change?",
                "How do you want to build on this progress?",
                "What challenges did you overcome along the way?"
            ],
            PromptType.SELF_COMPASSION: [
                "What would self-compassion look like in this situation?",
                "How can you be gentler with yourself?",
                "What would you tell a friend in your situation?"
            ],
            PromptType.CRISIS_SUPPORT: [
                "What is one small step you can take right now?",
                "Who could you reach out to for support?",
                "What has helped you through difficult times before?"
            ]
        }
        
        questions = base_questions.get(prompt_type, [
            "What insights are emerging for you?",
            "How does this reflection feel?",
            "What would you like to explore further?"
        ])
        
        # Select 2-3 questions randomly
        return random.sample(questions, min(len(questions), 3))
    
    def _generate_suggested_activities(self, prompt_type: PromptType, mood: str,
                                     emotions: List[str], difficulty_level: str) -> List[str]:
        """Generate suggested activities to complement the prompt"""
        
        activity_suggestions = {
            'gentle': [
                "Take three deep breaths",
                "Write freely for 5 minutes",
                "Go for a gentle walk",
                "Listen to calming music",
                "Practice a brief body scan",
                "Drink a warm beverage mindfully",
                "Look at photos that bring you joy"
            ],
            'moderate': [
                "Journal about your reflections",
                "Create a mind map of your thoughts",
                "Practice meditation for 10 minutes",
                "Call a trusted friend or family member",
                "Engage in creative expression",
                "Spend time in nature",
                "Practice gratitude journaling"
            ],
            'deep': [
                "Write a letter to yourself",
                "Create art expressing your feelings",
                "Practice extended meditation",
                "Have a meaningful conversation",
                "Engage in volunteer work",
                "Plan steps toward a goal",
                "Reflect on your values and priorities"
            ]
        }
        
        # Mood-specific additions
        mood_activities = {
            'blue': ["Practice self-compassion meditation", "Reach out to a supportive person", "Engage in gentle movement"],
            'green': ["Practice gratitude", "Plan something you're excited about", "Share your positive energy with others"],
            'yellow': ["Practice grounding techniques", "Do breathing exercises", "Organize your space"],
            'purple': ["Engage in creative activities", "Brainstorm new ideas", "Explore something new"],
            'red': ["Practice physical exercise", "Write about your feelings", "Practice boundary setting"]
        }
        
        activities = activity_suggestions.get(difficulty_level, activity_suggestions['gentle']).copy()
        activities.extend(mood_activities.get(mood, []))
        
        # Return 3-5 random suggestions
        return random.sample(activities, min(len(activities), 5))
    
    def _create_personalization_record(self, context: Dict[str, Any], 
                                     preferences: Optional[Dict[str, Any]],
                                     prompt_type: PromptType, difficulty_level: str) -> Dict[str, Any]:
        """Create record of personalization factors used"""
        
        factors = {
            'mood_considered': context.get('mood'),
            'emotions_considered': context.get('emotions', []),
            'crisis_level_considered': context.get('crisis_level'),
            'time_context': context.get('time_of_day'),
            'prompt_type_selected': prompt_type.value,
            'difficulty_level_selected': difficulty_level,
            'preferences_applied': preferences or {},
            'generation_timestamp': datetime.now().isoformat()
        }
        
        return factors
    
    def _generate_tags(self, prompt_type: PromptType, mood: str, 
                      emotions: List[str], difficulty_level: str) -> List[str]:
        """Generate tags for organizing and searching prompts"""
        
        tags = [
            prompt_type.value,
            f"mood_{mood}",
            f"difficulty_{difficulty_level}"
        ]
        
        # Add emotion tags
        for emotion in emotions:
            tags.append(f"emotion_{emotion}")
        
        # Add contextual tags
        if prompt_type == PromptType.CRISIS_SUPPORT:
            tags.extend(['crisis', 'support', 'safety'])
        elif prompt_type == PromptType.SELF_COMPASSION:
            tags.extend(['healing', 'kindness', 'self_care'])
        elif prompt_type == PromptType.GROWTH_REFLECTION:
            tags.extend(['growth', 'development', 'progress'])
        elif prompt_type == PromptType.GRATITUDE:
            tags.extend(['positive', 'appreciation', 'mindfulness'])
        
        return tags
    
    def _estimate_time_requirement(self, prompt_type: PromptType, difficulty_level: str) -> str:
        """Estimate time needed for reflection"""
        
        time_estimates = {
            'gentle': {
                PromptType.EMOTIONAL_CHECK_IN: "5-10 minutes",
                PromptType.GRATITUDE: "5-10 minutes",
                PromptType.MINDFULNESS: "5-15 minutes",
                PromptType.CRISIS_SUPPORT: "5-10 minutes",
                PromptType.SELF_COMPASSION: "10-15 minutes"
            },
            'moderate': {
                PromptType.EMOTIONAL_CHECK_IN: "10-20 minutes",
                PromptType.GROWTH_REFLECTION: "15-25 minutes",
                PromptType.PATTERN_EXPLORATION: "15-30 minutes",
                PromptType.GRATITUDE: "10-15 minutes",
                PromptType.RELATIONSHIP: "15-25 minutes"
            },
            'deep': {
                PromptType.GROWTH_REFLECTION: "20-45 minutes",
                PromptType.PATTERN_EXPLORATION: "25-45 minutes",
                PromptType.HEALING: "20-40 minutes",
                PromptType.GOAL_SETTING: "25-45 minutes",
                PromptType.CREATIVITY: "20-60 minutes"
            }
        }
        
        return time_estimates.get(difficulty_level, {}).get(prompt_type, "10-20 minutes")
    
    def generate_daily_prompt(self, context: Dict[str, Any]) -> ReflectivePrompt:
        """Generate a daily reflection prompt"""
        context['category'] = 'daily_reflection'
        return self.generate_prompt(context)
    
    def generate_crisis_prompt(self, context: Dict[str, Any]) -> ReflectivePrompt:
        """Generate a crisis support prompt"""
        context['crisis_level'] = 'high'
        context['category'] = 'crisis_intervention'
        return self.generate_prompt(context)
    
    def generate_growth_prompt(self, context: Dict[str, Any]) -> ReflectivePrompt:
        """Generate a growth-focused prompt"""
        context['category'] = 'growth_milestone'
        preferences = {'preferred_prompt_type': PromptType.GROWTH_REFLECTION.value}
        return self.generate_prompt(context, preferences)
    
    def get_generation_statistics(self) -> Dict[str, Any]:
        """Get prompt generation statistics"""
        return {
            'generation_stats': self.generation_stats,
            'total_prompt_types': len(PromptType),
            'total_categories': len(PromptCategory),
            'personalization_factors': len(self.personalization_engine),
            'template_coverage': {
                ptype.value: len(self.prompt_templates.get(ptype.value, {}))
                for ptype in PromptType
            }
        }
    
    def update_personalization(self, prompt_id: str, feedback: Dict[str, Any]):
        """Update personalization based on user feedback"""
        
        # Track effective prompts
        if feedback.get('helpful', False):
            prompt_type = feedback.get('prompt_type')
            if prompt_type:
                if prompt_type not in self.personalization_engine['preferred_prompt_types']:
                    self.personalization_engine['preferred_prompt_types'][prompt_type] = 0
                self.personalization_engine['preferred_prompt_types'][prompt_type] += 1
        
        # Track difficulty preferences
        difficulty = feedback.get('difficulty_level')
        rating = feedback.get('difficulty_rating')  # too_easy, just_right, too_hard
        if difficulty and rating:
            if difficulty not in self.personalization_engine['effective_difficulty_levels']:
                self.personalization_engine['effective_difficulty_levels'][difficulty] = []
            self.personalization_engine['effective_difficulty_levels'][difficulty].append(rating)
        
        logger.info(f"Updated personalization based on feedback for prompt {prompt_id}")
    
    def get_personalized_recommendations(self, context: Dict[str, Any]) -> List[str]:
        """Get personalized prompt recommendations based on learning"""
        
        recommendations = []
        
        # Recommend based on successful prompt types
        preferred_types = self.personalization_engine.get('preferred_prompt_types', {})
        if preferred_types:
            top_type = max(preferred_types.items(), key=lambda x: x[1])[0]
            recommendations.append(f"Based on your preferences, a {top_type} prompt might be helpful")
        
        # Recommend based on mood patterns
        mood = context.get('mood')
        if mood in self.generation_stats['prompts_by_mood']:
            recommendations.append(f"You've found {mood} mood prompts helpful before")
        
        # Recommend based on time patterns
        # (This would be enhanced with actual usage data)
        
        return recommendations[:3]  # Return top 3 recommendations

