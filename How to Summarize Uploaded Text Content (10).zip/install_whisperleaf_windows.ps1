# WhisperLeaf Installation Script for Windows 11
# Automated installation for Dell Inspiron 16 and other Windows systems

param(
    [string]$InstallPath = "$env:USERPROFILE\WhisperLeaf",
    [switch]$SkipPython = $false,
    [switch]$Verbose = $false
)

Write-Host "🌿 WhisperLeaf Installation Script for Windows 11" -ForegroundColor Green
Write-Host "=================================================" -ForegroundColor Green
Write-Host ""

# Function to check if running as administrator
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Function to install Python if needed
function Install-Python {
    Write-Host "🐍 Checking Python installation..." -ForegroundColor Yellow
    
    try {
        $pythonVersion = python --version 2>&1
        if ($pythonVersion -match "Python 3\.1[1-9]") {
            Write-Host "✅ Python $pythonVersion found - compatible!" -ForegroundColor Green
            return $true
        }
        elseif ($pythonVersion -match "Python") {
            Write-Host "⚠️  Python found but version is too old: $pythonVersion" -ForegroundColor Yellow
            Write-Host "   WhisperLeaf requires Python 3.11 or higher" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "❌ Python not found in PATH" -ForegroundColor Red
    }
    
    Write-Host "📥 Downloading Python 3.11..." -ForegroundColor Yellow
    $pythonUrl = "https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe"
    $pythonInstaller = "$env:TEMP\python-3.11.8-amd64.exe"
    
    try {
        Invoke-WebRequest -Uri $pythonUrl -OutFile $pythonInstaller -UseBasicParsing
        Write-Host "✅ Python installer downloaded" -ForegroundColor Green
        
        Write-Host "🔧 Installing Python 3.11..." -ForegroundColor Yellow
        Start-Process -FilePath $pythonInstaller -ArgumentList "/quiet", "InstallAllUsers=0", "PrependPath=1", "Include_test=0" -Wait
        
        # Refresh PATH
        $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
        
        Write-Host "✅ Python 3.11 installed successfully!" -ForegroundColor Green
        Remove-Item $pythonInstaller -Force
        return $true
    }
    catch {
        Write-Host "❌ Failed to install Python: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# Function to install Node.js if needed
function Install-NodeJS {
    Write-Host "📦 Checking Node.js installation..." -ForegroundColor Yellow
    
    try {
        $nodeVersion = node --version 2>&1
        if ($nodeVersion -match "v1[6-9]\." -or $nodeVersion -match "v[2-9][0-9]\.") {
            Write-Host "✅ Node.js $nodeVersion found - compatible!" -ForegroundColor Green
            return $true
        }
        elseif ($nodeVersion -match "v") {
            Write-Host "⚠️  Node.js found but version is too old: $nodeVersion" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "❌ Node.js not found in PATH" -ForegroundColor Red
    }
    
    Write-Host "📥 Downloading Node.js LTS..." -ForegroundColor Yellow
    $nodeUrl = "https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi"
    $nodeInstaller = "$env:TEMP\node-v20.11.0-x64.msi"
    
    try {
        Invoke-WebRequest -Uri $nodeUrl -OutFile $nodeInstaller -UseBasicParsing
        Write-Host "✅ Node.js installer downloaded" -ForegroundColor Green
        
        Write-Host "🔧 Installing Node.js..." -ForegroundColor Yellow
        Start-Process -FilePath "msiexec.exe" -ArgumentList "/i", $nodeInstaller, "/quiet", "/norestart" -Wait
        
        # Refresh PATH
        $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
        
        Write-Host "✅ Node.js installed successfully!" -ForegroundColor Green
        Remove-Item $nodeInstaller -Force
        return $true
    }
    catch {
        Write-Host "❌ Failed to install Node.js: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# Function to create virtual environment and install dependencies
function Setup-WhisperLeaf {
    param([string]$Path)
    
    Write-Host "🏗️  Setting up WhisperLeaf at: $Path" -ForegroundColor Yellow
    
    # Create installation directory
    if (!(Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
        Write-Host "✅ Created installation directory" -ForegroundColor Green
    }
    
    Set-Location $Path
    
    # Create Python virtual environment
    Write-Host "🐍 Creating Python virtual environment..." -ForegroundColor Yellow
    python -m venv whisperleaf_env
    
    if (!(Test-Path "whisperleaf_env\Scripts\activate.ps1")) {
        Write-Host "❌ Failed to create virtual environment" -ForegroundColor Red
        return $false
    }
    
    # Activate virtual environment
    Write-Host "🔌 Activating virtual environment..." -ForegroundColor Yellow
    & ".\whisperleaf_env\Scripts\Activate.ps1"
    
    # Upgrade pip
    Write-Host "📦 Upgrading pip..." -ForegroundColor Yellow
    python -m pip install --upgrade pip
    
    # Install Python dependencies
    Write-Host "📦 Installing Python dependencies..." -ForegroundColor Yellow
    if (Test-Path "requirements.txt") {
        pip install -r requirements.txt
    } else {
        # Install core dependencies
        pip install fastapi uvicorn sqlalchemy cryptography python-multipart jinja2 aiofiles
        pip install pandas numpy matplotlib seaborn plotly
        pip install beautifulsoup4 requests python-dateutil
        pip install pytest pytest-asyncio
    }
    
    # Install Node.js dependencies
    if (Test-Path "ui\whisperleaf-ui\package.json") {
        Write-Host "📦 Installing Node.js dependencies..." -ForegroundColor Yellow
        Set-Location "ui\whisperleaf-ui"
        npm install
        Set-Location "..\..\"
    }
    
    # Initialize database
    Write-Host "🗄️  Initializing database..." -ForegroundColor Yellow
    if (Test-Path "scripts\initialize.py") {
        python scripts\initialize.py
    }
    
    Write-Host "✅ WhisperLeaf setup completed!" -ForegroundColor Green
    return $true
}

# Function to create desktop shortcuts
function Create-Shortcuts {
    param([string]$InstallPath)
    
    Write-Host "🔗 Creating desktop shortcuts..." -ForegroundColor Yellow
    
    $WshShell = New-Object -comObject WScript.Shell
    
    # Create start script shortcut
    $StartShortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\Start WhisperLeaf.lnk")
    $StartShortcut.TargetPath = "powershell.exe"
    $StartShortcut.Arguments = "-ExecutionPolicy Bypass -File `"$InstallPath\start_whisperleaf.ps1`""
    $StartShortcut.WorkingDirectory = $InstallPath
    $StartShortcut.IconLocation = "shell32.dll,21"
    $StartShortcut.Description = "Start WhisperLeaf Emotional AI"
    $StartShortcut.Save()
    
    Write-Host "✅ Desktop shortcuts created!" -ForegroundColor Green
}

# Function to create startup scripts
function Create-StartupScripts {
    param([string]$InstallPath)
    
    Write-Host "📝 Creating startup scripts..." -ForegroundColor Yellow
    
    # Create PowerShell startup script
    $startScript = @"
# WhisperLeaf Startup Script
Write-Host "🌿 Starting WhisperLeaf..." -ForegroundColor Green

Set-Location "$InstallPath"

# Activate virtual environment
& ".\whisperleaf_env\Scripts\Activate.ps1"

# Start API server in background
Write-Host "🚀 Starting API server..." -ForegroundColor Yellow
Start-Process -FilePath "python" -ArgumentList "api\main.py" -WindowStyle Hidden

# Wait for API server to start
Start-Sleep -Seconds 5

# Start web interface
Write-Host "🌐 Starting web interface..." -ForegroundColor Yellow
Set-Location "ui\whisperleaf-ui"
Start-Process -FilePath "npm" -ArgumentList "run", "dev" -WindowStyle Hidden

# Wait for web interface to start
Start-Sleep -Seconds 10

# Open browser
Write-Host "🌿 Opening WhisperLeaf in browser..." -ForegroundColor Green
Start-Process "http://localhost:5173"

Write-Host "✅ WhisperLeaf is now running!" -ForegroundColor Green
Write-Host "   Access at: http://localhost:5173" -ForegroundColor Cyan
Write-Host "   Press Ctrl+C to stop" -ForegroundColor Yellow

# Keep script running
try {
    while (`$true) {
        Start-Sleep -Seconds 30
    }
} catch {
    Write-Host "🛑 Stopping WhisperLeaf..." -ForegroundColor Yellow
}
"@
    
    $startScript | Out-File -FilePath "$InstallPath\start_whisperleaf.ps1" -Encoding UTF8
    
    # Create batch file for easy access
    $batchScript = @"
@echo off
cd /d "$InstallPath"
powershell.exe -ExecutionPolicy Bypass -File "start_whisperleaf.ps1"
pause
"@
    
    $batchScript | Out-File -FilePath "$InstallPath\start_whisperleaf.bat" -Encoding ASCII
    
    Write-Host "✅ Startup scripts created!" -ForegroundColor Green
}

# Main installation process
try {
    Write-Host "🔍 System Requirements Check" -ForegroundColor Cyan
    Write-Host "=============================" -ForegroundColor Cyan
    
    # Check Windows version
    $osVersion = [System.Environment]::OSVersion.Version
    if ($osVersion.Major -lt 10) {
        Write-Host "❌ Windows 10 or higher required" -ForegroundColor Red
        exit 1
    }
    Write-Host "✅ Windows version compatible" -ForegroundColor Green
    
    # Check available disk space (minimum 5GB)
    $freeSpace = (Get-WmiObject -Class Win32_LogicalDisk -Filter "DeviceID='C:'").FreeSpace / 1GB
    if ($freeSpace -lt 5) {
        Write-Host "⚠️  Low disk space: $([math]::Round($freeSpace, 1))GB free. Minimum 5GB recommended." -ForegroundColor Yellow
    } else {
        Write-Host "✅ Sufficient disk space: $([math]::Round($freeSpace, 1))GB free" -ForegroundColor Green
    }
    
    # Check RAM
    $totalRAM = (Get-WmiObject -Class Win32_ComputerSystem).TotalPhysicalMemory / 1GB
    if ($totalRAM -lt 4) {
        Write-Host "⚠️  Low RAM: $([math]::Round($totalRAM, 1))GB. Minimum 4GB recommended." -ForegroundColor Yellow
    } else {
        Write-Host "✅ Sufficient RAM: $([math]::Round($totalRAM, 1))GB" -ForegroundColor Green
    }
    
    Write-Host ""
    Write-Host "🚀 Beginning Installation" -ForegroundColor Cyan
    Write-Host "=========================" -ForegroundColor Cyan
    
    # Install Python if needed
    if (!$SkipPython) {
        if (!(Install-Python)) {
            Write-Host "❌ Python installation failed. Please install Python 3.11+ manually." -ForegroundColor Red
            exit 1
        }
    }
    
    # Install Node.js if needed
    if (!(Install-NodeJS)) {
        Write-Host "❌ Node.js installation failed. Please install Node.js manually." -ForegroundColor Red
        exit 1
    }
    
    # Setup WhisperLeaf
    if (!(Setup-WhisperLeaf -Path $InstallPath)) {
        Write-Host "❌ WhisperLeaf setup failed." -ForegroundColor Red
        exit 1
    }
    
    # Create shortcuts and startup scripts
    Create-Shortcuts -InstallPath $InstallPath
    Create-StartupScripts -InstallPath $InstallPath
    
    Write-Host ""
    Write-Host "🎉 Installation Complete!" -ForegroundColor Green
    Write-Host "=========================" -ForegroundColor Green
    Write-Host ""
    Write-Host "WhisperLeaf has been successfully installed to:" -ForegroundColor Cyan
    Write-Host "  $InstallPath" -ForegroundColor White
    Write-Host ""
    Write-Host "To start WhisperLeaf:" -ForegroundColor Cyan
    Write-Host "  • Double-click 'Start WhisperLeaf' on your desktop" -ForegroundColor White
    Write-Host "  • Or run: $InstallPath\start_whisperleaf.bat" -ForegroundColor White
    Write-Host ""
    Write-Host "WhisperLeaf will open in your browser at:" -ForegroundColor Cyan
    Write-Host "  http://localhost:5173" -ForegroundColor White
    Write-Host ""
    Write-Host "🌿 Welcome to your sovereign emotional AI companion!" -ForegroundColor Green
    
} catch {
    Write-Host "❌ Installation failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Please check the error and try again, or install manually using the documentation." -ForegroundColor Yellow
    exit 1
}

