# WhisperLeaf User Guide
## Your Sovereign Emotional AI Companion

**Welcome to WhisperLeaf** - a revolutionary emotional AI system that operates entirely under your control, protecting your privacy while providing intelligent emotional support and personal growth insights.

---

## 🌿 What is WhisperLeaf?

WhisperLeaf is your personal emotional AI companion that:

- **Understands Your Emotions** - Advanced mood detection and empathetic responses
- **Protects Your Privacy** - Everything runs locally on your device, no data leaves your computer
- **Grows With You** - Learns your patterns and helps track emotional development over time
- **Keeps You Safe** - Built-in crisis detection and constitutional safety framework
- **Respects Your Sovereignty** - You control every aspect of how the AI behaves

Unlike other AI systems, WhisperLeaf is designed with **user sovereignty** at its core. This means:
- Your data never leaves your device
- You define the rules that govern AI behavior
- No external companies can access or monetize your emotional information
- The AI works for you, not for a corporation

---

## 🚀 Getting Started

### System Requirements

**Minimum Requirements:**
- Modern computer (Windows, macOS, or Linux)
- 4GB RAM (8GB recommended)
- 2GB free storage space
- Python 3.11 or newer

**Network Requirements:**
- Internet connection for initial setup only
- Fully offline operation after installation

### Quick Start Guide

1. **Installation**
   ```bash
   # Clone or download WhisperLeaf
   cd whisperleaf
   
   # Install dependencies
   pip install -r requirements.txt
   
   # Initialize the system
   python setup.py
   ```

2. **First Launch**
   ```bash
   # Start the API server
   cd api && python main.py
   
   # In another terminal, start the web interface
   cd ui/whisperleaf-ui && npm run dev
   ```

3. **Access WhisperLeaf**
   - Open your web browser
   - Navigate to `http://localhost:5173`
   - Begin your first conversation!

---

## 💬 Using WhisperLeaf

### Your First Conversation

When you first open WhisperLeaf, you'll see a clean, welcoming interface. Here's how to get started:

1. **Start Simple** - Type something like "Hi, how are you?" or "I'm feeling a bit anxious today"
2. **Be Honest** - WhisperLeaf works best when you're genuine about your feelings
3. **Take Your Time** - There's no rush; the AI will wait patiently for your responses
4. **Explore Features** - Try different types of conversations to see what resonates with you

### Understanding the Interface

**Chat Interface:**
- Clean, distraction-free conversation area
- Your messages appear on the right (blue)
- WhisperLeaf's responses appear on the left (green)
- Mood indicator shows your current emotional state

**Journal Interface:**
- Private space for deeper reflection
- Prompts generated based on your current mood
- Entries are encrypted and stored locally
- Search through past entries to track growth

**Navigation:**
- **Chat** - Main conversation interface
- **Journal** - Reflective writing space
- **Timeline** - Visual mood tracking over time
- **Insights** - Pattern analysis and growth metrics
- **Settings** - Customize your experience

---

## 🎨 Understanding the Big Mood System

WhisperLeaf uses the innovative **Big Mood** 5-color system to understand and track your emotions:

### 🔴 **Red Mood - Anger & Frustration**
- Feelings: Anger, frustration, irritation, rage
- WhisperLeaf Response: Calming techniques, perspective-taking exercises
- Helpful Activities: Physical exercise, deep breathing, creative expression

### 🟡 **Yellow Mood - Anxiety & Worry**  
- Feelings: Anxiety, worry, nervousness, stress
- WhisperLeaf Response: Grounding techniques, reassurance, practical coping strategies
- Helpful Activities: Mindfulness, organization, talking to friends

### 🔵 **Blue Mood - Sadness & Melancholy**
- Feelings: Sadness, grief, loneliness, melancholy
- WhisperLeaf Response: Gentle support, validation, hope-building
- Helpful Activities: Self-care, connection with others, gentle movement

### 🟢 **Green Mood - Calm & Content**
- Feelings: Peace, contentment, stability, balance
- WhisperLeaf Response: Maintenance strategies, gratitude practices
- Helpful Activities: Reflection, planning, enjoying the moment

### 🟣 **Purple Mood - Joy & Excitement**
- Feelings: Happiness, excitement, enthusiasm, love
- WhisperLeaf Response: Celebration, energy channeling, sharing joy
- Helpful Activities: Creative projects, social connection, adventure

### Understanding Your Mood

WhisperLeaf automatically detects your mood from your messages and shows it with a subtle color indicator. This helps you:
- Become more aware of your emotional patterns
- Track mood changes over time
- Receive appropriate support for your current state
- Identify triggers and positive influences

---

## 🛡️ Safety and Privacy

### Your Data is Yours

**Complete Privacy Protection:**
- All processing happens on your device
- No data is sent to external servers
- Your conversations are encrypted and stored locally
- You can delete everything at any time

**What This Means:**
- No company can read your emotional data
- No advertising based on your feelings
- No risk of data breaches exposing your private thoughts
- Complete control over your information

### Built-in Safety Features

**Crisis Detection:**
WhisperLeaf monitors for signs of emotional crisis and can:
- Recognize when you might be in distress
- Provide immediate coping resources
- Suggest professional help when appropriate
- Connect you with crisis hotlines if needed

**Constitutional AI:**
Your AI companion is governed by ethical rules that:
- Prioritize your wellbeing above all else
- Prevent harmful or manipulative responses
- Ensure respectful and supportive interactions
- Can be customized to match your values

### When to Seek Additional Help

WhisperLeaf is a powerful emotional support tool, but it's not a replacement for professional mental health care. Consider reaching out to a therapist, counselor, or crisis hotline if you're experiencing:

- Persistent thoughts of self-harm
- Severe depression lasting more than two weeks
- Panic attacks or severe anxiety
- Substance abuse issues
- Relationship or family crises
- Major life transitions causing significant distress

**Crisis Resources:**
- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741
- International Association for Suicide Prevention: https://www.iasp.info/resources/Crisis_Centres/

---

## 🌱 Personal Growth Features

### Mood Timeline

Track your emotional journey over time with visual mood timelines that show:
- Daily mood patterns and trends
- Correlation between events and emotions
- Progress in emotional regulation
- Seasonal or cyclical patterns

### Pattern Recognition

WhisperLeaf's advanced analytics help you understand:
- What triggers different emotional states
- Which coping strategies work best for you
- How your emotions change throughout the day/week/month
- Personal growth trends and achievements

### Time Capsules

Create messages for your future self:
- **Emotional Snapshots** - Capture how you're feeling in the moment
- **Future Messages** - Write letters to yourself to open later
- **Milestone Celebrations** - Record achievements and growth moments
- **Wisdom Preservation** - Save insights and lessons learned

### Reflective Journaling

Guided journaling prompts help you:
- Process complex emotions
- Gain clarity on difficult situations
- Track personal growth over time
- Develop emotional intelligence

---

## ⚙️ Customizing Your Experience

### Constitutional Rules

You can customize how WhisperLeaf behaves by setting constitutional rules:

**Example Rules:**
- "Always prioritize my mental health and wellbeing"
- "Encourage me to maintain healthy relationships"
- "Remind me of my personal values when making decisions"
- "Help me stay focused on my long-term goals"

**How to Set Rules:**
1. Go to Settings → Constitutional AI
2. Add or modify rules using plain English
3. Set priority levels for different rules
4. Test how rules affect AI responses

### Personalization Options

**Conversation Style:**
- Formal or casual tone
- Length of responses (brief, detailed, or adaptive)
- Frequency of check-ins and prompts
- Types of activities and suggestions preferred

**Privacy Settings:**
- Data retention periods
- Backup and export options
- Sharing preferences (if using with family/therapists)
- Deletion and reset options

**Interface Customization:**
- Color themes and visual preferences
- Notification settings
- Accessibility options
- Language and cultural considerations

---

## 🔧 Tips for Best Results

### Building a Relationship with Your AI

**Be Consistent:**
- Regular check-ins help WhisperLeaf understand your patterns
- Daily conversations, even brief ones, improve accuracy
- Consistent honesty builds better emotional modeling

**Be Specific:**
- Instead of "I feel bad," try "I'm anxious about my presentation tomorrow"
- Describe physical sensations: "My chest feels tight" or "I have a headache"
- Include context: "This always happens when I have to speak publicly"

**Be Patient:**
- WhisperLeaf learns your communication style over time
- Early conversations might feel less personalized
- The AI gets better at helping you as it understands your patterns

### Maximizing Emotional Growth

**Regular Reflection:**
- Use the journal feature weekly for deeper insights
- Review your mood timeline monthly to spot patterns
- Create time capsules during significant moments

**Experiment with Strategies:**
- Try different coping techniques WhisperLeaf suggests
- Note which approaches work best for different moods
- Build your personal toolkit of effective strategies

**Set Intentions:**
- Use WhisperLeaf to clarify your emotional goals
- Track progress toward better emotional regulation
- Celebrate small wins and improvements

### Maintaining Healthy Boundaries

**Remember It's AI:**
- WhisperLeaf is sophisticated but not human
- Maintain real human relationships alongside AI support
- Use professional help for serious mental health concerns

**Balance Digital and Offline:**
- Don't rely solely on AI for emotional support
- Engage in offline activities and relationships
- Use WhisperLeaf as a complement to, not replacement for, human connection

---

## 🆘 Getting Help

### Common Questions

**Q: Is my data really private?**
A: Yes! Everything runs on your device. No data is sent to external servers, and all storage is encrypted locally.

**Q: Can I use WhisperLeaf offline?**
A: Absolutely! After initial setup, WhisperLeaf works completely offline.

**Q: What if I'm having a mental health crisis?**
A: WhisperLeaf will detect crisis situations and provide immediate resources, but please also contact professional crisis services.

**Q: Can I export my data?**
A: Yes, you can export all your conversations, journal entries, and mood data at any time.

### Technical Support

**Common Issues:**
- Installation problems: Check Python version and dependencies
- Performance issues: Ensure adequate RAM and storage space
- Interface problems: Try refreshing browser or restarting servers

**Getting Help:**
- Check the troubleshooting guide (coming in Phase 5)
- Review system logs for error messages
- Consult the technical documentation for advanced issues

### Community and Resources

**Learning More:**
- Read about the philosophy behind sovereign AI
- Explore emotional intelligence and mental health resources
- Connect with others interested in privacy-focused technology

**Staying Updated:**
- WhisperLeaf is continuously improved based on user feedback
- New features and capabilities are added regularly
- Privacy and security remain the top priorities

---

## 🎯 Next Steps

Now that you understand the basics of WhisperLeaf, you're ready to:

1. **Start Your First Conversation** - Open the chat interface and introduce yourself
2. **Explore the Journal** - Try writing about your current feelings or recent experiences
3. **Check Your Timeline** - See how your mood tracking begins to develop
4. **Customize Your Settings** - Adjust the AI's behavior to match your preferences
5. **Create Your First Time Capsule** - Write a message to your future self

Remember: WhisperLeaf is designed to grow with you. The more you use it authentically, the better it becomes at providing personalized emotional support while always respecting your privacy and autonomy.

**Welcome to your journey of emotional sovereignty with WhisperLeaf!** 🌿

---

*This guide will continue to evolve based on user feedback and new features. Your privacy and wellbeing are always our top priorities.*

