import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ScrollArea } from '@/components/ui/scroll-area.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { 
  Send, 
  Bot, 
  User, 
  Shield, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  Settings,
  MessageSquare
} from 'lucide-react'

const ChatInterface = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      role: 'assistant',
      content: 'Hello! I\'m your Sovereign AI assistant, operating under constitutional governance. I\'m here to help you while following strict ethical guidelines. How can I assist you today?',
      timestamp: new Date(),
      constitutional: {
        allowed: true,
        confidence: 1.0,
        appliedRules: [],
        reasoning: 'Initial greeting message'
      }
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [conversationId] = useState(`conv_${Date.now()}`)
  const [userId] = useState('user_demo')
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const sendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return

    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsLoading(true)

    try {
      // Call the constitutional AI API
      const response = await fetch('http://localhost:8003/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: userId,
          conversation_id: conversationId,
          message: inputMessage
        })
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      const assistantMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: data.response.content,
        timestamp: new Date(data.response.timestamp),
        constitutional: data.response.constitutional_decision,
        model: data.response.model,
        generationTime: data.response.generation_time_ms,
        wasModified: data.response.was_modified,
        modificationReason: data.response.modification_reason
      }

      setMessages(prev => [...prev, assistantMessage])
    } catch (error) {
      console.error('Error sending message:', error)
      
      const errorMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: 'I apologize, but I encountered an error while processing your message. Please make sure the Sovereign AI server is running and try again.',
        timestamp: new Date(),
        constitutional: {
          allowed: false,
          confidence: 0.0,
          reasoning: 'System error occurred'
        },
        isError: true
      }

      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  }

  const getConstitutionalBadge = (constitutional) => {
    if (!constitutional) return null

    if (constitutional.allowed) {
      return (
        <Badge variant="outline" className="text-green-600 border-green-200">
          <CheckCircle className="w-3 h-3 mr-1" />
          Approved
        </Badge>
      )
    } else {
      return (
        <Badge variant="outline" className="text-red-600 border-red-200">
          <AlertTriangle className="w-3 h-3 mr-1" />
          Blocked
        </Badge>
      )
    }
  }

  const getMessageIcon = (role, constitutional) => {
    if (role === 'user') {
      return <User className="w-5 h-5" />
    }
    
    if (constitutional && !constitutional.allowed) {
      return <Shield className="w-5 h-5 text-red-500" />
    }
    
    return <Bot className="w-5 h-5 text-blue-500" />
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Header */}
      <Card className="rounded-none border-b">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Shield className="w-6 h-6 text-blue-600" />
              <CardTitle className="text-xl">Sovereign AI Chat</CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-xs">
                <MessageSquare className="w-3 h-3 mr-1" />
                Constitutional AI
              </Badge>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4 max-w-4xl mx-auto">
          {messages.map((message) => (
            <div key={message.id} className="flex space-x-3">
              <div className="flex-shrink-0 mt-1">
                {getMessageIcon(message.role, message.constitutional)}
              </div>
              
              <div className="flex-1 space-y-2">
                <div className="flex items-center space-x-2">
                  <span className="font-medium text-sm">
                    {message.role === 'user' ? 'You' : 'Sovereign AI'}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {formatTimestamp(message.timestamp)}
                  </span>
                  {message.constitutional && getConstitutionalBadge(message.constitutional)}
                  {message.model && (
                    <Badge variant="outline" className="text-xs">
                      {message.model}
                    </Badge>
                  )}
                </div>
                
                <Card className={`${message.role === 'user' ? 'bg-blue-50 dark:bg-blue-950' : 'bg-muted/50'} ${message.isError ? 'border-red-200 bg-red-50 dark:bg-red-950' : ''}`}>
                  <CardContent className="p-3">
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    
                    {/* Constitutional Information */}
                    {message.constitutional && (
                      <div className="mt-3 pt-3 border-t border-border/50">
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <span>Confidence:</span>
                            <span className="font-medium">
                              {(message.constitutional.confidence * 100).toFixed(0)}%
                            </span>
                          </div>
                          
                          {message.generationTime && (
                            <div className="flex items-center space-x-1">
                              <Clock className="w-3 h-3" />
                              <span>{message.generationTime.toFixed(0)}ms</span>
                            </div>
                          )}
                          
                          {message.wasModified && (
                            <Badge variant="outline" className="text-xs text-orange-600 border-orange-200">
                              Modified
                            </Badge>
                          )}
                        </div>
                        
                        {message.constitutional.reasoning && (
                          <p className="text-xs text-muted-foreground mt-1">
                            {message.constitutional.reasoning}
                          </p>
                        )}
                        
                        {message.modificationReason && (
                          <p className="text-xs text-orange-600 mt-1">
                            Reason: {message.modificationReason}
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex space-x-3">
              <div className="flex-shrink-0 mt-1">
                <Bot className="w-5 h-5 text-blue-500 animate-pulse" />
              </div>
              <div className="flex-1">
                <Card className="bg-muted/50">
                  <CardContent className="p-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      <span className="text-sm text-muted-foreground ml-2">
                        Processing through constitutional governance...
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <Card className="rounded-none border-t">
        <CardContent className="p-4">
          <div className="flex space-x-2 max-w-4xl mx-auto">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message... (Press Enter to send)"
              className="flex-1"
              disabled={isLoading}
            />
            <Button 
              onClick={sendMessage} 
              disabled={!inputMessage.trim() || isLoading}
              size="icon"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="flex items-center justify-center mt-2 text-xs text-muted-foreground">
            <Shield className="w-3 h-3 mr-1" />
            All messages are evaluated by constitutional AI governance
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default ChatInterface

