# Sovereign AI Source Code Package

**Complete source code for the Level 3 Sovereign AI Personal AI System**

---

## 📦 Package Information

- **Package**: `sovereign_ai_source_code.tar.gz`
- **Size**: 221KB compressed
- **Files**: 152 total files
- **Version**: Level 3 Sovereign AI v1.0
- **Created**: July 19, 2025

---

## 📁 Directory Structure

```
sovereign_ai/
├── api-server/                    # Core data management system
│   ├── main.py                    # Main API server
│   ├── database.py                # Database connection & models
│   ├── models.py                  # SQLAlchemy models
│   ├── vault.py                   # Document storage system
│   ├── vector_store.py            # Semantic search
│   ├── document_processor.py      # Text extraction
│   └── data/                      # Database files (created at runtime)
│
├── constitutional/                # AI governance system
│   ├── constitution.py            # Rule definition framework
│   └── ai_governor.py             # Real-time governance engine
│
├── curation/                      # Content curation engine
│   ├── rss_processor.py           # RSS feed processing
│   ├── web_scraper.py             # Web content extraction
│   ├── content_filter.py          # Quality assessment
│   ├── source_manager.py          # Automated scheduling
│   └── feed_monitor.py            # Feed monitoring
│
├── time_capsule/                  # Backup & recovery system
│   ├── backup_system.py           # Automated backups
│   └── recovery_manager.py        # Point-in-time recovery
│
├── sovereign-chat/                # React web application
│   ├── src/
│   │   ├── App.jsx                # Main application
│   │   ├── components/
│   │   │   ├── ChatInterface.jsx  # Chat interface
│   │   │   └── ui/                # UI components (70+ files)
│   │   ├── hooks/                 # React hooks
│   │   └── lib/                   # Utilities
│   ├── package.json               # Node.js dependencies
│   ├── vite.config.js             # Build configuration
│   └── [React app structure]
│
├── scripts/                       # System management
│   ├── start_system.sh            # Start all services
│   ├── stop_system.sh             # Stop all services
│   └── check_status.sh            # System health check
│
├── tests/                         # Test files
│   ├── test_constitutional.py     # Constitutional AI tests
│   ├── test_content_filter.py     # Content filtering tests
│   ├── test_time_capsule.py       # Backup system tests
│   ├── integration_test.py        # Complete system tests
│   └── [other test files]
│
├── config/                        # Configuration
│   └── config.yaml                # Main configuration
│
├── chat_api.py                    # Chat API server
├── curation_api.py                # Curation API server
├── requirements.txt               # Python dependencies
├── .env                           # Environment variables
└── [configuration files]
```

---

## 🚀 Key Components Included

### **Backend Systems (Python)**
- **Chat API Server**: Constitutional AI + conversation management
- **Curation API Server**: Content sources + intelligent filtering
- **Core Data Management**: Vault, vector database, document processing
- **Constitutional AI**: Rule-based governance system
- **Automated Curation**: RSS feeds, web scraping, content filtering
- **Time Capsule System**: Enterprise backup and recovery
- **Integration Tests**: Comprehensive test suite

### **Frontend Application (React)**
- **Modern Chat Interface**: Professional web application
- **Real-time Updates**: Live constitutional governance display
- **Responsive Design**: Works on desktop and mobile
- **Component Library**: 70+ UI components with Tailwind CSS
- **Build System**: Vite-based development and production builds

### **System Management**
- **Startup Scripts**: Automated service management
- **Configuration Templates**: YAML and environment files
- **Health Monitoring**: System status and performance checks
- **Database Schemas**: SQLite initialization and models

### **Documentation & Tests**
- **Test Suites**: Unit tests and integration tests
- **Configuration Examples**: Ready-to-use config templates
- **Development Tools**: Linting, formatting, build scripts

---

## 📋 Installation Requirements

### **System Dependencies**
- **Operating System**: Ubuntu 22.04 LTS (or compatible Linux)
- **Python**: 3.11+ with pip
- **Node.js**: 20+ with pnpm
- **Ollama**: AI model management
- **System packages**: curl, git, build tools

### **Python Dependencies** (from requirements.txt)
```
fastapi>=0.104.1
uvicorn>=0.24.0
sqlalchemy>=2.0.23
sqlite3 (built-in)
requests>=2.31.0
beautifulsoup4>=4.12.2
feedparser>=6.0.10
schedule>=1.2.0
sentence-transformers>=2.2.2
chromadb>=0.4.15
python-multipart>=0.0.6
python-jose>=3.3.0
passlib>=1.7.4
bcrypt>=4.0.1
```

### **Node.js Dependencies** (from package.json)
```
react>=18.2.0
vite>=5.0.0
tailwindcss>=3.3.0
@shadcn/ui components
lucide-react (icons)
clsx, tailwind-merge
```

---

## 🛠️ Quick Start

### **1. Extract the Package**
```bash
tar -xzf sovereign_ai_source_code.tar.gz
cd sovereign_ai
```

### **2. Install System Dependencies**
```bash
# Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Install Python and Node.js (Ubuntu)
sudo apt update
sudo apt install python3.11 python3.11-pip nodejs npm
npm install -g pnpm
```

### **3. Set Up Python Environment**
```bash
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### **4. Set Up React Application**
```bash
cd sovereign-chat
pnpm install
cd ..
```

### **5. Download AI Model**
```bash
ollama pull tinyllama
```

### **6. Start the System**
```bash
chmod +x scripts/*.sh
./scripts/start_system.sh
```

### **7. Access the Interface**
- **Web Interface**: http://localhost:5174
- **Chat API**: http://localhost:8003
- **Curation API**: http://localhost:8002

---

## 🔧 Configuration

### **Environment Variables** (.env)
```
OLLAMA_HOST=http://localhost:11434
CHAT_API_PORT=8003
CURATION_API_PORT=8002
REACT_APP_PORT=5174
DATABASE_URL=sqlite:///./sovereign_ai.db
VECTOR_DB_PATH=./data/chroma_db
VAULT_PATH=./data/vault
```

### **Main Configuration** (config/config.yaml)
```yaml
ai:
  model: "tinyllama"
  temperature: 0.7
  max_tokens: 2048

constitutional:
  rules_file: "constitutional/default_rules.json"
  enforcement_level: "strict"

curation:
  scan_interval: 3600  # 1 hour
  max_sources: 100
  content_retention_days: 30

backup:
  interval: 86400  # 24 hours
  retention_count: 7
  compression: true
```

---

## 🧪 Testing

### **Run All Tests**
```bash
# Activate virtual environment
source venv/bin/activate

# Run individual test suites
python test_constitutional.py
python test_content_filter.py
python test_time_capsule.py

# Run integration tests
python integration_test.py
```

### **Test Coverage**
- **Constitutional AI**: Rule evaluation, governance, response modification
- **Content Curation**: RSS processing, web scraping, filtering
- **Time Capsule**: Backup creation, recovery, verification
- **Integration**: End-to-end system functionality
- **API Endpoints**: All REST API endpoints with sample data

---

## 🔒 Security Features

### **Built-in Security**
- **Constitutional AI Governance**: Prevents harmful AI responses
- **Input Validation**: All API inputs validated and sanitized
- **Rate Limiting**: Prevents abuse of web scraping and APIs
- **Robots.txt Compliance**: Ethical web scraping practices
- **Local Processing**: All AI processing happens locally
- **Encrypted Backups**: Time capsule backups with integrity verification

### **Privacy Protection**
- **No Cloud Dependencies**: Core functionality works offline
- **Local Data Storage**: All conversations and data stay on your machine
- **Constitutional Privacy Rules**: Built-in privacy protection rules
- **Audit Logging**: Complete transparency of all AI decisions

---

## 🚀 Production Deployment

### **System Requirements**
- **Minimum**: 2 CPU cores, 4GB RAM, 10GB storage
- **Recommended**: 4 CPU cores, 8GB RAM, 50GB SSD
- **High Performance**: 8+ CPU cores, 16GB+ RAM, 100GB+ NVMe SSD

### **Deployment Options**
1. **Local Development**: Run on personal computer
2. **Home Server**: Deploy on dedicated hardware
3. **Cloud Instance**: AWS, GCP, DigitalOcean
4. **Docker Container**: Containerized deployment (Dockerfile included)

### **Production Checklist**
- [ ] Update all dependencies to latest versions
- [ ] Configure firewall and security settings
- [ ] Set up SSL/TLS certificates for HTTPS
- [ ] Configure automated backups
- [ ] Set up monitoring and logging
- [ ] Test disaster recovery procedures

---

## 📞 Support

### **Getting Help**
1. **Installation Issues**: Check requirements.txt and system dependencies
2. **API Errors**: Review logs in the console output
3. **React Build Issues**: Ensure Node.js 20+ and pnpm are installed
4. **AI Model Issues**: Verify Ollama is running and model is downloaded
5. **Performance Issues**: Check system resources and configuration

### **Common Issues**
- **Port Conflicts**: Change ports in .env file if needed
- **Permission Errors**: Ensure scripts are executable (`chmod +x scripts/*.sh`)
- **Memory Issues**: Use TinyLLama model for systems with <8GB RAM
- **Network Issues**: Check firewall settings for API ports

---

## 🎯 What's Included vs. What's Not

### ✅ **Included in Source Package**
- Complete Python backend source code
- Complete React frontend source code
- System management scripts
- Configuration templates
- Test suites and examples
- Database schemas and models
- Documentation references

### ❌ **Not Included (Install Separately)**
- Python packages (install via `pip install -r requirements.txt`)
- Node.js packages (install via `pnpm install`)
- AI models (download via `ollama pull tinyllama`)
- System dependencies (install via package manager)
- Runtime databases (created automatically on first run)

---

## 🎉 Ready to Deploy!

This source code package contains everything you need to build and run your own Level 3 Sovereign AI system. Follow the installation guide from the documentation package for detailed setup instructions.

**Your AI, Your Rules, Your Data** - Complete source code for true AI sovereignty!

---

*Sovereign AI Source Code Package v1.0 - Complete implementation of Level 3 Sovereign AI*

